<p align="center">
  <img alt="Grok2API" src="./frontend/public/grok2api.png" width="720" />
</p>

<p align="center">
  <strong>面向 Grok Build、Grok Web 与 Grok Console 的多账号 API 网关</strong>
</p>

<p align="center">
  <a href="./README.md">English</a> | 简体中文
</p>

<p align="center">
  <a href="./backend/go.mod"><img alt="Go" src="https://img.shields.io/badge/Go-1.26-00ADD8?logo=go&logoColor=white" /></a>
  <a href="./frontend/package.json"><img alt="React" src="https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=111827" /></a>
  <a href="https://github.com/chenyme/grok2api/pkgs/container/grok2api"><img alt="Docker" src="https://img.shields.io/badge/Docker-amd64%20%7C%20arm64-2496ED?logo=docker&logoColor=white" /></a>
</p>

<p align="center">
  <a href="https://trendshift.io/repositories/19868?utm_source=repository-badge&amp;utm_medium=badge&amp;utm_campaign=badge-repository-19868" target="_blank" rel="noopener noreferrer"><img src="https://trendshift.io/api/badge/repositories/19868" alt="chenyme%2Fgrok2api | Trendshift" width="250" height="55"/></a>
</p>

> [!TIP]
> 推荐个人新项目 [DEEIX-AI / DEEIX-Chat](https://github.com/DEEIX-AI/DEEIX-Chat)：面向多模型路由、对话、文件、工具、计费与运维的一体化轻量 AI 平台。

> [!NOTE]
> 本项目仅供技术研究与学习交流。使用时请务必遵循 Grok 官方的使用条款及当地法律法规，否则一切后果自负！

## 赞助商

> [希望赞助这个项目？](mailto:chenyme03@gmail.com)

<table>
<tr>
<td width="200" align="center" valign="middle"><a href="https://go.apimart.ai/gh-grok2api"><img src="frontend/public/sponner/api-mart.jpg" alt="APIMart" width="180"></a></td>
<td valign="middle">感谢 APIMart 赞助了本项目！APIMart 是专注 AI 图片/视频生成的低价 API 平台，GPT-Image-2 低至 $0.006/张，1 美元可出图 160+ 张。图片、视频一套异步 API 通吃，提交任务拿 ID、回调取结果，跑批万张不超时、换模型不改代码。按量付费、无月费，通过此 <a href="https://go.apimart.ai/gh-grok2api">注册链接</a> 注册即可开用。</td>
</tr>
<tr>
<td width="200" align="center" valign="middle"><a href="https://www.packyapi.com/register"><img src="frontend/public/sponner/packycode.png" alt="PackyCode" width="180"></a></td>
<td valign="middle">PackyCode 是稳定专业的 API 中转服务商，支持 Claude Code、Codex、Gemini 及多种国模，提供统一高速入口、全栈可观测、风控与弹性扩容。<a href="https://www.packyapi.com/register">点此注册</a>，轻松将大模型接入业务流程。</td>
</tr>
<tr>
<td width="200" align="center" valign="middle"><a href="https://github.com/DEEIX-AI/DEEIX-Chat"><img src="frontend/public/sponner/deeix-chat_deeix-ai.png" alt="DEEIX AI / DEEIX Chat" width="160"></a></td>
<td valign="middle">DEEIX-Chat 是一款开源可部署的 AI Chat 平台，面向需要长期、稳定、统一使用多模型能力的个人、团队与企业，将模型、对话、文件、工具调用与后台管理整合为一套可部署、可扩展的系统。点击 <a href="https://github.com/DEEIX-AI/DEEIX-Chat">此处</a> 开始部署！</td>
</tr>
<tr>
<td width="200" align="center" valign="middle"><a href="https://www.right.codes/register"><img src="frontend/public/sponner/rightcode.jpg" alt="RightCode" width="160"></a></td>
<td valign="middle">Right Code 是一个企业级 AI Agent 分发平台，主要提供稳定的 Claude Code、Codex、Gemini 等模型的中转服务。充值即可开票，企业、团队用户一对一对接。感谢 Right Code 提供的 Tokens 支持，点击 <a href="https://www.right.codes/register">此处</a> 注册并开始使用！</td>
</tr>
<tr>
<td width="200" align="center" valign="middle"><a href="https://www.rapidproxy.io/?ref=grok2api"><img src="frontend/public/sponner/rapid-proxy.jpg" alt="RapidProxy" width="180"></a></td>
<td valign="middle">RapidProxy 是面向开发者的数据采集代理方案，提供稳定可靠的住宅代理服务。拥有 9000 万+ 全球住宅 IP，覆盖 200+ 个国家和地区，支持智能轮换与精准地域定位，帮助网页抓取、AI 数据训练、SEO 监控、电商数据分析等项目突破访问限制、提升采集效率。支持 Playwright、Selenium、Puppeteer 等主流自动化框架，价格低至 $0.65/GB，<a href="https://www.rapidproxy.io/?ref=grok2api">立即免费测试</a>。</td>
</tr>
</table>

<br>

## 项目简介

Grok2API 是一个内置 React 管理端的 Go 网关。它分别管理 Grok Build、Grok Web 和 Grok Console 账号池，并对外提供统一的 OpenAI 与 Anthropic 兼容接口。

### 项目架构

```mermaid
flowchart LR
    %% 颜色定义
    classDef access fill:#e1f5fe,stroke:#01579b
    classDef core fill:#fff3e0,stroke:#e65100
    classDef providers fill:#f3e5f5,stroke:#4a148c
    classDef infra fill:#e8f5e9,stroke:#1b5e20
    classDef upstream fill:#fce4ec,stroke:#880e4f

    subgraph Access["接入域"]
        direction LR
        Clients["API 客户端"]
        Admin["React 管理端"]
    end

    subgraph Core["网关核心域"]
        direction LR
        Management["管理服务<br/>账号 · 模型 · 密钥 · 设置"]
        Sync["账号同步<br/>凭据 · 额度 · 模型"]
        Gateway["网关服务<br/>协议 · 路由 · 选号 · 重试"]
        Audit["审计服务<br/>用量 · 客户端计费"]
        Management --> Sync
        Gateway -.-> Audit
    end

    subgraph Providers["Provider 渠道域"]
        direction LR
        Registry["Provider 注册表"]
        Build["Grok Build<br/>OAuth · 动态模型 · Billing"]
        Web["Grok Web<br/>SSO · 远端额度 · 媒体"]
        Console["Grok Console<br/>SSO · 本地窗口 · 无状态"]
        Registry --> Build
        Registry --> Web
        Registry --> Console
    end

    subgraph Infra["共享基础设施域"]
        direction LR
        Egress["出口管理器<br/>作用域 · 代理池 · 回退 · Clearance"]
        Database[("SQLite / PostgreSQL")]
        Runtime[("Memory / Redis")]
    end

    Upstream["🌐 Grok 上游"]

    %% 跨域调用
    Clients --> Gateway
    Admin --> Management
    Gateway --> Registry
    Sync --> Registry
    Build -->|grok_build| Egress
    Web -->|grok_web / asset| Egress
    Console -->|grok_console| Egress
    Egress --> Upstream
    Management --> Database
    Audit --> Database
    Gateway <--> Runtime

    %% 应用样式
    class Clients,Admin access
    class Management,Sync,Gateway,Audit core
    class Registry,Build,Web,Console providers
    class Egress,Database,Runtime infra
    class Upstream upstream
```

网关通过 Provider 注册表分发请求，账号同步负责刷新凭据、额度和模型。三个渠道独立维护账号状态并使用隔离的出口作用域；请求结束后统一结算用量、审计和客户端计费。

### 核心能力

| 模块 | 能力 |
| :-- | :-- |
| 接口 | Responses、Chat Completions、Anthropic Messages、Images 与异步 Videos |
| 客户端 | Codex、Claude Code，以及 OpenAI/Anthropic 兼容 SDK |
| 账号 | 批量导入导出、额度同步、凭据续期、转换、账号工具与清理 |
| 路由 | 模型发现、Provider 限定、会话粘滞、额度/并发门禁和有界切换 |
| 会话 | stored response、compact、Prompt Cache 亲和与可选 reasoning replay |
| 媒体 | 图片生成与编辑、视频任务、本地归档及 URL/Base64/SSE 输出 |
| 出口 | HTTP/SOCKS/Resin 与 Trojan/VLESS/Shadowsocks/VMess 隧道、订阅、探测、代理池、调配、回退与 FlareSolverr |
| 运维 | Dashboard、模型路由、客户端密钥、审计、运行设置和媒体库 |

### Provider 边界

| Provider | 认证 | 模型 | 主要能力 |
| :-- | :-- | :-- | :-- |
| Grok Build | OAuth / 设备授权 | 按账号动态发现 | Responses、Chat、Messages、compact、stored response、付费账号视频 |
| Grok Web | SSO | 内置并按等级过滤 | Responses、Chat、Messages、stored response、图片、图片编辑、视频 |
| Grok Console | SSO | 内置 | 无状态 Responses、Chat、Messages、图片、图片编辑、视频、TTS、STT、Realtime |

三个 Provider 独立维护凭据、额度、健康、冷却、并发与模型能力。单条路由的账号重试始终留在当前 Provider；当同一对外模型名主动聚合了多条路由时，网关可选择另一条可调度路由，但不会跨 Provider 混用账号状态。

## 快速部署

官方镜像支持 `linux/amd64` 和 `linux/arm64`。

```bash
git clone https://github.com/chenyme/grok2api.git
cd grok2api
cp config.example.yaml config.yaml
```

生成密钥并写入 `config.yaml`：

```bash
openssl rand -hex 32
openssl rand -base64 32
```

```yaml
secrets:
  jwtSecret: "替换为生成的 Hex 密钥"
  credentialEncryptionKey: "替换为生成的 Base64 密钥"

bootstrapAdmin:
  username: "admin"
  password: "替换为强密码"
```

启动服务：

```bash
docker compose pull
docker compose up -d
docker compose logs -f grok2api
```

docker build -t grok2api:local . && GROK2API_IMAGE=grok2api:local docker compose up -d

访问 `http://127.0.0.1:7878`。镜像已包含前端，SQLite 数据库与本地媒体保存在 Compose 数据卷中。

### 源码运行

```bash
cp config.example.yaml config.yaml
make run
```

单独运行前端开发服务：

```bash
cd frontend
pnpm install
pnpm dev
```

## 初始化网关

1. 使用初始管理员登录。
2. 接入 Build、Web 或 Console 账号。
3. 等待额度和模型能力同步完成。
4. 在“模型路由”中确认公开模型。
5. 在“客户端密钥”中创建密钥。
6. 使用该密钥调用 `/v1/*`。

首次登录后请修改管理员密码，并从配置中删除 `bootstrapAdmin`。账号写入后不要更换 `credentialEncryptionKey`。

### 账号操作

| Provider | 接入或导入 | 导出 |
| :-- | :-- | :-- |
| Build | 设备授权、JSON/JSONL | 可重新导入的账号文件 |
| Web | 粘贴/TXT SSO、JSON/JSONL | 可重新导入的账号文件 |
| Console | 粘贴/TXT SSO、JSON/JSONL | 可重新导入的账号文件 |

导入兼容 UTF-8 BOM。批量额度同步、Build 凭据续期、Web→Build/Console 转换、账号工具和账号清理均显示实时进度。

Build Refresh Token 在续期时可能发生轮换。请勿让 grok2api、官方 CLI、其他网关或独立客户端同时使用同一份 Build 凭据，否则其中一个客户端可能消费另一个客户端仍在保存的旧 Token。建议为每个活跃客户端分别授权；如需迁移凭据，应先停止旧客户端继续使用。

Web 账号工具支持接受协议、设置对应 20–40 岁的随机生日和开启 NSFW；已完成步骤会记录并在后续执行时跳过。

系统支持自动删除长期处于 `reauthRequired` 的账号，默认关闭；存在活动推理租约或视频任务的账号不会被删除。

> [!TIP]
> 从 Python 版迁移时，请将 Grok Web SSO 导出为 TXT，再导入“Grok Web”。旧数据库和号池元数据不兼容。

## 模型与路由

Build 模型根据每个账号的实际能力动态发现；Web、Console 使用内置目录。管理端“模型路由”展示 Provider 前缀、接口能力和支持账号数；客户端应以 `GET /v1/models` 返回的当前可服务模型为准。

### Grok Build

Build 不使用全局固定模型清单。账号同步会读取上游 `/models`，不同账号、订阅等级或灰度批次可能返回不同模型，网关按账号能力参与调度，不会用单个账号覆盖全局目录。

| 模型 | 类型 | 可用条件 | 网关接口能力 |
| :-- | :-- | :-- | :-- |
| 上游 `/models` 返回的对话模型（例如 `grok-4.5`） | 对话 | 当前账号实际返回 | Chat Completions、Responses、Messages、compact、stored response |
| `grok-composer-2.5-fast` | 对话 | Grok Build OAuth 账号 | Chat Completions、Responses、Messages；即使上游稀疏目录暂未列出，网关也会按 OAuth 会话能力补齐 |
| `grok-imagine-video-1.5` | 视频 | Super/付费 Build 账号 | Videos；Free 或能力未知账号不会获得该路由 |

对话请求会转换到 Build Responses 协议，并保留 Codex、Claude Code 所需的工具、推理、多轮与 Prompt Cache 兼容逻辑。Build 当前不提供图片生成和图片编辑路由。

### Grok Web

Web 使用内置目录并按账号等级过滤；更高等级继承低等级模型。

| 模型 | 类型 | 最低等级 | 网关接口能力 |
| :-- | :-- | :-- | :-- |
| `grok-chat-fast` | 对话 | Basic | Chat Completions、Responses、Messages |
| `grok-chat-auto` | 对话 | Super | Chat Completions、Responses、Messages |
| `grok-chat-expert` | 对话 | Super | Chat Completions、Responses、Messages |
| `grok-chat-heavy` | 对话 | Heavy | Chat Completions、Responses、Messages |
| `grok-imagine-image-2.0-web` | 图像 / 图像编辑 | Basic | Images Generations / Images Edits（仅 1K 质量模式；非流式生成响应包含对象分段；额度耗尽自动换号） |
| `grok-imagine-video` | 视频 | Basic | Videos；保留旧 Web 协议 |
| `grok-imagine-video-1.5` | 视频 | Basic；1080p 仅 Heavy/H | Videos；新版文生、单图图生、多参考图/音频协议；480p/720p/1080p，6-15 秒，参考模式最高 720p |

### Grok Console

Console 使用当前版本内置目录。对话为无状态转发；图片、视频和语音使用 xAI 标准资源接口。

| 模型 | 类型 | 网关接口能力 |
| :-- | :-- | :-- |
| `grok-4.20-0309-non-reasoning` | 对话 | Chat Completions、Responses、Messages |
| `grok-4.20-0309-reasoning` | 对话 | Chat Completions、Responses、Messages；模型会推理，但上游不接受可配置 `reasoningEffort` |
| `grok-4.20-multi-agent-0309` | 对话 | Chat Completions、Responses、Messages |
| `grok-4.5` | 对话 | Chat Completions、Responses、Messages |
| `grok-4.3` | 对话 | Chat Completions、Responses、Messages |
| `grok-build-0.1` | 对话 | Chat Completions、Responses、Messages |
| `grok-imagine-image` | 图像、图像编辑 | Images Generations、Images Edits |
| `grok-imagine-image-quality` | 图像、图像编辑 | Images Generations、Images Edits |
| `grok-imagine-image-2.0` | 图像、图像编辑 | Images Generations、Images Edits |
| `grok-imagine-video` | 视频 | Videos |
| `grok-imagine-video-1.5` | 视频 | 视频生成，包括 Free Console 账号 |
| `grok-voice-latest`、`grok-voice-think-fast-2.0`、`grok-voice-think-fast-1.0` | 语音 | TTS 和 Realtime WebSocket 代理 |
| `grok-stt` | 语音 | STT 和 OpenAI 兼容的音频转录 |

同一个 Console 图片模型的生成与编辑能力会聚合展示为一条逻辑模型，不需要创建 `-edit` 模型副本。

公开模型名通常不带 Provider。内部路由使用 `Build/`、`Web/` 或 `Console/` 前缀；带前缀名称可显式限定来源。

Web 可与对应的 Build、Console 建立一对一弱关联。关联只共享匿名出口身份和来源展示，不合并凭据、额度、健康、冷却、并发、模型能力或计费。

### Codex、Claude Code 与 Prompt Cache

Responses 与 Messages 支持流式、工具、推理、多轮会话和 compact。客户端会话信号会保持稳定，用于 Grok Build Prompt Cache 亲和；实际命中仍要求上游账号兼容且请求前缀未变化。同一网关实例内，仍可解密的 `g2a_compact_v1` 摘要在 session / PromptCacheKey 漂移后也会展开；带该前缀但无法解码的 blob 会返回 400。其他 compact blob 作为上游原始状态转发时会保留原始 `encrypted_content`；若 Build 拒绝，该错误会原样返回客户端。

Responses 与 Chat Completions 按 OpenAI 语义报告输入总量；Messages 按 Anthropic 语义分开报告未缓存输入和缓存读取。审计保留输入总量与缓存部分，用于计费对账。

## API

推理接口使用客户端密钥：

```http
Authorization: Bearer g2a_xxx_xxx
```

| 方法 | 路径 | 用途 |
| :-- | :-- | :-- |
| `GET` | `/healthz`、`/readyz` | 存活与就绪检查 |
| `GET` | `/v1/models` | 当前可服务模型 |
| `POST` | `/v1/responses` | Responses JSON/SSE |
| `POST` | `/v1/responses/compact` | 压缩支持的 Response 会话 |
| `GET`、`DELETE` | `/v1/responses/{id}` | 查询或删除 stored response |
| `POST` | `/v1/chat/completions` | Chat Completions JSON/SSE |
| `POST` | `/v1/messages` | Anthropic Messages JSON/SSE |
| `POST` | `/v1/images/generations`、`/v1/images/edits` | 生成或编辑图片 |
| `POST` | `/v1/videos`、`/v1/videos/generations` | 创建视频任务 |
| `POST` | `/v1/videos/edits`、`/v1/videos/extensions` | 编辑和延长视频 |
| `GET` | `/v1/videos/{id}`、`/v1/videos/{id}/content` | 查询任务和读取视频内容 |
| `POST` | `/v1/tts`、`/v1/audio/speech`、`/v1/audio/tasks` | 语音合成 |
| `POST` | `/v1/stt`、`/v1/audio/transcriptions` | 音频转录 |
| `GET` | `/v1/stt`、`/v1/realtime` | 代理语音 WebSocket 会话 |
| `GET` | `/v1/media/images/{asset_id}`、`/v1/media/videos/{asset_id}` | 读取归档媒体 |

stored response 和 compact 取决于最终 Provider。登录管理端后可在 `/docs` 查看当前模型与调用示例；仅在 `server.swaggerEnabled: true` 时提供 Swagger。

`/v1/images/edits` 接受原有 JSON `image`/`images` URL 对象（包括 base64 data URL），或 `multipart/form-data` 的 `image`/`image[]` 图片文件。multipart 的 `model`、`prompt`、`n`、`size`、`quality`、`stream`、`partial_images` 等标量复用 JSON 业务校验；`selection_regions`、`multi_region_edits` 等结构化表单值使用 JSON。`n` 仍仅支持 1，`quality` 仅支持 `low`/`medium`。像素 `mask` 不受支持，两种格式均明确返回 `unsupported_parameter`；多边形选区继续可用。`background`、`input_fidelity`、`output_format`、`output_compression` 和图片编辑的 `user` 同样不受支持。

`POST /v1/videos` 与 `/v1/videos/generations` 均接受 JSON 或 multipart，共用模型、路由和输入校验。标准 `seconds`（1–15 的整数或整数字符串）映射 `duration`；`size` 精确映射：`1280x720`/`720x1280` 对应 720p 横屏/竖屏，`1920x1080`/`1080x1920` 对应 1080p 横屏/竖屏。其他尺寸（包括 `1792x1024`/`1024x1792`）以及与 `duration`、`resolution`、`aspect_ratio` 冲突的参数明确报错。multipart 的 `input_reference` 接受作为首帧的图片文件，不支持视频；JSON 使用现有 `{"url":"..."}` 或 `{"file_id":"..."}` 媒体输入对象，且不能同时提供 `image`。保留 `last_frame`、`reference_images` 和 `reference_audios`，结构化 multipart 值使用 JSON。视频编辑和延长保持原有源 `video` 协议，不接受仅用于生成的标准别名。

媒体 multipart 总请求上限 32 MiB、最多 64 段、每文件最多 20 MiB，同时遵守服务端更低的请求体上限。JPEG、PNG、静态 WebP、GIF 文件须声明匹配的 MIME 或 `application/octet-stream`，在任务创建及上游上传前先校验尺寸预算，再完整解码。单边最多 8192，解码像素最多 16,777,216；GIF 最多 128 帧且累计像素遵守同一预算。WebP 使用官方 `golang.org/x/image/webp` decoder，动画 WebP 和损坏图片被拒绝；原有 JSON data URL 路径不变。不按文件名识别图片。非法数值、重复标量和不支持的 multipart 选项明确报错。

`POST /v1/videos` 返回包含 `id`、`object: "video"`、`model`、`status` 的 OpenAI 风格视频对象。原有 `/v1/videos/generations`、`/edits`、`/extensions` 创建入口保持 `{"request_id":"..."}` 契约。共用的 `GET /v1/videos/{id}` 返回 `queued`、`in_progress`、`completed` 或 `failed`，附带任务真实时间戳、进度、已知时长的 `seconds` 字符串，以及保存的比例和分辨率能精确表示时的像素 `size`。完成任务保留 `video.url` 并提供 `content_url`。返回的图片和视频链接，包括 `/v1/media/images/{asset_id}`、`/v1/media/videos/{asset_id}` 和 `/v1/videos/{id}/content`，均支持无需 API Key 或 Cookie 的 GET/HEAD 直接下载，本地视频支持 Range 分段读取。生成、任务元数据查询和管理接口仍需鉴权。媒体能力仅限上述明确支持的选项，不是完整的 OpenAI 媒体兼容；未提供视频 list、delete 或 cancel 接口。

`/v1/audio/transcriptions` 支持 `json`（默认）、`verbose_json` 和 `text`。视频编辑按实际路由校验 Console `grok-imagine-video`。视频延长还支持 Web `grok-imagine-video-1.5`：请求需用 `video_extension_start_time` 提供源视频的绝对结束时间，网关会先把源视频上传到选中的 Web 账号，再新建延长会话；Web 的 `duration` 表示本次新增片段时长，范围 6 到 10 秒。对外模型名仍可自定义。金额计费以网关能够可靠测量的官方计价单位为准：TTS 按输入字符数预留并结算，REST 与流式 STT 按成功响应返回的实际音频时长结算。STT 时长只能在请求完成后获得，因此并发中的请求可能使有限额 Key 短暂超过金额上限。Realtime、视频编辑与延长，以及未收录官方定价的自定义路由当前记录为“未计费”，保持可调用且不消耗金额额度。

客户端密钥支持模型白名单，以及可选的 RPM、并发、用量和截止日期限制。

```bash
curl http://127.0.0.1:7878/v1/responses \
  -H "Authorization: Bearer g2a_xxx_xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "your-model",
    "input": "用三句话解释量子隧穿。",
    "stream": true
  }'
```

## 出口与 Cloudflare

出口节点按 Build、Web、Console 或 Web 资源隔离。管理端支持：

- HTTP、HTTPS、SOCKS4/4A、SOCKS5/5H、Resin、Trojan、VLESS、Shadowsocks 与 VMess
- 隧道协议支持 TCP、WebSocket 和 TLS，未实现的传输形态会在导入时拒绝
- 订阅和文本/Base64 导入
- 批量探测、筛选、删除、分配与均衡
- 按作用域配置无回退、直连或固定节点
- 代理池模式，单次连接失败不会触发全局冷却
- 固定代理传输失败后立即复测；同节点复测自动合并，后续绑定请求限时等待并在恢复后快速重试
- 可选的[出口质量守护程序](./tools/egress-quality-guard/README.zh-CN.md)，支持逐节点模型探测、防误杀隔离和自动恢复；通过内置的 `quality-guard` Compose profile 按需启用
- 代理用户名包含 `{account}` 的节点会被识别为租约级节点：被动审计异常只会临时移出对应的账号租约，冷却后固定使用同一账号和节点复测，复测异常会续期；若 sidecar 不可用，已到期的隔离不会继续阻断路由，避免孤儿状态永久卡住账号。共享节点始终不会因此停用，也不会暴露渲染后的代理身份。普通固定 sticky 会话仍可按独立节点管理

Hysteria 与 TUIC 暂未支持。FlareSolverr 仅接受 HTTP/SOCKS 代理地址，因此自动刷新 Clearance 暂不能直接使用隧道分享链接。

首次启用时只需在 `config.yaml` 中增加 `qualityGuard` 并启动 profile。主程序会自动创建并稳定复用不可导出的系统探测身份：

```yaml
qualityGuard:
  enabled: true
  model: "grok-4.7"
  # Grok 4.7 缺流式 reasoning 时先扣住响应，换号再打，不把降智正文发给用户。
  # 最多观察 30 秒；stub 加上足够可见输出在超时后扣住（TUI 30s 后的短问候），
  # 空 stub 继续等。floor 已达标但 1 秒内吐短回复的也扣。
  requestRetry:
    enabled: true
    maxAttempts: 6
    holdTimeout: 30s
    minOutputTokens: 5
    onExhausted: fail_closed # fail_open | fail_closed
    # 首次确认缺 thinking 或吞吐降智（soft/hard/burst）时立即禁用账号。
    autoDisable: true
    accountCooldown: 12h
    idleAccountCooldown: 15m
```

`requestRetry` 在网关请求路径上生效，与 sidecar 独立，仅作用于 Grok 4.7。内置默认值和 `config.example.yaml` 均关闭 `enabled`、`autoDisable`，任一开关开启后启用质量检测。可见输出达到 `minOutputTokens` 且没有流式 reasoning 时暂缓交付，只有可安全重放的无状态请求才能换账号重试。`autoDisable` 会在确认缺 thinking 或吞吐降智时停用账号。TUI 续聊和 hosted tools 仍参与检测，但不跨账号重放绑定状态或有副作用的工具。最终按 `onExhausted` 返回 `503 quality_degraded` 或放出当前响应。上下文压缩、图片、视频和 ForcedEgress 探针豁免这些检查。

```bash
docker compose --profile quality-guard up -d --build
```

曾使用预览版 `clientKeyID` 配置的现有部署可以直接升级：该字段会被兼容读取但不再使用，可安全删除；原来手工创建的探测 Key 不会被程序擅自删除。

后续修改该配置时，执行 `docker compose --profile quality-guard restart grok2api egress-quality-guard` 使基础配置重新加载；管理页面中的策略调整仍支持热加载。

普通的 `docker compose up -d` 不会启动守护程序，也不会产生主动探测流量。sidecar 只从主程序获得权限受限的内部凭据，不保存或使用管理员密码。启用自动隔离前请先阅读上面的详细说明。

Resin 用户名支持 `{account}`：

```text
socks5h://Default.{account}:RESIN_PROXY_TOKEN@resin:2260
```

占位符会替换为稳定的匿名身份。已关联的 Web、Build、Console 可共享该身份，不直接使用 Token 或 Email。

如需自动维护 Web/Console Cloudflare Clearance：

```bash
docker compose --profile flaresolverr up -d
```

随后在 **运行设置 → 媒体与网络 → Clearance** 填写 `http://flaresolverr:8191`，并选择一种托管模式：

- `FlareSolverr` 按配置周期主动刷新固定出口中过期的 Clearance。
- `按需刷新` 不按时间淘汰最后一次成功的 Clearance，只在上游明确拒绝并将其标记失效后重新求解；后台定时任务不会在该模式下启动浏览器。

`手动维护` 始终不会调用 FlareSolverr。按需模式允许首次请求不携带托管 Clearance；若被 Cloudflare 拒绝，下一次租约会执行一次经过并发去重的求解。

出口层只重试可以确认发生在请求提交前的连接故障，不会重放已经提交的生成请求、认证失败、额度耗尽或上游限流。

固定代理进入冷却后会立即触发一次独立连通性复测。同一节点的并发故障只启动一个探针；后续绑定请求最多等待 5 秒，复测健康后重新读取节点状态并继续，不健康则保持原冷却。代理池每次获取新隧道，单个旋转出口失败不会让整个池进入冷却。完整设计与安全边界见[即时故障复测与限时重试](./backend/internal/infra/egress/FAILURE_RETRY.md)。

## 配置与部署

`config.yaml` 保存启动配置；Provider 和运维参数由管理端维护，未标记“重启生效”的设置支持热加载。

| 场景 | 数据库 | 运行态 | 媒体 |
| :-- | :-- | :-- | :-- |
| 单实例 | SQLite | Memory | 本地目录 |
| 多实例 | PostgreSQL | Redis | 共享且可读写的目录 |

多实例需要为每个副本设置唯一的 `deployment.instanceID`，统一使用同一个 `clusterID`；只有媒体目录已正确共享时才设置 `sharedMedia: true`。

PostgreSQL 凭据可以通过环境变量注入，无需写入 `config.yaml`：

```bash
GROK2API_DATABASE_URL='postgresql://user:password@host:5432/grok2api?sslmode=require' docker compose up -d
```

非空的 `GROK2API_DATABASE_URL` 会覆盖 `database.postgres.dsn` 并自动选择 `postgres`；空值不会覆盖 YAML。支持 `postgres://` 和 `postgresql://`，SQLAlchemy 的 `postgresql+asyncpg://` 会返回格式迁移提示。程序不会隐式读取通用的 `DATABASE_URL`；平台只提供该变量时，可在部署清单中显式映射为 `GROK2API_DATABASE_URL: "${DATABASE_URL}"`。数据库配置优先级为：内置默认值 < `config.yaml` < `GROK2API_DATABASE_URL`。当前 CLI 没有数据库覆盖参数。

### 反向代理后的客户端 IP

请求审计会记录规范化的客户端 IPv4 或 IPv6 地址。客户端直连 grok2api 时无需额外配置；经过 Nginx 等反向代理时，需要同时配置代理和 grok2api：

1. 在 Nginx 中转发标准客户端 IP 请求头：

```nginx
location / {
    proxy_pass http://127.0.0.1:7878;

    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

2. 在 `config.yaml` 中仅信任 Nginx 的实际地址或隔离网络：

```yaml
server:
  trustedProxies:
    - "127.0.0.1"
```

使用 Docker 时，grok2api 看到的对端可能是网桥网关或另一个容器，而不是 `127.0.0.1`。配置前可查询 Compose 网络：

```bash
docker network inspect grok2api_default \
  --format '{{(index .IPAM.Config 0).Subnet}}'
```

例如隔离网络返回 `172.20.0.0/16` 时，可以将该 CIDR 配置为可信代理。不要使用 `0.0.0.0/0` 或 `::/0`；grok2api 会拒绝不受限的可信代理范围。未配置 `trustedProxies` 时，所有转发头都会被忽略，审计记录 TCP 直连对端地址，从而避免客户端伪造 `X-Forwarded-For`。

如果 Nginx 前还有 Cloudflare，应先使用 Cloudflare 官方代理网段和 `CF-Connecting-IP` 正确配置 Nginx real-IP 模块，不要信任任意来源提供的 `CF-Connecting-IP`。修改 `server.trustedProxies` 后需要重启 grok2api；修改 Nginx 配置后需要重新加载 Nginx。

重要的可选设置：

- `audit.ledgerMode`：`observe` 仅报告账本故障；`enforce` 可暂停新推理以保护计费准确性。
- `routing.accountIsolatedConnections`：为外部 L4 或按连接哈希的负载均衡器按账号拆分出站 TCP/HTTP 连接池。默认关闭，因为会增加连接数、TLS 握手、内存和文件描述符占用。
- `routing.segmentedSelectorEnabled`：默认对至少 3000 个可用账号的大号池启用，限制动态并发读取规模，同时保留额度/等级优先级、会话粘性、完整选号回退与原子门禁。
- `routing.autoAssignMaxNodeShare` / `routing.autoAssignMaxMigrationShare`：可选的大号池保护。`0`（默认）保持历史行为：不健康节点上的 auto 账号会一次性迁走，容量/再均衡仍最多 200 次。仅在隔离一个节点会把大量账号压到最后几个健康出口时，才设为 `0.05`–`1`。环境变量 `GROK2API_AUTO_ASSIGN_MAX_NODE_SHARE` 与 `GROK2API_AUTO_ASSIGN_MAX_MIGRATION_SHARE` 可覆盖 YAML。
- Build 响应头超时和精确匹配的 403 失效规则支持热加载。
- “同步最新版本”可应用已验证的 Grok Build 客户端版本和 User-Agent。

## 生产检查

- 使用 HTTPS，并启用 `auth.secureCookies`。
- 公网部署保持 Swagger 关闭。
- 使用强密钥并妥善备份；不要提交凭据、Cookie、账号导出或数据库。
- 备份 `config.yaml`、数据库和媒体目录。
- 多实例同时使用 PostgreSQL、Redis 与共享媒体。
- 公网服务前置反向代理与访问控制。

## 开发验证

```bash
cd backend
go test ./...
go test -race ./...
go vet ./...
go build ./cmd/grok2api
```

```bash
cd frontend
pnpm install --frozen-lockfile
pnpm lint
pnpm build
```

修改公开 API 注释后重新生成 Swagger：

```bash
make swagger
```

## 相关文档

- [English README](./README.md)
- [后端说明](./backend/README.md)
- [前端说明](./frontend/README.md)
