package gateway

import (
	"context"
	"encoding/json"
	"errors"
	"math"
	"net/http"
	"strings"
	"time"

	accountdomain "github.com/chenyme/grok2api/backend/internal/domain/account"
	"github.com/chenyme/grok2api/backend/internal/domain/audit"
	inferencedomain "github.com/chenyme/grok2api/backend/internal/domain/inference"
	modeldomain "github.com/chenyme/grok2api/backend/internal/domain/model"
	infraegress "github.com/chenyme/grok2api/backend/internal/infra/egress"
	neterrorpkg "github.com/chenyme/grok2api/backend/internal/pkg/neterror"
)

const (
	ErrorQualityDegraded                   = "quality_degraded"
	qualityRetryFailOpen                   = "fail_open"
	qualityRetryFailClosed                 = "fail_closed"
	defaultQualityMaxAttempts              = 6
	defaultQualityHoldTimeout              = 30 * time.Second
	defaultQualityMinOutput                = int64(5)
	defaultMinEncryptedBytes               = 256
	defaultEncryptedBytesPerReasoningToken = 4
	defaultBurstFlushMS                    = int64(1000)
	defaultBurstMaxVisible                 = int64(32)
	defaultBurstMinReasoning               = int64(80)
	// Fake encrypted thinking dumps the whole visible answer after a long
	// wait. Audit TPS is rewritten against full duration (looks like 60–120
	// tok/s) but first-token ≈ duration. Catch flush windows up to 2s so
	// 1.8s / 1962-token dumps are withheld too.
	defaultFakeEncFlushMS = int64(2000)
	// Cipher-only "thinking" that is already dumping this much visible text
	// with usage.reasoning_tokens=0 is the 128k status-loop drool, not a
	// real encrypted thinking stream.
	defaultCipherDroolVisible        = int64(1024)
	defaultMissingThinkingCooldown   = 12 * time.Hour
	lastErrorMissingThinking         = accountdomain.LastErrorMissingThinking
	lastErrorMissingThinkingDisabled = accountdomain.LastErrorMissingThinkingDisabled
	// An empty stream that idles while held is treated as an account-quality
	// failure: the request can still rotate before any bytes reach the client.
	qualityIdleAccountCooldown = 15 * time.Minute
)

var (
	errQualityDegraded    = errors.New("上游响应缺少推理")
	errQualityEmptyStream = errors.New("上游流式响应为空")
)

// QualityRetryRuntime is the isolated request-path withhold/retry policy.
// Zero Enabled leaves production behavior unchanged.
type QualityRetryRuntime struct {
	Enabled         bool
	MaxAttempts     int
	HoldTimeout     time.Duration
	MinOutputTokens int64
	OnExhausted     string
	AutoDisable     bool
	AccountCooldown time.Duration
	// IdleAccountCooldown is applied to truly empty upstream streams
	// (idle timeout / empty peek). Missing-thinking still uses AccountCooldown.
	IdleAccountCooldown             time.Duration
	MinEncryptedBytes               int
	EncryptedBytesPerReasoningToken int
	SoftTPS                         float64
	HardTPS                         float64
	MinGenerationMS                 int64
	FailClosed                      bool
}

// QualityStreamSignals is the hold classifier input. Tests drive this
// directly and via ObserveQualityChunk on SSE fixtures.
type QualityStreamSignals struct {
	HasThinking       bool
	HasReasoningDelta bool
	// ReasoningStarted is an empty reasoning item or the Chat SSE stub
	// `: grok2api-reasoning-start`. That is not proof of thinking: 降智
	// still emits the stub, then dumps visible tokens with usage 0.
	ReasoningStarted bool
	VisibleTokens    int64
	ReasoningTokens  int64
	OutputTokens     int64
	EncryptedBytes   int
	EncryptedFloor   int64
	UsageReported    bool
	FirstVisible     bool
	VisibleFlushMS   int64
	Terminal         bool
	HoldExpired      bool
}

// QualityVerdict is the hold decision for one upstream stream.
type QualityVerdict string

const (
	QualityWait     QualityVerdict = "wait"
	QualityDeliver  QualityVerdict = "deliver"
	QualityWithhold QualityVerdict = "withhold"
)

// QualityRetryAction is what the attempt loop does with a withhold verdict.
type QualityRetryAction string

const (
	QualityActionDeliver     QualityRetryAction = "deliver"
	QualityActionDeliverLast QualityRetryAction = "deliver_last"
	QualityActionRetry       QualityRetryAction = "retry"
	QualityActionReject      QualityRetryAction = "reject"
)

func normalizeQualityRetry(cfg QualityRetryRuntime) QualityRetryRuntime {
	if cfg.MaxAttempts <= 0 {
		cfg.MaxAttempts = defaultQualityMaxAttempts
	}
	if cfg.HoldTimeout <= 0 {
		cfg.HoldTimeout = defaultQualityHoldTimeout
	}
	if cfg.MinOutputTokens <= 0 {
		cfg.MinOutputTokens = defaultQualityMinOutput
	}
	if cfg.AccountCooldown <= 0 {
		cfg.AccountCooldown = defaultMissingThinkingCooldown
	}
	if cfg.IdleAccountCooldown <= 0 {
		cfg.IdleAccountCooldown = qualityIdleAccountCooldown
	}
	if cfg.MinEncryptedBytes <= 0 {
		cfg.MinEncryptedBytes = defaultMinEncryptedBytes
	}
	if cfg.EncryptedBytesPerReasoningToken <= 0 {
		cfg.EncryptedBytesPerReasoningToken = defaultEncryptedBytesPerReasoningToken
	}
	if cfg.SoftTPS <= 0 {
		cfg.SoftTPS = audit.DefaultDegradeSoftTPS
	}
	if cfg.HardTPS <= cfg.SoftTPS {
		cfg.HardTPS = audit.DefaultDegradeHardTPS
	}
	if cfg.MinGenerationMS <= 0 {
		cfg.MinGenerationMS = audit.DefaultDegradeMinGenMS
	}
	cfg.OnExhausted = normalizeQualityExhaustionPolicy(cfg.OnExhausted)
	return cfg
}

func (s *Service) UpdateQualityRetry(cfg QualityRetryRuntime) {
	normalized := normalizeQualityRetry(cfg)
	s.qualityRetry.Store(&normalized)
}

func (s *Service) qualityRetryConfig() QualityRetryRuntime {
	if s == nil {
		return normalizeQualityRetry(QualityRetryRuntime{})
	}
	if value := s.qualityRetry.Load(); value != nil {
		return *value
	}
	return normalizeQualityRetry(QualityRetryRuntime{})
}

// encryptedThinkingFloor is max(minBytes, reasoningTokens*bytesPerToken).
// A non-empty stub such as "gAAAA-cipher" is not thinking.
func encryptedThinkingFloor(minBytes, bytesPerToken int, reasoningTokens int64) int64 {
	if minBytes <= 0 {
		minBytes = defaultMinEncryptedBytes
	}
	if bytesPerToken <= 0 {
		bytesPerToken = defaultEncryptedBytesPerReasoningToken
	}
	floor := int64(minBytes)
	if reasoningTokens > 0 {
		if reasoningTokens > math.MaxInt64/int64(bytesPerToken) {
			return math.MaxInt64
		}
		need := reasoningTokens * int64(bytesPerToken)
		if need > floor {
			floor = need
		}
	}
	return floor
}

func qualityFastFlush(sig QualityStreamSignals, limitMS int64) bool {
	return sig.FirstVisible && sig.VisibleFlushMS >= 0 && sig.VisibleFlushMS < limitMS
}

func qualityMeetsEncryptedFloor(sig QualityStreamSignals) bool {
	if sig.EncryptedBytes <= 0 {
		return false
	}
	floor := sig.EncryptedFloor
	if floor <= 0 {
		floor = encryptedThinkingFloor(0, 0, sig.ReasoningTokens)
	}
	return int64(sig.EncryptedBytes) >= floor
}

func qualityHasDumpBill(sig QualityStreamSignals) bool {
	return sig.ReasoningTokens >= defaultBurstMinReasoning || qualityMeetsEncryptedFloor(sig)
}

func qualityIsBurstDump(sig QualityStreamSignals, minOutput int64) bool {
	_ = minOutput
	if sig.HasReasoningDelta {
		return false
	}
	visible := sig.VisibleTokens
	heavyReasoning := sig.ReasoningTokens >= defaultBurstMinReasoning
	shortVisible := visible > 0 && visible < defaultBurstMaxVisible
	// Hold timed out, then a short greeting dumped with a large reasoning bill
	// (TUI "你好" after 30s / 954 thinking tokens).
	if sig.HoldExpired && shortVisible && heavyReasoning {
		return true
	}
	if qualityFastFlush(sig, defaultBurstFlushMS) && qualityHasDumpBill(sig) {
		return true
	}
	return false
}

// qualityIsFakeEncryptedDump is the 18190 / 18183 dump: ciphertext or a
// large reasoning bill, then the visible answer arrives in <2s. Visible
// token count is not a gate — vis<8 chat dumps were leaking on minOutput.
func qualityIsFakeEncryptedDump(sig QualityStreamSignals, minOutput int64) bool {
	_ = minOutput
	if sig.HasReasoningDelta {
		return false
	}
	if !qualityFastFlush(sig, defaultFakeEncFlushMS) {
		return false
	}
	return qualityHasDumpBill(sig)
}

// qualityIsFastReasoningRatioDump catches plaintext thinking that is still a
// 1ms dump: billed reasoning is ≥80% of output and the visible flush is <2s.
func qualityIsFastReasoningRatioDump(sig QualityStreamSignals) bool {
	if !sig.HasReasoningDelta {
		return false
	}
	if !qualityFastFlush(sig, defaultFakeEncFlushMS) {
		return false
	}
	output := sig.OutputTokens
	if output <= 0 {
		output = sig.VisibleTokens + sig.ReasoningTokens
	}
	if output <= 0 || sig.ReasoningTokens <= 0 {
		return false
	}
	return sig.ReasoningTokens*5 >= output*4
}

// qualityIsCipherDrool is the 128k TUI status-loop: ciphertext met the
// floor so HasThinking is true, but there is no plaintext reasoning and
// usage.reasoning_tokens is still 0 while visible text is already dumping.
func qualityIsCipherDrool(sig QualityStreamSignals, minOutput int64) bool {
	if minOutput <= 0 {
		minOutput = defaultQualityMinOutput
	}
	if sig.HasReasoningDelta || sig.ReasoningTokens > 0 {
		return false
	}
	if sig.EncryptedBytes <= 0 {
		return false
	}
	visible := sig.VisibleTokens
	if visible >= defaultCipherDroolVisible {
		return true
	}
	if sig.Terminal && visible >= minOutput {
		return true
	}
	return false
}

// ClassifyQualityHold decides whether a held stream may be forwarded.
// Streamed thinking delivers: reasoning/summary deltas, or a reasoning item
// whose encrypted_content meets the ciphertext floor. A non-empty stub such
// as "gAAAA-cipher" is not thinking. Usage.reasoning_tokens alone does not —
// degraded upstreams fill that field without ciphertext or deltas. A finished
// sample with enough visible output and no streamed thinking is withheld.
// Replies below minOutput are delivered; production uses 5 so output > 4 is
// withheld when no real thinking was streamed.
// A hold timeout with no visible output is not fail-open: keep waiting for
// more bytes or a stream abort so an empty hang is not flushed as HTTP 200.
//
// An empty reasoning stub is not thinking. Before the hold deadline, wait for
// real evidence or a terminal event. A stub plus enough visible output at the
// deadline is withheld — that is the TUI dump after 30s, not late ciphertext.
// Stub-only empty streams keep waiting for idle/terminal handling.
// HasThinking that is only a thin ciphertext dump after the hold is still
// withheld. Dump detectors run first so plaintext thinking cannot veto a 1ms
// reasoning-ratio dump, and vis<minOutput cannot skip fake-enc/burst.
// Dump detectors run first so plaintext thinking cannot veto a 1ms
// reasoning-ratio dump, and vis<minOutput cannot skip fake-enc/burst.
// Remaining plaintext deltas still deliver. Cipher-only HasThinking waits
// until visible text has streamed for 2s or the stream ends.
func ClassifyQualityHold(sig QualityStreamSignals, minOutput int64) QualityVerdict {
	if minOutput <= 0 {
		minOutput = defaultQualityMinOutput
	}
	if qualityIsBurstDump(sig, minOutput) || qualityIsCipherDrool(sig, minOutput) || qualityIsFakeEncryptedDump(sig, minOutput) || qualityIsFastReasoningRatioDump(sig) {
		return QualityWithhold
	}
	if sig.HasThinking {
		if sig.HasReasoningDelta {
			return QualityDeliver
		}
		// Cipher-only: do not release when encrypted_content first meets
		// the floor. Fake dumps send the blob, then the whole answer in
		// <2s; releasing early lets that dump bypass fake-enc. Wait until
		// visible text has streamed for 2s, or the stream ends.
		if sig.Terminal {
			return QualityDeliver
		}
		if sig.VisibleTokens >= minOutput && sig.FirstVisible && sig.VisibleFlushMS >= defaultFakeEncFlushMS {
			return QualityDeliver
		}
		return QualityWait
	}
	// Prefer observed/derived visible output. Total output includes reasoning
	// tokens, which are deliberately not trusted as quality evidence above. If
	// the stream exposed no visible count at all, retain OutputTokens as a
	// compatibility fallback for terminal usage-only responses.
	output := sig.VisibleTokens
	if output <= 0 {
		output = sig.OutputTokens
	}
	enough := output >= minOutput
	if sig.ReasoningStarted && !sig.Terminal && !sig.HoldExpired {
		return QualityWait
	}
	if sig.Terminal {
		if output <= 0 {
			return QualityWait
		}
		if enough {
			return QualityWithhold
		}
		return QualityDeliver
	}
	if enough {
		return QualityWithhold
	}
	if sig.HoldExpired {
		if output <= 0 {
			return QualityWait
		}
		if enough {
			return QualityWithhold
		}
		return QualityDeliver
	}
	return QualityWait
}

// qualityPeekAbortError prefers the idle-timeout cause over a plain
// context.Canceled so the attempt loop can retry instead of treating the
// abort as a client 499.
func qualityPeekAbortError(ctx context.Context, err error) error {
	if ctx != nil {
		if cause := context.Cause(ctx); neterrorpkg.IsUpstreamStreamIdleTimeout(cause) {
			return cause
		}
	}
	if neterrorpkg.IsUpstreamStreamIdleTimeout(err) {
		return err
	}
	if err != nil {
		return err
	}
	if ctx != nil {
		return ctx.Err()
	}
	return nil
}

// isClientRequestCancel reports a real client disconnect. Upstream idle
// timeouts cancel the same context and must not be classified as 499.
func isClientRequestCancel(ctx context.Context, err error) bool {
	return neterrorpkg.IsClientRequestCancel(ctx, err)
}

// DecideQualityRetry caps withhold recovery at maxAttempts (default 6:
// original + five extra accounts). The last withhold
// (attemptIndex == maxAttempts-1) is fail-open unless OnExhausted is fail_closed.
func DecideQualityRetry(verdict QualityVerdict, attemptIndex, maxAttempts int, onExhausted string) QualityRetryAction {
	if verdict != QualityWithhold {
		return QualityActionDeliver
	}
	if maxAttempts <= 0 {
		maxAttempts = defaultQualityMaxAttempts
	}
	if attemptIndex < 0 {
		attemptIndex = 0
	}
	if attemptIndex < maxAttempts-1 {
		return QualityActionRetry
	}
	// attemptIndex == maxAttempts-1 (or past it): do not retry again.
	if normalizeQualityExhaustionPolicy(onExhausted) == qualityRetryFailClosed {
		return QualityActionReject
	}
	return QualityActionDeliverLast
}

// BoundQualityRetry turns a Retry into DeliverLast/Reject when the routing
// loop has no remaining account slot, so the already-held body is not dropped
// on continue-into-exhausted-loop.
func BoundQualityRetry(action QualityRetryAction, hasNextRoutingAttempt bool, onExhausted string) QualityRetryAction {
	if action != QualityActionRetry || hasNextRoutingAttempt {
		return action
	}
	if normalizeQualityExhaustionPolicy(onExhausted) == qualityRetryFailClosed {
		return QualityActionReject
	}
	return QualityActionDeliverLast
}

func normalizeQualityExhaustionPolicy(value string) string {
	if strings.EqualFold(strings.TrimSpace(value), qualityRetryFailOpen) {
		return qualityRetryFailOpen
	}
	return qualityRetryFailClosed
}

// QualityCommit is the single attempt-loop decision for a held stream.
type QualityCommit struct {
	Action   QualityRetryAction
	Audit    bool
	KeepBody bool
}

// CommitQualityHold is the shipped withhold/retry/commit unit. The attempt
// loop must not re-derive this from Decide+Bound+switch.
func CommitQualityHold(verdict QualityVerdict, qualityAttempt, maxAttempts int, hasNextRouting bool, onExhausted string) QualityCommit {
	action := BoundQualityRetry(
		DecideQualityRetry(verdict, qualityAttempt, maxAttempts, onExhausted),
		hasNextRouting,
		onExhausted,
	)
	switch action {
	case QualityActionRetry, QualityActionReject:
		return QualityCommit{Action: action, Audit: true, KeepBody: false}
	case QualityActionDeliverLast:
		return QualityCommit{Action: action, Audit: false, KeepBody: true}
	default:
		return QualityCommit{Action: QualityActionDeliver, Audit: false, KeepBody: true}
	}
}

// shouldHoldQualityStream 仅对 Grok 4.7 的推理请求启用质量拦截。
func shouldHoldQualityStream(input Input, ownership *inferencedomain.ResponseOwnership, route modeldomain.Route, operation audit.Operation, cfg QualityRetryRuntime) bool {
	if !cfg.Enabled || !input.Streaming || input.ForcedEgressNodeID != 0 || input.skipQualityHold {
		return false
	}
	switch operation {
	case audit.OperationChat, audit.OperationResponses, audit.OperationMessages, "":
	default:
		return false
	}
	// Context compaction is a system summary operation, not a normal reasoning
	// turn. Holding it can quarantine a healthy account for producing the
	// expected summary without streamed reasoning. Keep both compaction forms
	// excluded even if a caller reaches this gate without skipQualityHold.
	if isResponsesCompactionRequest(input.Body) {
		return false
	}
	if route.Provider != accountdomain.ProviderBuild && route.Provider != accountdomain.ProviderConsole {
		return false
	}
	if !modeldomain.IsGrok47LLM(route.UpstreamModel) {
		return false
	}
	// TUI commonly declares tools and follow-ups carry previous_response_id.
	// They still need quality classification, but replay safety is decided
	// separately: detecting a degraded response must not imply that an
	// account-bound or side-effecting request can run on another account.
	if qualityRequestDisablesReasoning(input.Body) {
		return false
	}
	if modeldomain.SupportsReasoningForProvider(route.Provider, input.PublicModel) {
		return true
	}
	return modeldomain.SupportsReasoningForProvider(route.Provider, route.UpstreamModel)
}

// canReplayQualityHoldAcrossAccounts separates response classification from
// retry authority. Stored Responses are account-bound, while hosted tools may
// already have produced an external side effect before their held response is
// rejected. Both may be held, audited, and penalized, but neither is replayed
// on another account.
func canReplayQualityHoldAcrossAccounts(input Input, ownership *inferencedomain.ResponseOwnership) bool {
	return ownership == nil && !qualityRequestHasReplayUnsafeHostedTools(input.Body)
}

func qualityRequestHasReplayUnsafeHostedTools(body []byte) bool {
	var payload map[string]any
	if json.Unmarshal(body, &payload) != nil || payload == nil {
		return false
	}
	if raw, exists := payload["web_search_options"]; exists && raw != nil {
		return true
	}
	if raw, exists := payload["mcp_servers"]; exists && raw != nil {
		servers, ok := raw.([]any)
		if !ok || len(servers) > 0 {
			return true
		}
	}
	if qualityToolListHasReplayUnsafeHostedTool(payload["tools"]) {
		return true
	}
	// Responses Tool Search can load declarations later in the request. Only
	// inspect additional_tools items; arbitrary user/schema objects may also
	// contain a field named "tools" and must not affect the retry policy.
	items, _ := payload["input"].([]any)
	for _, rawItem := range items {
		item, ok := rawItem.(map[string]any)
		if !ok || jsonNodeString(item["type"]) != "additional_tools" {
			continue
		}
		if qualityToolListHasReplayUnsafeHostedTool(item["tools"]) {
			return true
		}
	}
	return false
}

func qualityToolListHasReplayUnsafeHostedTool(value any) bool {
	tools, ok := value.([]any)
	if !ok {
		return false
	}
	for _, rawTool := range tools {
		tool, ok := rawTool.(map[string]any)
		if !ok {
			continue
		}
		kind := jsonNodeString(tool["type"])
		switch kind {
		case "", "function", "custom", "local_shell", "apply_patch", "tool_search":
			// These declarations only ask the model to return a call. Execution
			// happens in the client after the held response is committed.
			continue
		case "shell":
			environment, _ := tool["environment"].(map[string]any)
			if jsonNodeString(environment["type"]) != "local" {
				return true
			}
		case "namespace":
			if qualityToolListHasReplayUnsafeHostedTool(tool["tools"]) {
				return true
			}
		default:
			// Default to no replay for every server/native tool, including types
			// added by future protocol versions that this gateway does not know yet.
			return true
		}
	}
	return false
}

func jsonNodeString(value any) string {
	text, _ := value.(string)
	return strings.ToLower(strings.TrimSpace(text))
}

func qualityRequestDisablesReasoning(body []byte) bool {
	var payload map[string]json.RawMessage
	if json.Unmarshal(body, &payload) != nil {
		return false
	}
	if jsonStringEquals(payload["reasoning_effort"], modeldomain.ReasoningEffortNone) {
		return true
	}
	for _, key := range []string{"reasoning", "output_config", "thinking"} {
		var nested map[string]json.RawMessage
		if json.Unmarshal(payload[key], &nested) != nil {
			continue
		}
		if jsonStringEquals(nested["effort"], modeldomain.ReasoningEffortNone) || jsonStringEquals(nested["type"], "disabled") {
			return true
		}
		var budget int64
		if raw, ok := nested["budget_tokens"]; ok && json.Unmarshal(raw, &budget) == nil && budget == 0 {
			return true
		}
	}
	return jsonStringEquals(payload["thinking"], "disabled")
}

func jsonStringEquals(raw json.RawMessage, want string) bool {
	var value string
	return json.Unmarshal(raw, &value) == nil && strings.EqualFold(strings.TrimSpace(value), want)
}

func (s *Service) applyMissingThinkingPenalty(ctx context.Context, requestID string, credential accountdomain.Credential, cooldown time.Duration, autoDisable bool) {
	writeCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), finalizationTimeout)
	defer cancel()
	action, err := s.selector.markMissingThinking(writeCtx, credential, cooldown, autoDisable)
	if err != nil {
		s.logger.Error("quality_degraded_penalty_failed", "request_id", requestID, "account_id", credential.ID, "action", action, "error", err)
		return
	}
	switch action {
	case missingThinkingPenaltyDisabled:
		s.logger.Info("quality_degraded_disabled", "request_id", requestID, "account_id", credential.ID)
	case missingThinkingPenaltyCooled:
		s.logger.Info("quality_degraded_cooldown", "request_id", requestID, "account_id", credential.ID, "cooldown", cooldown.String())
	}
}

func (s *Service) applyOutputSpeedPenalty(ctx context.Context, record audit.Record, credential accountdomain.Credential, cfg QualityRetryRuntime, forcedEgress bool) error {
	// Both explicit and TUI compaction are classified in the audit record.
	// System summaries stay exempt from account quality penalties.
	if record.Operation == audit.OperationCompaction {
		return nil
	}
	if !cfg.Enabled || !cfg.AutoDisable || forcedEgress || credential.Provider != accountdomain.ProviderBuild || !record.Streaming || record.FirstTokenMS == nil || record.OutputTokens < cfg.MinOutputTokens || !auditRequestSucceeded(record.StatusCode, record.ErrorCode) {
		return nil
	}
	class, tps, _ := audit.ClassifyOutputSpeed(record.OutputTokens, record.ReasoningTokens, *record.FirstTokenMS, record.DurationMS, cfg.SoftTPS, cfg.HardTPS, cfg.MinGenerationMS, cfg.FailClosed)
	if class == "" {
		return nil
	}
	if err := s.selector.disableAccount(ctx, credential); err != nil {
		return err
	}
	s.logger.Info("quality_degraded_disabled", "request_id", record.RequestID, "account_id", credential.ID, "class", class, "output_tps", tps)
	return nil
}

func (s *Service) recordQualityDegraded(ctx context.Context, base audit.Record, credential accountdomain.Credential, usage Usage, startedAt time.Time, trace *infraegress.Trace, provider accountdomain.Provider) {
	record := base
	record.EventID = newAuditEventID()
	accountID := credential.ID
	record.AccountID = &accountID
	record.AccountName = credential.Name
	record.StatusCode = http.StatusOK
	record.ErrorCode = ErrorQualityDegraded
	record.OutputTokens = usage.OutputTokens
	record.ReasoningTokens = usage.ReasoningTokens
	record.TotalTokens = usage.TotalTokens
	record.InputTokens = usage.InputTokens
	if usage.Reported {
		record.UsageSource = audit.UsageSourceUpstream
	}
	record.DurationMS = time.Since(startedAt).Milliseconds()
	record.CreatedAt = time.Now().UTC()
	applyAuditEgress(&record, trace, provider)
	writeCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), finalizationTimeout)
	defer cancel()
	if err := s.audits.Create(writeCtx, record); err != nil {
		s.logger.Error("quality_degraded_audit_failed", "event_id", record.EventID, "request_id", record.RequestID, "error", err)
	}
}
