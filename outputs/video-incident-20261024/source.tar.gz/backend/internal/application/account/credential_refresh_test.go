package account

import (
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	accountdomain "github.com/chenyme/grok2api/backend/internal/domain/account"
	"github.com/chenyme/grok2api/backend/internal/infra/persistence/relational"
	"github.com/chenyme/grok2api/backend/internal/infra/provider"
	"github.com/chenyme/grok2api/backend/internal/infra/runtime/memory"
	"github.com/chenyme/grok2api/backend/internal/repository"
)

func TestEnsureCredentialReusesRotatedTokenAndThrottlesForcedRefresh(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }

	first, err := service.EnsureCredential(ctx, credential, true)
	if err != nil {
		t.Fatal(err)
	}
	if adapter.refreshCount.Load() != 1 || first.EncryptedAccessToken != "access-1" {
		t.Fatalf("first refresh = %#v, count = %d", first, adapter.refreshCount.Load())
	}

	fromStaleRequest, err := service.EnsureCredential(ctx, credential, true)
	if err != nil {
		t.Fatal(err)
	}
	if adapter.refreshCount.Load() != 1 || fromStaleRequest.EncryptedAccessToken != first.EncryptedAccessToken {
		t.Fatalf("stale request caused another refresh: count = %d", adapter.refreshCount.Load())
	}

	duringCooldown, err := service.EnsureCredential(ctx, first, true)
	if err != nil {
		t.Fatal(err)
	}
	if adapter.refreshCount.Load() != 1 || duringCooldown.EncryptedAccessToken != first.EncryptedAccessToken {
		t.Fatalf("forced refresh cooldown failed: count = %d", adapter.refreshCount.Load())
	}

	now = now.Add(forcedRefreshMinInterval + time.Second)
	afterCooldown, err := service.EnsureCredential(ctx, first, true)
	if err != nil {
		t.Fatal(err)
	}
	if adapter.refreshCount.Load() != 2 || afterCooldown.EncryptedAccessToken != "access-2" {
		t.Fatalf("refresh after cooldown = %#v, count = %d", afterCooldown, adapter.refreshCount.Load())
	}

	manual, err := service.ensureCredential(ctx, afterCooldown, ensureCredentialOptions{force: true, bypassCooldown: true, retryPermanentOnce: true})
	if err != nil {
		t.Fatal(err)
	}
	if adapter.refreshCount.Load() != 3 || manual.EncryptedAccessToken != "access-3" {
		t.Fatalf("manual refresh did not bypass cooldown: count = %d", adapter.refreshCount.Load())
	}
}

func TestEnsureCredentialPreservesBotFlagWhenRefreshedTokenCannotBeInspected(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, credential, _ := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	credential.BuildBotFlagSource = 2
	credential, err := service.accounts.Update(ctx, credential)
	if err != nil {
		t.Fatal(err)
	}
	refreshed, err := service.EnsureCredential(ctx, credential, true)
	if err != nil {
		t.Fatal(err)
	}
	if refreshed.BuildBotFlagSource != 2 {
		t.Fatalf("refreshed source = %d, want preserved source 2", refreshed.BuildBotFlagSource)
	}
}

func TestEnsureCredentialPersistsRotatedTokenAfterRequestCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	adapter.afterRefresh = cancel

	refreshed, err := service.EnsureCredential(ctx, credential, true)
	if err != nil {
		t.Fatalf("refresh after request cancellation = %v", err)
	}
	if refreshed.EncryptedAccessToken != "access-1" || refreshed.EncryptedRefreshToken != "refresh-1" {
		t.Fatalf("refreshed credential = %#v", refreshed)
	}
	stored, err := service.accounts.Get(context.Background(), credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if stored.EncryptedAccessToken != "access-1" || stored.EncryptedRefreshToken != "refresh-1" || stored.LastRefreshAt == nil {
		t.Fatalf("rotated credential was not persisted: %#v", stored)
	}
}

func TestEnsureCredentialCollapsesConcurrentForcedRefreshes(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	adapter.delay = 30 * time.Millisecond

	const callers = 20
	start := make(chan struct{})
	errors := make(chan error, callers)
	var workers sync.WaitGroup
	workers.Add(callers)
	for range callers {
		go func() {
			defer workers.Done()
			<-start
			value, err := service.EnsureCredential(ctx, credential, true)
			if err == nil && value.EncryptedAccessToken != "access-1" {
				err = fmt.Errorf("access token = %q", value.EncryptedAccessToken)
			}
			errors <- err
		}()
	}
	close(start)
	workers.Wait()
	close(errors)
	for err := range errors {
		if err != nil {
			t.Fatal(err)
		}
	}
	if adapter.refreshCount.Load() != 1 {
		t.Fatalf("refresh count = %d", adapter.refreshCount.Load())
	}
}

func TestEnsureCredentialCollapsesRefreshAcrossServiceInstances(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	database, err := relational.OpenSQLite(ctx, filepath.Join(t.TempDir(), "credential-refresh-multi-instance.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer database.Close()
	if err := database.InitializeSchema(ctx); err != nil {
		t.Fatal(err)
	}
	repository := relational.NewAccountRepository(database)
	credential, _, err := repository.UpsertByIdentity(ctx, accountdomain.Credential{
		Provider: accountdomain.ProviderBuild, Name: "multi-instance", SourceKey: "multi-instance",
		EncryptedAccessToken: "access-0", EncryptedRefreshToken: "refresh-0", ExpiresAt: now.Add(time.Hour),
		Enabled: true, AuthStatus: accountdomain.AuthStatusActive, MaxConcurrent: 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	adapter := &credentialRefreshAdapter{delay: 40 * time.Millisecond}
	registry := provider.NewRegistry(adapter)
	lock := memory.NewLockStore()
	first := NewService(repository, nil, nil, nil, registry, nil, lock)
	second := NewService(repository, nil, nil, nil, registry, nil, lock)
	start := make(chan struct{})
	errors := make(chan error, 2)
	for _, service := range []*Service{first, second} {
		go func(service *Service) {
			<-start
			_, refreshErr := service.EnsureCredential(ctx, credential, true)
			errors <- refreshErr
		}(service)
	}
	close(start)
	for range 2 {
		if err := <-errors; err != nil {
			t.Fatal(err)
		}
	}
	if adapter.refreshCount.Load() != 1 {
		t.Fatalf("refresh count = %d", adapter.refreshCount.Load())
	}
}

func TestEnsureCredentialRefreshesWhenAccessTokenIsMissing(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	credential, err := service.accounts.UpdateTokens(ctx, credential.ID, "", "refresh-only", now.Add(time.Hour), 0)
	if err != nil {
		t.Fatal(err)
	}

	refreshed, err := service.EnsureCredential(ctx, credential, false)
	if err != nil {
		t.Fatal(err)
	}
	if adapter.refreshCount.Load() != 1 || refreshed.EncryptedAccessToken != "access-1" {
		t.Fatalf("refresh-only credential was not refreshed: %#v, count = %d", refreshed, adapter.refreshCount.Load())
	}
}

func TestCredentialRefreshSchedulerRefreshesOnlyDueAccounts(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return time.Now().UTC() }
	dueAt := now.Add(-time.Minute)
	credential.RefreshDueAt = &dueAt
	credential, err := service.accounts.Update(ctx, credential)
	if err != nil {
		t.Fatal(err)
	}
	far, _, err := service.accounts.UpsertByIdentity(ctx, accountdomain.Credential{
		Provider: accountdomain.ProviderBuild, Name: "far", SourceKey: "far",
		EncryptedAccessToken: "far-access", EncryptedRefreshToken: "far-refresh", ExpiresAt: now.Add(6 * time.Hour),
		Enabled: true, AuthStatus: accountdomain.AuthStatusActive, MaxConcurrent: 1,
	})
	if err != nil {
		t.Fatal(err)
	}

	runCtx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		service.RunCredentialRefresh(runCtx)
		close(done)
	}()
	t.Cleanup(func() {
		cancel()
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Fatal("credential refresh scheduler did not stop")
		}
	})

	deadline := time.Now().Add(2 * time.Second)
	var updated accountdomain.Credential
	for time.Now().Before(deadline) {
		updated, err = service.accounts.Get(ctx, credential.ID)
		if err == nil && adapter.refreshCount.Load() == 1 && updated.LastRefreshAt != nil && updated.RefreshFailureCount == 0 {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if adapter.refreshCount.Load() != 1 {
		t.Fatalf("refresh count = %d", adapter.refreshCount.Load())
	}
	if err != nil {
		t.Fatal(err)
	}
	if updated.RefreshDueAt == nil || !updated.RefreshDueAt.After(time.Now()) || updated.LastRefreshAt == nil || updated.RefreshFailureCount != 0 {
		t.Fatalf("updated credential = %#v", updated)
	}
	farUpdated, err := service.accounts.Get(ctx, far.ID)
	if err != nil {
		t.Fatal(err)
	}
	if farUpdated.EncryptedAccessToken != "far-access" || farUpdated.LastRefreshAt != nil {
		t.Fatalf("far credential was refreshed: %#v", farUpdated)
	}
}

func TestStartupRecoveryPreservesFutureRefreshSchedule(t *testing.T) {
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	originalDue := credential.RefreshDueAt

	report, err := service.RecoverCriticalCredentials(context.Background(), 2*time.Minute, 100)
	if err != nil {
		t.Fatal(err)
	}
	if report.CriticalFound != 0 || adapter.refreshCount.Load() != 0 {
		t.Fatalf("report=%#v refreshes=%d", report, adapter.refreshCount.Load())
	}
	stored, err := service.accounts.Get(context.Background(), credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if originalDue == nil || stored.RefreshDueAt == nil || !stored.RefreshDueAt.Equal(*originalDue) {
		t.Fatalf("refresh due changed: before=%v after=%v", originalDue, stored.RefreshDueAt)
	}
}

func TestStartupRecoveryRefreshesExpiredCredential(t *testing.T) {
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	expired, err := service.accounts.UpdateTokens(context.Background(), credential.ID, credential.EncryptedAccessToken, credential.EncryptedRefreshToken, now.Add(-time.Minute), 0)
	if err != nil {
		t.Fatal(err)
	}
	if expired.RefreshDueAt == nil || expired.RefreshDueAt.After(now) {
		t.Fatalf("expired refresh due = %v", expired.RefreshDueAt)
	}

	report, err := service.RecoverCriticalCredentials(context.Background(), 2*time.Minute, 100)
	if err != nil {
		t.Fatal(err)
	}
	if report.CriticalFound != 1 || report.Refreshed != 1 || report.Failed != 0 || adapter.refreshCount.Load() != 1 {
		t.Fatalf("report=%#v refreshes=%d", report, adapter.refreshCount.Load())
	}
}

func TestStartupRecoveryRespectsContextBudget(t *testing.T) {
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	if _, err := service.accounts.UpdateTokens(context.Background(), credential.ID, credential.EncryptedAccessToken, credential.EncryptedRefreshToken, now.Add(-time.Minute), 0); err != nil {
		t.Fatal(err)
	}
	adapter.delay = time.Second
	ctx, cancel := context.WithTimeout(context.Background(), 25*time.Millisecond)
	defer cancel()
	started := time.Now()
	_, err := service.RecoverCriticalCredentials(ctx, 2*time.Minute, 100)
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("err = %v", err)
	}
	if elapsed := time.Since(started); elapsed > 250*time.Millisecond {
		t.Fatalf("startup recovery exceeded budget: %s", elapsed)
	}
}

func TestCredentialRefreshDueQueryStaysBoundedForLargePool(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, _, _ := newCredentialRefreshTestService(t, now)
	values := make([]accountdomain.Credential, 0, 1000)
	for index := range 1000 {
		name := fmt.Sprintf("large-%04d", index)
		values = append(values, accountdomain.Credential{
			Provider: accountdomain.ProviderBuild, Name: name, SourceKey: name,
			EncryptedAccessToken: "access", EncryptedRefreshToken: "refresh", ExpiresAt: now.Add(time.Minute),
			Enabled: true, AuthStatus: accountdomain.AuthStatusActive, MaxConcurrent: 1,
		})
	}
	if _, err := service.accounts.UpsertManyByIdentity(ctx, values); err != nil {
		t.Fatal(err)
	}
	ids, err := service.accounts.ListDueCredentialRefreshIDs(ctx, now, credentialRefreshBatchSize)
	if err != nil {
		t.Fatal(err)
	}
	if len(ids) != credentialRefreshBatchSize {
		t.Fatalf("due batch size = %d", len(ids))
	}
	next, err := service.accounts.NextCredentialRefreshDueAt(ctx)
	if err != nil || next == nil || next.After(now) {
		t.Fatalf("next due = %v, err = %v", next, err)
	}
}

func TestCredentialRefreshFailureDistinguishesTransientAndPermanent(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }

	adapter.refreshErr = &provider.CredentialRefreshError{Status: 503, Code: "oauth_unavailable", Message: "Please retry later", Response: `{"error":"oauth_unavailable","message":"Please retry later"}`}
	if _, err := service.EnsureCredential(ctx, credential, true); err == nil {
		t.Fatal("transient refresh unexpectedly succeeded")
	}
	transient, err := service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if transient.AuthStatus != accountdomain.AuthStatusActive || transient.RefreshFailureCount != 1 || transient.LastRefreshErrorStatus != 503 || transient.LastRefreshErrorCode != "oauth_unavailable" || transient.LastRefreshErrorMessage != "Please retry later" || transient.LastRefreshErrorResponse == "" || transient.RefreshPermanent || transient.RefreshDueAt == nil || !transient.RefreshDueAt.After(now) {
		t.Fatalf("transient state = %#v", transient)
	}

	service.clearRefreshState(credential.ID)
	adapter.refreshErr = &provider.CredentialRefreshError{Status: 400, Code: "invalid_grant", Message: "Refresh token has expired", Response: `{"error":"invalid_grant","error_description":"Refresh token has expired"}`, Permanent: true}
	if _, err := service.EnsureCredential(ctx, transient, true); err == nil {
		t.Fatal("permanent refresh unexpectedly succeeded")
	}
	permanent, err := service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if permanent.AuthStatus != accountdomain.AuthStatusActive || permanent.RefreshFailureCount != 2 || permanent.LastRefreshErrorStatus != 400 || permanent.LastRefreshErrorCode != "invalid_grant" || permanent.LastRefreshErrorMessage != "Refresh token has expired" || permanent.LastRefreshErrorResponse == "" || !permanent.RefreshPermanent || permanent.RefreshDueAt == nil || !permanent.RefreshDueAt.Equal(permanent.ExpiresAt) {
		t.Fatalf("permanent with valid token should stay active: %#v", permanent)
	}
	dueIDs, err := service.accounts.ListDueCredentialRefreshIDs(ctx, now, credentialRefreshBatchSize)
	if err != nil {
		t.Fatal(err)
	}
	if len(dueIDs) != 0 {
		t.Fatalf("permanent refresh failure remained immediately due: %#v", dueIDs)
	}
	dueAtExpiry, err := service.accounts.ListDueCredentialRefreshIDs(ctx, permanent.ExpiresAt, credentialRefreshBatchSize)
	if err != nil {
		t.Fatal(err)
	}
	if len(dueAtExpiry) != 1 || dueAtExpiry[0] != credential.ID {
		t.Fatalf("permanent refresh failure was not scheduled at expiry: %#v", dueAtExpiry)
	}
	refreshCount := adapter.refreshCount.Load()
	service.now = func() time.Time { return permanent.ExpiresAt.Add(-time.Minute) }
	usable, err := service.EnsureCredential(ctx, permanent, false)
	if err != nil {
		t.Fatalf("valid access token was rejected after permanent refresh failure: %v", err)
	}
	if usable.EncryptedAccessToken != permanent.EncryptedAccessToken || adapter.refreshCount.Load() != refreshCount {
		t.Fatalf("usable token = %#v, refresh count = %d", usable, adapter.refreshCount.Load())
	}
	service.now = func() time.Time { return now }
	if _, err := service.EnsureCredential(ctx, permanent, true); err == nil {
		t.Fatal("forced retry after permanent failure unexpectedly succeeded")
	}
	permanent, err = service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if !permanent.RefreshPermanent || permanent.RefreshDueAt == nil || !permanent.RefreshDueAt.Equal(permanent.ExpiresAt) || adapter.refreshCount.Load() != refreshCount {
		t.Fatalf("permanent refresh state retried or changed: %#v, refresh count = %d", permanent, adapter.refreshCount.Load())
	}

	service.clearRefreshState(credential.ID)
	expiredCredential := permanent
	expiredCredential.ExpiresAt = now.Add(-time.Minute)
	if _, err := service.accounts.UpdateTokens(ctx, permanent.ID, permanent.EncryptedAccessToken, permanent.EncryptedRefreshToken, expiredCredential.ExpiresAt, 0); err != nil {
		t.Fatal(err)
	}
	adapter.refreshErr = &provider.CredentialRefreshError{Status: 400, Code: "invalid_grant", Permanent: true}
	expiredState, _ := service.accounts.Get(ctx, credential.ID)
	if expiredState.RefreshPermanent {
		t.Fatalf("token update did not clear permanent refresh failure: %#v", expiredState)
	}
	if _, err := service.EnsureCredential(ctx, expiredState, true); err == nil {
		t.Fatal("permanent refresh with expired token unexpectedly succeeded")
	}
	finalState, err := service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if finalState.AuthStatus != accountdomain.AuthStatusReauthRequired {
		t.Fatalf("permanent with expired token should be reauthRequired: %#v", finalState)
	}
	manualCount := adapter.refreshCount.Load()
	manualOptions := ensureCredentialOptions{force: true, bypassCooldown: true, retryPermanentOnce: true}
	if _, err := service.ensureCredential(ctx, finalState, manualOptions); err == nil {
		t.Fatal("manual retry should surface the repeated invalid_grant")
	}
	if adapter.refreshCount.Load() != manualCount+1 {
		t.Fatalf("manual retry did not issue exactly one oauth request: before=%d after=%d", manualCount, adapter.refreshCount.Load())
	}
	adapter.refreshErr = nil
	latest, err := service.accounts.Get(ctx, finalState.ID)
	if err != nil {
		t.Fatal(err)
	}
	recovered, err := service.ensureCredential(ctx, latest, manualOptions)
	if err != nil {
		t.Fatalf("manual retry did not recover credential: %v", err)
	}
	if recovered.AuthStatus != accountdomain.AuthStatusActive || recovered.RefreshPermanent || recovered.LastRefreshErrorCode != "" {
		t.Fatalf("manual recovery state = %#v", recovered)
	}
}

func TestCredentialRefreshRejectsFalsePermanentClassification(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now.Add(2 * time.Hour) }
	adapter.refreshErr = &provider.CredentialRefreshError{Status: 401, Code: "invalid_client", Message: "Client authentication failed", Permanent: true}

	current := credential
	for attempt := 0; attempt < credentialUnclassifiedAuthLimit+1; attempt++ {
		service.clearRefreshState(credential.ID)
		if _, err := service.EnsureCredential(ctx, current, true); err == nil {
			t.Fatal("refresh unexpectedly succeeded")
		}
		var err error
		current, err = service.accounts.Get(ctx, credential.ID)
		if err != nil {
			t.Fatal(err)
		}
	}
	if current.RefreshPermanent || current.RefreshUnclassifiedAuthCount != 0 || current.AuthStatus != accountdomain.AuthStatusActive || current.RefreshDueAt == nil || current.RefreshDueAt.Before(service.now().Add(credentialConfigurationRetry)) {
		t.Fatalf("configuration error was treated as an account rejection: %#v", current)
	}
}

func TestCredentialRefreshConvergesRepeatedUnclassifiedAuthRejectionAfterExpiry(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	adapter.refreshErr = &provider.CredentialRefreshError{Status: 401, Code: "oauth_http_401", Message: "Unauthorized"}

	current := credential
	for attempt := 1; attempt <= credentialUnclassifiedAuthLimit; attempt++ {
		service.clearRefreshState(credential.ID)
		if _, err := service.EnsureCredential(ctx, current, true); err == nil {
			t.Fatalf("refresh attempt %d unexpectedly succeeded", attempt)
		}
		var err error
		current, err = service.accounts.Get(ctx, credential.ID)
		if err != nil {
			t.Fatal(err)
		}
		if current.AuthStatus != accountdomain.AuthStatusActive || current.RefreshPermanent || current.RefreshUnclassifiedAuthCount != attempt {
			t.Fatalf("attempt %d state = %#v", attempt, current)
		}
	}

	service.now = func() time.Time { return credential.ExpiresAt.Add(time.Minute) }
	service.clearRefreshState(credential.ID)
	if _, err := service.EnsureCredential(ctx, current, true); err == nil {
		t.Fatal("expired unclassified rejection unexpectedly succeeded")
	}
	converged, err := service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if converged.AuthStatus != accountdomain.AuthStatusReauthRequired || converged.RefreshPermanent || converged.RefreshUnclassifiedAuthCount != credentialUnclassifiedAuthLimit+1 {
		t.Fatalf("unclassified rejection did not converge safely: %#v", converged)
	}

	adapter.refreshErr = nil
	service.clearRefreshState(credential.ID)
	recovered, err := service.ensureCredential(ctx, converged, ensureCredentialOptions{force: true, bypassCooldown: true, retryPermanentOnce: true})
	if err != nil {
		t.Fatalf("manual refresh did not recover unclassified reauth state: %v", err)
	}
	if recovered.AuthStatus != accountdomain.AuthStatusActive || recovered.RefreshPermanent || recovered.RefreshUnclassifiedAuthCount != 0 {
		t.Fatalf("manual recovery state = %#v", recovered)
	}
}

func TestCredentialRefreshUnclassifiedAuthCountResetsOnDifferentFailureAndSuccess(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	current := credential

	adapter.refreshErr = &provider.CredentialRefreshError{Status: 400, Code: "oauth_http_400"}
	for attempt := 1; attempt <= 2; attempt++ {
		service.clearRefreshState(credential.ID)
		if _, err := service.EnsureCredential(ctx, current, true); err == nil {
			t.Fatal("unclassified refresh unexpectedly succeeded")
		}
		var err error
		current, err = service.accounts.Get(ctx, credential.ID)
		if err != nil {
			t.Fatal(err)
		}
	}
	if current.RefreshUnclassifiedAuthCount != 2 {
		t.Fatalf("unclassified count = %d", current.RefreshUnclassifiedAuthCount)
	}

	adapter.refreshErr = &provider.CredentialRefreshError{Status: 503, Code: "temporarily_unavailable"}
	service.clearRefreshState(credential.ID)
	if _, err := service.EnsureCredential(ctx, current, true); err == nil {
		t.Fatal("transient refresh unexpectedly succeeded")
	}
	var err error
	current, err = service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if current.RefreshUnclassifiedAuthCount != 0 || current.AuthStatus != accountdomain.AuthStatusActive {
		t.Fatalf("different failure did not reset unclassified count: %#v", current)
	}

	adapter.refreshErr = &provider.CredentialRefreshError{Status: 400, Code: "oauth_http_400"}
	service.clearRefreshState(credential.ID)
	if _, err := service.EnsureCredential(ctx, current, true); err == nil {
		t.Fatal("unclassified refresh unexpectedly succeeded")
	}
	current, err = service.accounts.Get(ctx, credential.ID)
	if err != nil {
		t.Fatal(err)
	}
	if current.RefreshUnclassifiedAuthCount != 1 {
		t.Fatalf("new unclassified sequence count = %d", current.RefreshUnclassifiedAuthCount)
	}

	adapter.refreshErr = nil
	service.clearRefreshState(credential.ID)
	recovered, err := service.EnsureCredential(ctx, current, true)
	if err != nil {
		t.Fatalf("successful refresh failed: %v", err)
	}
	if recovered.RefreshUnclassifiedAuthCount != 0 || recovered.RefreshFailureCount != 0 || recovered.AuthStatus != accountdomain.AuthStatusActive {
		t.Fatalf("successful refresh did not clear rejection state: %#v", recovered)
	}
}

func TestHistoricalNonTerminalPermanentStateCanRefreshAgain(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	if err := service.accounts.UpdateCredentialRefreshFailure(ctx, credential.ID, repository.CredentialRefreshFailure{
		Count: 1, RetryAt: now, Status: 400, Code: "oauth_http_400", Message: "historical status-only classification", Permanent: true,
	}); err != nil {
		t.Fatal(err)
	}
	stuck, err := service.accounts.Get(ctx, credential.ID)
	if err != nil || !stuck.RefreshPermanent {
		t.Fatalf("historical state = %#v err=%v", stuck, err)
	}

	recovered, err := service.EnsureCredential(ctx, stuck, true)
	if err != nil {
		t.Fatalf("historical non-terminal state did not retry: %v", err)
	}
	if recovered.RefreshPermanent || recovered.LastRefreshErrorCode != "" || adapter.refreshCount.Load() != 1 {
		t.Fatalf("recovered credential = %#v count=%d", recovered, adapter.refreshCount.Load())
	}
}

func TestCredentialDecryptFailedAllowsRetryAfterKeyRecovery(t *testing.T) {
	ctx := context.Background()
	now := time.Now().UTC()
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }

	// 旧行为会把 decrypt_failed 标 permanent；模拟已落库的 permanent 状态。
	if err := service.accounts.UpdateCredentialRefreshFailure(ctx, credential.ID, repository.CredentialRefreshFailure{Count: 1, RetryAt: now.Add(time.Hour), Code: "credential_decrypt_failed", Message: "Stored credential could not be decrypted", Permanent: true}); err != nil {
		t.Fatal(err)
	}
	stuck, err := service.accounts.Get(ctx, credential.ID)
	if err != nil || !stuck.RefreshPermanent || stuck.LastRefreshErrorCode != "credential_decrypt_failed" {
		t.Fatalf("setup stuck state = %#v err=%v", stuck, err)
	}

	// 密钥恢复后：手动 force 必须能再次发起刷新。
	adapter.refreshErr = nil
	service.clearRefreshState(credential.ID)
	recovered, err := service.EnsureCredential(ctx, stuck, true)
	if err != nil {
		t.Fatalf("force refresh after decrypt_failed should retry: %v", err)
	}
	if recovered.RefreshPermanent || recovered.LastRefreshErrorStatus != 0 || recovered.LastRefreshErrorCode != "" || recovered.LastRefreshErrorMessage != "" || recovered.LastRefreshErrorResponse != "" || adapter.refreshCount.Load() < 1 {
		t.Fatalf("decrypt_failed was not cleared after successful refresh: %#v count=%d", recovered, adapter.refreshCount.Load())
	}

	// invalid_grant 仍须保持永久阻断。
	service.clearRefreshState(credential.ID)
	adapter.refreshErr = &provider.CredentialRefreshError{Status: 400, Code: "invalid_grant", Permanent: true}
	if _, err := service.EnsureCredential(ctx, recovered, true); err == nil {
		t.Fatal("invalid_grant should fail")
	}
	blocked, err := service.accounts.Get(ctx, credential.ID)
	if err != nil || !blocked.RefreshPermanent || blocked.LastRefreshErrorCode != "invalid_grant" {
		t.Fatalf("invalid_grant permanent state = %#v err=%v", blocked, err)
	}
	// force 也不得再打 OAuth（真正永久）
	count := adapter.refreshCount.Load()
	if _, err := service.EnsureCredential(ctx, blocked, true); err == nil {
		t.Fatal("invalid_grant force should still be blocked")
	}
	if adapter.refreshCount.Load() != count {
		t.Fatalf("invalid_grant forced another oauth call: before=%d after=%d", count, adapter.refreshCount.Load())
	}
}

func TestRefreshAllTokensSkipsUnrefreshableAccounts(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, _, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	for _, value := range []accountdomain.Credential{
		{Provider: accountdomain.ProviderBuild, Name: "refreshable-2", SourceKey: "refreshable-2", EncryptedAccessToken: "access-2", EncryptedRefreshToken: "refresh-2", ExpiresAt: now.Add(time.Hour), Enabled: true, AuthStatus: accountdomain.AuthStatusActive},
		{Provider: accountdomain.ProviderBuild, Name: "not-refreshable", SourceKey: "not-refreshable", EncryptedAccessToken: "access-3", ExpiresAt: now.Add(time.Hour), Enabled: true, AuthStatus: accountdomain.AuthStatusActive},
	} {
		if _, _, err := service.accounts.UpsertByIdentity(ctx, value); err != nil {
			t.Fatal(err)
		}
	}
	invalid, _, err := service.accounts.UpsertByIdentity(ctx, accountdomain.Credential{
		Provider: accountdomain.ProviderBuild, Name: "invalid-refreshable", SourceKey: "invalid-refreshable",
		EncryptedAccessToken: "access-invalid", EncryptedRefreshToken: "refresh-invalid", ExpiresAt: now.Add(time.Hour), Enabled: true, AuthStatus: accountdomain.AuthStatusActive,
	})
	if err != nil {
		t.Fatal(err)
	}
	invalid.AuthStatus = accountdomain.AuthStatusReauthRequired
	if _, err := service.accounts.Update(ctx, invalid); err != nil {
		t.Fatal(err)
	}

	progress := make([][2]int, 0, 4)
	succeeded, failed, skipped, err := service.RefreshAllTokensWithProgress(ctx, func(completed, total int) error {
		progress = append(progress, [2]int{completed, total})
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	if succeeded != 3 || failed != 0 || skipped != 1 || adapter.refreshCount.Load() != 3 {
		t.Fatalf("result = %d/%d/%d, refresh count = %d", succeeded, failed, skipped, adapter.refreshCount.Load())
	}
	if len(progress) != 4 || progress[0] != [2]int{0, 3} || progress[1] != [2]int{1, 3} || progress[2] != [2]int{2, 3} || progress[3] != [2]int{3, 3} {
		t.Fatalf("progress = %#v", progress)
	}
	recovered, err := service.accounts.Get(ctx, invalid.ID)
	if err != nil || recovered.AuthStatus != accountdomain.AuthStatusActive {
		t.Fatalf("invalid account was not recovered: %#v err=%v", recovered, err)
	}
}

func TestBatchRefreshTokensRefreshesOnlySelectedEligibleAccounts(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 19, 10, 0, 0, 0, time.UTC)
	service, refreshable, adapter := newCredentialRefreshTestService(t, now)
	service.now = func() time.Time { return now }
	selected := []uint64{refreshable.ID}
	var invalidID uint64
	for _, value := range []accountdomain.Credential{
		{Provider: accountdomain.ProviderBuild, Name: "missing-refresh", SourceKey: "missing-refresh", EncryptedAccessToken: "access", Enabled: true, AuthStatus: accountdomain.AuthStatusActive},
		{Provider: accountdomain.ProviderBuild, Name: "disabled", SourceKey: "disabled", EncryptedAccessToken: "access", EncryptedRefreshToken: "refresh", Enabled: true, AuthStatus: accountdomain.AuthStatusActive},
		{Provider: accountdomain.ProviderBuild, Name: "invalid", SourceKey: "invalid", EncryptedAccessToken: "access", EncryptedRefreshToken: "refresh", Enabled: true, AuthStatus: accountdomain.AuthStatusActive},
	} {
		created, _, err := service.accounts.UpsertByIdentity(ctx, value)
		if err != nil {
			t.Fatal(err)
		}
		needsUpdate := false
		if value.Name == "disabled" {
			created.Enabled = false
			needsUpdate = true
		}
		if value.Name == "invalid" {
			created.AuthStatus = accountdomain.AuthStatusReauthRequired
			invalidID = created.ID
			needsUpdate = true
		}
		if needsUpdate {
			created, err = service.accounts.Update(ctx, created)
			if err != nil {
				t.Fatal(err)
			}
		}
		selected = append(selected, created.ID)
	}

	succeeded, failed, skipped, err := service.BatchRefreshTokens(ctx, append(selected, refreshable.ID))
	if err != nil {
		t.Fatal(err)
	}
	if succeeded != 2 || failed != 0 || skipped != 2 || adapter.refreshCount.Load() != 2 {
		t.Fatalf("result = %d/%d/%d, refresh count = %d", succeeded, failed, skipped, adapter.refreshCount.Load())
	}
	updated, err := service.accounts.Get(ctx, refreshable.ID)
	if err != nil {
		t.Fatal(err)
	}
	if updated.EncryptedAccessToken == "" || updated.EncryptedAccessToken == "access-0" {
		t.Fatalf("refreshed access token = %q", updated.EncryptedAccessToken)
	}
	recovered, err := service.accounts.Get(ctx, invalidID)
	if err != nil || recovered.AuthStatus != accountdomain.AuthStatusActive {
		t.Fatalf("selected invalid account was not recovered: %#v err=%v", recovered, err)
	}
}

func TestRefreshBillingCollapsesConcurrentRequests(t *testing.T) {
	ctx := context.Background()
	now := time.Date(2026, 7, 11, 12, 0, 0, 0, time.UTC)
	service, credential, adapter := newCredentialRefreshTestService(t, now)
	adapter.billingDelay = 30 * time.Millisecond
	const callers = 20
	start := make(chan struct{})
	errors := make(chan error, callers)
	var workers sync.WaitGroup
	workers.Add(callers)
	for range callers {
		go func() {
			defer workers.Done()
			<-start
			_, err := service.RefreshBilling(ctx, credential.ID)
			errors <- err
		}()
	}
	close(start)
	workers.Wait()
	close(errors)
	for err := range errors {
		if err != nil {
			t.Fatal(err)
		}
	}
	if adapter.billingCount.Load() != 1 {
		t.Fatalf("billing count = %d", adapter.billingCount.Load())
	}
}

func newCredentialRefreshTestService(t *testing.T, now time.Time) (*Service, accountdomain.Credential, *credentialRefreshAdapter) {
	t.Helper()
	ctx := context.Background()
	database, err := relational.OpenSQLite(ctx, filepath.Join(t.TempDir(), "credential-refresh.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = database.Close() })
	if err := database.InitializeSchema(ctx); err != nil {
		t.Fatal(err)
	}
	repository := relational.NewAccountRepository(database)
	credential, _, err := repository.UpsertByIdentity(ctx, accountdomain.Credential{
		Provider:              accountdomain.ProviderBuild,
		Name:                  "refresh-test",
		SourceKey:             "refresh-test",
		EncryptedAccessToken:  "access-0",
		EncryptedRefreshToken: "refresh-0",
		ExpiresAt:             now.Add(time.Hour),
		Enabled:               true,
		AuthStatus:            accountdomain.AuthStatusActive,
	})
	if err != nil {
		t.Fatal(err)
	}
	adapter := &credentialRefreshAdapter{}
	service := NewService(repository, nil, nil, nil, provider.NewRegistry(adapter), nil, nil)
	return service, credential, adapter
}

type credentialRefreshAdapter struct {
	refreshCount atomic.Int64
	billingCount atomic.Int64
	delay        time.Duration
	billingDelay time.Duration
	billing      accountdomain.Billing
	billingErr   error
	refreshErr   error
	afterRefresh func()
}

func (a *credentialRefreshAdapter) Provider() accountdomain.Provider {
	return accountdomain.ProviderBuild
}

func (a *credentialRefreshAdapter) Definition() provider.Definition {
	return provider.Definition{
		Provider: accountdomain.ProviderBuild, Quota: provider.QuotaBilling,
		Credential: provider.CredentialSurface{
			Refresh: true,
		},
	}
}

func (a *credentialRefreshAdapter) RefreshCredential(ctx context.Context, _ accountdomain.Credential) (provider.RefreshedCredential, error) {
	if a.delay > 0 {
		timer := time.NewTimer(a.delay)
		defer timer.Stop()
		select {
		case <-ctx.Done():
			return provider.RefreshedCredential{}, ctx.Err()
		case <-timer.C:
		}
	}
	count := a.refreshCount.Add(1)
	if a.refreshErr != nil {
		return provider.RefreshedCredential{}, a.refreshErr
	}
	if a.afterRefresh != nil {
		a.afterRefresh()
	}
	return provider.RefreshedCredential{EncryptedAccessToken: fmt.Sprintf("access-%d", count), EncryptedRefreshToken: fmt.Sprintf("refresh-%d", count), ExpiresAt: time.Now().UTC().Add(time.Hour), RefreshTokenRotated: true}, nil
}

func (a *credentialRefreshAdapter) ForwardResponse(context.Context, provider.ResponseResourceRequest) (*provider.Response, error) {
	return nil, nil
}

func (a *credentialRefreshAdapter) ListModels(context.Context, accountdomain.Credential) ([]string, error) {
	return nil, nil
}

func (a *credentialRefreshAdapter) GetBilling(context.Context, accountdomain.Credential) (accountdomain.Billing, error) {
	if a.billingDelay > 0 {
		time.Sleep(a.billingDelay)
	}
	a.billingCount.Add(1)
	return a.billing, a.billingErr
}

func (a *credentialRefreshAdapter) StartDeviceAuthorization(context.Context) (provider.DeviceAuthorization, error) {
	return provider.DeviceAuthorization{}, nil
}

func (a *credentialRefreshAdapter) PollDeviceAuthorization(context.Context, string) (provider.CredentialSeed, error) {
	return provider.CredentialSeed{}, nil
}

func (a *credentialRefreshAdapter) ParseImportedCredentials([]byte) ([]provider.CredentialSeed, error) {
	return nil, nil
}
func (a *credentialRefreshAdapter) MarshalCredentials([]provider.CredentialSeed) ([]byte, error) {
	return nil, nil
}
