package console

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	auditdomain "github.com/chenyme/grok2api/backend/internal/domain/audit"
	"github.com/chenyme/grok2api/backend/internal/infra/provider"
	"github.com/chenyme/grok2api/backend/internal/infra/provider/cli"
)

var (
	resetDurationPattern = regexp.MustCompile(`(?i)(\d+)\s*([dhms])`)
)

func normalizeRequest(body []byte, spec ModelSpec) ([]byte, error) {
	return normalizeRequestWithMetadata(body, spec, nil)
}

func normalizeRequestWithMetadata(body []byte, spec ModelSpec, metadata *provider.NormalizedRequestMetadata) ([]byte, error) {
	var payload map[string]any
	if err := json.Unmarshal(body, &payload); err != nil {
		return nil, fmt.Errorf("解析 Console Responses 请求: %w", err)
	}
	payload["model"] = spec.UpstreamModel
	// Console is stateless. Replay the supplied input and silently discard
	// stateful client hints instead of rejecting an otherwise valid request.
	payload["store"] = false
	for _, field := range []string{
		"metadata", "previous_response_id", "service_tier", "prompt_cache_key",
		"background", "conversation",
	} {
		delete(payload, field)
	}
	normalizeConsoleResponseFormat(payload)
	patchConsoleInput(payload)
	if _, exists := payload["max_output_tokens"]; !exists && spec.MaxOutputTokens > 0 {
		payload["max_output_tokens"] = spec.MaxOutputTokens
	}
	requestedEffort := metadata != nil && auditdomain.NormalizeReasoningEffort(metadata.ReasoningEffort) != ""
	requestedEffort = requestedEffort || hasRecognizedConsoleReasoningEffort(payload)
	normalizeReasoning(payload, spec)
	updateConsoleReasoningMetadata(payload, spec, requestedEffort, metadata)
	ensureReasoningInclude(payload)
	toolSummary, err := normalizeConsoleTools(payload, spec.DisallowsClientTools)
	if err != nil {
		return nil, err
	}
	if spec.NoSearchTools {
		stripConsoleSearchTools(payload)
	}
	if err := normalizeConsoleToolChoice(payload, toolSummary, spec.DisallowsClientTools); err != nil {
		return nil, err
	}
	ensureConsoleToolChoicePair(payload)
	return json.Marshal(payload)
}

// ensureConsoleToolChoicePair enforces the upstream invariant that tool_choice
// may only be sent when at least one valid tool declaration is present.
func ensureConsoleToolChoicePair(payload map[string]any) {
	choice, hasChoice := payload["tool_choice"]
	if !hasChoice || choice == nil {
		return
	}
	tools, ok := payload["tools"].([]any)
	if !ok || len(tools) == 0 {
		delete(payload, "tools")
		delete(payload, "tool_choice")
	}
}

func hasRecognizedConsoleReasoningEffort(payload map[string]any) bool {
	reasoning, _ := payload["reasoning"].(map[string]any)
	effort, _ := reasoning["effort"].(string)
	if strings.EqualFold(strings.TrimSpace(effort), "auto") {
		return true
	}
	return normalizeEffort(effort) != ""
}

func updateConsoleReasoningMetadata(payload map[string]any, spec ModelSpec, requested bool, metadata *provider.NormalizedRequestMetadata) {
	if metadata == nil {
		return
	}
	previous := auditdomain.NormalizeReasoningEffort(metadata.ReasoningEffort)
	metadata.ReasoningEffort = ""
	if !requested || !spec.SupportsReasoning {
		return
	}
	if !spec.SupportsReasoningEffort {
		metadata.ReasoningEffort = "fixed"
		return
	}
	reasoning, _ := payload["reasoning"].(map[string]any)
	effort, _ := reasoning["effort"].(string)
	if normalized := auditdomain.NormalizeReasoningEffort(effort); normalized != "" {
		metadata.ReasoningEffort = normalized
		return
	}
	metadata.ReasoningEffort = previous
}

func normalizeConsoleResponseFormat(payload map[string]any) {
	raw, exists := payload["response_format"]
	if !exists {
		return
	}
	delete(payload, "response_format")
	format, ok := raw.(map[string]any)
	if !ok {
		return
	}
	if typeName, _ := format["type"].(string); typeName == "json_schema" {
		if nested, ok := format["json_schema"].(map[string]any); ok {
			flattened := map[string]any{"type": "json_schema"}
			for key, value := range nested {
				if key != "type" {
					flattened[key] = value
				}
			}
			format = flattened
		}
	}
	text, _ := payload["text"].(map[string]any)
	if text == nil {
		text = make(map[string]any)
	}
	if _, exists := text["format"]; !exists {
		text["format"] = format
	}
	payload["text"] = text
}

func patchConsoleInput(payload map[string]any) {
	items, ok := payload["input"].([]any)
	if !ok {
		return
	}
	for _, rawItem := range items {
		item, ok := rawItem.(map[string]any)
		if !ok {
			continue
		}
		if item["type"] == "reasoning" {
			patchConsoleReasoningContent(item)
			continue
		}
		content, ok := item["content"].([]any)
		if !ok {
			continue
		}
		for _, rawPart := range content {
			part, ok := rawPart.(map[string]any)
			if !ok {
				continue
			}
			typeName, _ := part["type"].(string)
			switch typeName {
			case "text", "output_text":
				part["type"] = "input_text"
			case "image_url":
				if image, ok := part["image_url"].(map[string]any); ok {
					if url, _ := image["url"].(string); strings.TrimSpace(url) != "" {
						part["type"] = "input_image"
						part["image_url"] = url
					}
				}
			}
		}
	}
}

func patchConsoleReasoningContent(item map[string]any) {
	content, ok := item["content"].([]any)
	if !ok {
		return
	}
	for _, rawPart := range content {
		part, ok := rawPart.(map[string]any)
		if !ok {
			continue
		}
		if _, exists := part["type"]; !exists {
			if _, hasText := part["text"]; hasText {
				part["type"] = "reasoning_text"
			}
		}
	}
}

func normalizeReasoning(payload map[string]any, spec ModelSpec) {
	if !spec.SupportsReasoning {
		delete(payload, "reasoning")
		return
	}
	reasoning, _ := payload["reasoning"].(map[string]any)
	if reasoning == nil {
		if spec.DefaultReasoningEffort == "" {
			delete(payload, "reasoning")
			return
		}
		reasoning = make(map[string]any)
	}
	if !spec.SupportsReasoningEffort {
		delete(reasoning, "effort")
		if len(reasoning) == 0 {
			delete(payload, "reasoning")
		} else {
			payload["reasoning"] = reasoning
		}
		return
	}
	effort, _ := reasoning["effort"].(string)
	effort = normalizeEffort(effort)
	if effort == "" {
		effort = spec.DefaultReasoningEffort
	}
	if effort != "" {
		reasoning["effort"] = effort
	}
	payload["reasoning"] = reasoning
}

func normalizeEffort(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "none":
		return "none"
	case "minimal", "low":
		return "low"
	case "medium":
		return "medium"
	case "high":
		return "high"
	case "xhigh", "max":
		return "xhigh"
	default:
		return ""
	}
}

func ensureReasoningInclude(payload map[string]any) {
	value, _ := payload["include"].([]any)
	seen := make(map[string]struct{})
	result := make([]any, 0)
	for _, item := range value {
		name, ok := item.(string)
		if !ok || strings.TrimSpace(name) == "" {
			continue
		}
		if _, exists := seen[name]; exists {
			continue
		}
		seen[name] = struct{}{}
		result = append(result, name)
	}
	if _, exists := seen["reasoning.encrypted_content"]; !exists {
		result = append(result, "reasoning.encrypted_content")
	}
	payload["include"] = result
}

type consoleToolSummary struct {
	retainedClientTools bool
	removedClientTools  bool
}

func normalizeConsoleTools(payload map[string]any, disallowsClientTools bool) (consoleToolSummary, error) {
	summary := consoleToolSummary{}
	value, exists := payload["tools"]
	if !exists || value == nil {
		delete(payload, "tools")
		return summary, nil
	}
	tools, ok := value.([]any)
	if !ok {
		delete(payload, "tools")
		return summary, nil
	}
	hasClientViewImage := hasConsoleFunctionTool(tools, "view_image")
	result := make([]any, 0, len(tools))
	seenServerTools := make(map[string]struct{})
	for _, rawTool := range tools {
		tool, ok := rawTool.(map[string]any)
		if !ok {
			continue
		}
		typeName, _ := tool["type"].(string)
		normalizedType := strings.ToLower(strings.TrimSpace(typeName))
		if disallowsClientTools {
			normalizedType = strings.ReplaceAll(normalizedType, "-", "_")
		}
		if disallowsClientTools && isMultiAgentClientTool(normalizedType) {
			summary.removedClientTools = true
			continue
		}
		switch normalizedType {
		case "web_search", "web_search_preview", "web_search_preview_2025_03_11", "web_search_2025_08_26":
			if disallowsClientTools {
				if _, exists := seenServerTools["web_search"]; exists {
					continue
				}
				seenServerTools["web_search"] = struct{}{}
			}
			// xAI equips web_search with a server-side tool also named view_image
			// when image understanding is enabled. Prefer the client's function of
			// that name so Codex can still inspect local files without mgw rejecting
			// the request as a duplicate tool definition.
			allowImageUnderstanding := disallowsClientTools || !hasClientViewImage
			clean := map[string]any{"type": "web_search", "enable_image_understanding": allowImageUnderstanding}
			if enabled, ok := tool["enable_image_understanding"].(bool); ok && allowImageUnderstanding {
				clean["enable_image_understanding"] = enabled
			}
			// Forward the image-search toggle (enable_image_search) so clients
			// can explicitly enable/disable it; absent when not requested.
			if enabled, ok := tool["enable_image_search"].(bool); ok {
				clean["enable_image_search"] = enabled
			}
			result = append(result, clean)
			summary.retainedClientTools = true
		case "x_search":
			if disallowsClientTools {
				if _, exists := seenServerTools["x_search"]; exists {
					continue
				}
				seenServerTools["x_search"] = struct{}{}
			}
			clean := map[string]any{"type": "x_search", "enable_video_understanding": true}
			if enabled, ok := tool["enable_video_understanding"].(bool); ok {
				clean["enable_video_understanding"] = enabled
			}
			// Forward the X-search time bounds (from_date/to_date, YYYY-MM-DD).
			// Invalid formats and empty strings are dropped; if from_date is
			// later than to_date both are dropped to avoid an upstream 400.
			for _, field := range []string{"from_date", "to_date"} {
				text, ok := tool[field].(string)
				if !ok || text == "" {
					continue
				}
				if date, err := time.Parse("2006-01-02", text); err == nil && date.Format("2006-01-02") == text {
					clean[field] = text
				}
			}
			from, hasFrom := clean["from_date"].(string)
			to, hasTo := clean["to_date"].(string)
			if hasFrom && hasTo {
				fromDate, _ := time.Parse("2006-01-02", from)
				toDate, _ := time.Parse("2006-01-02", to)
				if fromDate.After(toDate) {
					delete(clean, "from_date")
					delete(clean, "to_date")
				}
			}
			result = append(result, clean)
			summary.retainedClientTools = true
		case "function":
			name, _ := tool["name"].(string)
			if strings.TrimSpace(name) == "" {
				continue
			}
			clean := map[string]any{"type": "function", "name": strings.TrimSpace(name)}
			for _, field := range []string{"description", "parameters", "strict"} {
				if fieldValue, exists := tool[field]; exists {
					if field == "parameters" {
						normalized, _, err := cli.NormalizeBuildFunctionParametersRoot(fieldValue, "tools.parameters", strings.TrimSpace(name))
						if err != nil {
							return summary, err
						}
						clean[field] = normalized
						continue
					}
					clean[field] = fieldValue
				}
			}
			result = append(result, clean)
			summary.retainedClientTools = true
		case "mcp", "shell", "image_generation", "collections_search", "file_search", "code_execution", "code_interpreter":
			// These are native xAI Responses tool variants. Keep their payloads,
			// while namespace/tool_search remain client-side abstractions and are
			// intentionally omitted instead of causing an upstream 400.
			result = append(result, tool)
			summary.retainedClientTools = true
		}
	}
	if len(result) == 0 {
		delete(payload, "tools")
		return summary, nil
	}
	payload["tools"] = result
	return summary, nil
}

// stripConsoleSearchTools removes built-in search tools the model ignores.
// When nothing remains, tools and tool_choice are dropped together.
func stripConsoleSearchTools(payload map[string]any) {
	tools, ok := payload["tools"].([]any)
	if !ok {
		return
	}
	kept := tools[:0]
	for _, rawTool := range tools {
		if tool, ok := rawTool.(map[string]any); ok {
			if typeName, _ := tool["type"].(string); typeName == "web_search" || typeName == "x_search" {
				continue
			}
		}
		kept = append(kept, rawTool)
	}
	if len(kept) == 0 {
		delete(payload, "tools")
		delete(payload, "tool_choice")
		return
	}
	payload["tools"] = kept
}

func hasConsoleFunctionTool(tools []any, target string) bool {
	for _, rawTool := range tools {
		tool, ok := rawTool.(map[string]any)
		if !ok {
			continue
		}
		typeName, _ := tool["type"].(string)
		name, _ := tool["name"].(string)
		if strings.EqualFold(strings.TrimSpace(typeName), "function") && strings.EqualFold(strings.TrimSpace(name), target) {
			return true
		}
	}
	return false
}

func isMultiAgentClientTool(toolType string) bool {
	return toolType == "function" || toolType == "custom" || toolType == "shell" ||
		toolType == "mcp" || strings.HasPrefix(toolType, "mcp_")
}

func normalizeConsoleToolChoice(payload map[string]any, summary consoleToolSummary, disallowsClientTools bool) error {
	if _, exists := payload["tools"]; !exists {
		if disallowsClientTools && summary.removedClientTools && toolChoiceRequiresTool(payload["tool_choice"]) {
			return fmt.Errorf("模型不支持请求中必需的客户端工具")
		}
		delete(payload, "tool_choice")
		return nil
	}
	if disallowsClientTools {
		choice, exists := payload["tool_choice"]
		if !exists {
			payload["tool_choice"] = "auto"
			return nil
		}
		if value, ok := choice.(string); ok {
			switch strings.ToLower(strings.TrimSpace(value)) {
			case "none", "auto", "required":
				payload["tool_choice"] = strings.ToLower(strings.TrimSpace(value))
			default:
				payload["tool_choice"] = "auto"
			}
			return nil
		}
		if object, ok := choice.(map[string]any); ok {
			typeName, _ := object["type"].(string)
			if isMultiAgentClientTool(strings.ReplaceAll(strings.ToLower(strings.TrimSpace(typeName)), "-", "_")) {
				return fmt.Errorf("模型不支持请求中指定的客户端工具")
			}
		}
		payload["tool_choice"] = "required"
		return nil
	}
	choice, exists := payload["tool_choice"]
	if !exists {
		payload["tool_choice"] = "auto"
		return nil
	}
	if value, ok := choice.(string); ok {
		switch strings.ToLower(strings.TrimSpace(value)) {
		case "none", "auto":
			payload["tool_choice"] = strings.ToLower(strings.TrimSpace(value))
		case "required":
			if !summary.retainedClientTools {
				payload["tool_choice"] = "auto"
			}
		default:
			payload["tool_choice"] = "auto"
		}
		return nil
	}
	object, ok := choice.(map[string]any)
	if !ok {
		payload["tool_choice"] = "auto"
		return nil
	}
	typeName, _ := object["type"].(string)
	if typeName != "function" || !summary.retainedClientTools {
		payload["tool_choice"] = "auto"
		return nil
	}
	name, _ := object["name"].(string)
	if strings.TrimSpace(name) == "" {
		if function, ok := object["function"].(map[string]any); ok {
			name, _ = function["name"].(string)
		}
	}
	if strings.TrimSpace(name) == "" {
		payload["tool_choice"] = "auto"
		return nil
	}
	payload["tool_choice"] = map[string]any{"type": "function", "name": strings.TrimSpace(name)}
	return nil
}

func toolChoiceRequiresTool(choice any) bool {
	if value, ok := choice.(string); ok {
		return strings.EqualFold(strings.TrimSpace(value), "required")
	}
	_, isObject := choice.(map[string]any)
	return isObject
}

func toolIdentity(value any) string {
	tool, ok := value.(map[string]any)
	if !ok {
		return ""
	}
	typeName, _ := tool["type"].(string)
	if typeName != "function" {
		return typeName
	}
	name, _ := tool["name"].(string)
	return typeName + ":" + name
}

func consoleRetryAfter(body []byte) time.Duration {
	text := string(body)
	index := strings.Index(strings.ToLower(text), "resets in:")
	if index < 0 {
		return 0
	}
	text = text[index+len("resets in:"):]
	var total time.Duration
	for _, match := range resetDurationPattern.FindAllStringSubmatch(text, -1) {
		value, _ := strconv.Atoi(match[1])
		switch strings.ToLower(match[2]) {
		case "d":
			total += time.Duration(value) * 24 * time.Hour
		case "h":
			total += time.Duration(value) * time.Hour
		case "m":
			total += time.Duration(value) * time.Minute
		case "s":
			total += time.Duration(value) * time.Second
		}
	}
	return total
}

func parseConsoleRetryAfterHeader(value string, now time.Time) time.Duration {
	value = strings.TrimSpace(value)
	if seconds, err := strconv.ParseInt(value, 10, 64); err == nil && seconds > 0 {
		return time.Duration(seconds) * time.Second
	}
	if at, err := http.ParseTime(value); err == nil && at.After(now) {
		return at.Sub(now)
	}
	return 0
}

func parseConsoleRateLimitMetadata(body []byte) *provider.RateLimitMetadata {
	return provider.ParseRateLimitMetadata(body)
}
