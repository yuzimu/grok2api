package conversation

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
)

// convertChatRequest 将 Chat Completions 请求完整转换为标准 Responses 输入。
func convertChatRequest(body []byte, model string) ([]byte, ResponseOptions, error) {
	return convertChatRequestWithReasoningReplay(body, model, nil, "")
}

func convertChatRequestWithReasoningReplay(body []byte, model string, cache *ReasoningCache, scope string) ([]byte, ResponseOptions, error) {
	var source map[string]json.RawMessage
	if err := json.Unmarshal(body, &source); err != nil {
		return nil, ResponseOptions{}, fmt.Errorf("解析 Chat Completions 请求: %w", err)
	}
	var messages []chatMessage
	if err := json.Unmarshal(source["messages"], &messages); err != nil || len(messages) == 0 {
		return nil, ResponseOptions{}, errors.New("messages 必须是非空数组")
	}
	input, err := convertChatMessagesWithReasoningReplay(messages, cache, scope)
	if err != nil {
		return nil, ResponseOptions{}, err
	}
	target := map[string]json.RawMessage{"model": mustJSON(model), "input": mustJSON(input)}
	copyFields(target, source, "stream", "temperature", "top_p", "parallel_tool_calls", "metadata", "store", "service_tier")
	if raw := source["user"]; !isEmptyJSON(raw) {
		var user string
		if json.Unmarshal(raw, &user) != nil || strings.TrimSpace(user) == "" {
			return nil, ResponseOptions{}, errors.New("user 必须是非空字符串")
		}
		target["safety_identifier"] = mustJSON(strings.TrimSpace(user))
	}
	stopSequences, err := parseChatStopSequences(source["stop"])
	if err != nil {
		return nil, ResponseOptions{}, err
	}
	if raw := firstJSON(source["max_completion_tokens"], source["max_tokens"]); !isEmptyJSON(raw) {
		target["max_output_tokens"] = raw
	}
	if raw := source["response_format"]; !isEmptyJSON(raw) {
		format, err := convertResponseFormat(raw)
		if err != nil {
			return nil, ResponseOptions{}, err
		}
		target["text"] = mustJSON(map[string]json.RawMessage{"format": format})
	}
	if raw := source["reasoning_effort"]; !isEmptyJSON(raw) {
		target["reasoning"] = mustJSON(map[string]json.RawMessage{"effort": raw})
	}
	var tools []any
	if raw := source["tools"]; !isEmptyJSON(raw) {
		tools, err = convertChatTools(raw)
		if err != nil {
			return nil, ResponseOptions{}, err
		}
	}
	if !isEmptyJSON(source["web_search_options"]) && !containsToolType(tools, "web_search") {
		tools = append(tools, map[string]any{"type": "web_search"})
	}
	if len(tools) > 0 {
		target["tools"] = mustJSON(tools)
	}
	if raw := source["tool_choice"]; !isEmptyJSON(raw) {
		choice, err := convertChatToolChoice(raw)
		if err != nil {
			return nil, ResponseOptions{}, err
		}
		target["tool_choice"] = choice
	}
	converted, err := json.Marshal(target)
	return converted, ResponseOptions{StopSequences: stopSequences}.WithReasoningReplay(cache, scope), err
}

func parseChatStopSequences(raw json.RawMessage) ([]string, error) {
	if isEmptyJSON(raw) {
		return nil, nil
	}
	var single string
	if json.Unmarshal(raw, &single) == nil {
		if single == "" {
			return nil, errors.New("stop 不能为空")
		}
		return []string{single}, nil
	}
	var values []string
	if json.Unmarshal(raw, &values) != nil || len(values) == 0 {
		return nil, errors.New("stop 必须是字符串或非空字符串数组")
	}
	if len(values) > 4 {
		return nil, errors.New("stop 最多包含 4 个序列")
	}
	for index, value := range values {
		if value == "" {
			return nil, fmt.Errorf("stop[%d] 不能为空", index)
		}
	}
	return values, nil
}

type chatMessage struct {
	Role       string          `json:"role"`
	Content    json.RawMessage `json:"content"`
	ToolCalls  json.RawMessage `json:"tool_calls"`
	ToolCallID string          `json:"tool_call_id"`
	Name       string          `json:"name"`
}

func convertChatMessages(messages []chatMessage) ([]any, error) {
	return convertChatMessagesWithReasoningReplay(messages, nil, "")
}

func convertChatMessagesWithReasoningReplay(messages []chatMessage, cache *ReasoningCache, scope string) ([]any, error) {
	input := make([]any, 0, len(messages))
	for _, message := range messages {
		role := strings.ToLower(strings.TrimSpace(message.Role))
		switch role {
		case "system", "developer", "user", "assistant":
			if !isEmptyJSON(message.Content) && !bytes.Equal(bytes.TrimSpace(message.Content), []byte("null")) {
				content, err := convertChatContent(message.Content)
				if err != nil {
					return nil, fmt.Errorf("%s 消息内容无效: %w", role, err)
				}
				input = append(input, map[string]any{"type": "message", "role": role, "content": content})
			}
			if role == "assistant" && !isEmptyJSON(message.ToolCalls) {
				calls, err := convertAssistantToolCalls(message.ToolCalls)
				if err != nil {
					return nil, err
				}
				input = append(input, restoreReasoningForCalls(calls, cache, scope)...)
			}
		case "tool":
			if strings.TrimSpace(message.ToolCallID) == "" {
				return nil, errors.New("tool 消息缺少 tool_call_id")
			}
			output, err := convertChatToolOutput(message.Content)
			if err != nil {
				return nil, err
			}
			input = append(input, map[string]any{"type": "function_call_output", "call_id": message.ToolCallID, "output": output})
		default:
			return nil, fmt.Errorf("不支持 messages.role=%q", message.Role)
		}
	}
	if len(input) == 0 {
		return nil, errors.New("messages 中没有可发送内容")
	}
	return input, nil
}

func convertChatContent(raw json.RawMessage) (any, error) {
	var text string
	if json.Unmarshal(raw, &text) == nil {
		return text, nil
	}
	var parts []map[string]json.RawMessage
	if err := json.Unmarshal(raw, &parts); err != nil {
		return nil, errors.New("content 必须是字符串或内容数组")
	}
	result := make([]any, 0, len(parts))
	for _, part := range parts {
		var typeName string
		_ = json.Unmarshal(part["type"], &typeName)
		switch typeName {
		case "text", "input_text", "output_text":
			var value string
			if json.Unmarshal(part["text"], &value) != nil {
				return nil, errors.New("text 内容无效")
			}
			result = append(result, map[string]any{"type": "input_text", "text": value})
		case "image_url", "input_image":
			image, err := convertChatImagePart(part)
			if err != nil {
				return nil, err
			}
			result = append(result, image)
		default:
			return nil, fmt.Errorf("不支持 content.type=%q", typeName)
		}
	}
	return result, nil
}

func convertChatToolOutput(raw json.RawMessage) (any, error) {
	var text string
	if json.Unmarshal(raw, &text) == nil {
		return text, nil
	}
	var parts []map[string]json.RawMessage
	if json.Unmarshal(raw, &parts) != nil {
		return contentAsText(raw)
	}
	hasImage := false
	for _, part := range parts {
		var typeName string
		_ = json.Unmarshal(part["type"], &typeName)
		if typeName == "image_url" || typeName == "input_image" {
			hasImage = true
			break
		}
	}
	if !hasImage {
		return contentAsText(raw)
	}
	return convertChatContent(raw)
}

func convertChatImagePart(part map[string]json.RawMessage) (map[string]any, error) {
	imageURL, detail, err := parseImageURL(part)
	if err != nil {
		return nil, err
	}
	return map[string]any{"type": "input_image", "detail": detail, "image_url": imageURL}, nil
}

func parseImageURL(part map[string]json.RawMessage) (string, string, error) {
	raw := firstJSON(part["image_url"], part["url"])
	detail := "auto"
	var directDetail string
	if json.Unmarshal(part["detail"], &directDetail) == nil && strings.TrimSpace(directDetail) != "" {
		detail = strings.TrimSpace(directDetail)
	}
	var value string
	if json.Unmarshal(raw, &value) == nil && strings.TrimSpace(value) != "" {
		return value, detail, nil
	}
	var nested struct {
		URL    string `json:"url"`
		Detail string `json:"detail"`
	}
	if json.Unmarshal(raw, &nested) == nil && strings.TrimSpace(nested.URL) != "" {
		if strings.TrimSpace(nested.Detail) != "" {
			detail = strings.TrimSpace(nested.Detail)
		}
		return nested.URL, detail, nil
	}
	return "", "", errors.New("image_url 缺少有效 url")
}

func convertAssistantToolCalls(raw json.RawMessage) ([]any, error) {
	var calls []struct {
		ID       string `json:"id"`
		Type     string `json:"type"`
		Function struct {
			Name      string `json:"name"`
			Arguments string `json:"arguments"`
		} `json:"function"`
	}
	if err := json.Unmarshal(raw, &calls); err != nil {
		return nil, errors.New("assistant.tool_calls 格式无效")
	}
	result := make([]any, 0, len(calls))
	for _, call := range calls {
		if strings.TrimSpace(call.ID) == "" || strings.TrimSpace(call.Function.Name) == "" {
			return nil, errors.New("assistant.tool_calls 缺少有效 id 或 name")
		}
		arguments := call.Function.Arguments
		if arguments == "" {
			arguments = "{}"
		}
		result = append(result, map[string]any{"type": "function_call", "call_id": call.ID, "name": call.Function.Name, "arguments": arguments})
	}
	return result, nil
}

func convertChatTools(raw json.RawMessage) ([]any, error) {
	var tools []map[string]json.RawMessage
	if err := json.Unmarshal(raw, &tools); err != nil {
		return nil, errors.New("tools 必须是数组")
	}
	result := make([]any, 0, len(tools))
	for _, tool := range tools {
		var typeName string
		_ = json.Unmarshal(tool["type"], &typeName)
		if typeName != "function" {
			var value any
			_ = json.Unmarshal(mustJSON(tool), &value)
			object, _ := value.(map[string]any)
			switch typeName {
			case "web_search", "web_search_preview", "web_search_preview_2025_03_11", "web_search_2025_08_26":
				converted, err := convertChatWebSearchTool(object)
				if err != nil {
					return nil, err
				}
				result = append(result, converted)
			default:
				result = append(result, value)
			}
			continue
		}
		var function map[string]any
		if json.Unmarshal(tool["function"], &function) != nil {
			return nil, errors.New("function tool 格式无效")
		}
		function["type"] = "function"
		result = append(result, function)
	}
	return result, nil
}

func convertChatWebSearchTool(tool map[string]any) (map[string]any, error) {
	nested := make(map[string][]any, 2)
	if rawFilters, exists := tool["filters"]; exists && rawFilters != nil {
		filters, ok := rawFilters.(map[string]any)
		if !ok {
			return nil, errors.New("web_search filters 必须是对象")
		}
		for _, field := range []string{"allowed_domains", "excluded_domains"} {
			if value, exists := filters[field]; exists {
				domains, err := normalizeChatWebSearchDomains(value, field)
				if err != nil {
					return nil, err
				}
				nested[field] = domains
			}
		}
	}

	resultFilters := make(map[string]any, 2)
	for _, field := range []string{"allowed_domains", "excluded_domains"} {
		var topLevel []any
		if value, exists := tool[field]; exists {
			domains, err := normalizeChatWebSearchDomains(value, field)
			if err != nil {
				return nil, err
			}
			topLevel = domains
		}
		domains := nested[field]
		if len(domains) > 0 && len(topLevel) > 0 && !sameChatWebSearchDomains(domains, topLevel) {
			return nil, fmt.Errorf("web_search %s 声明冲突", field)
		}
		if len(domains) == 0 {
			domains = topLevel
		}
		if len(domains) > 0 {
			resultFilters[field] = domains
		}
	}
	if _, hasAllowed := resultFilters["allowed_domains"]; hasAllowed {
		if _, hasExcluded := resultFilters["excluded_domains"]; hasExcluded {
			return nil, errors.New("web_search 不能同时设置 allowed_domains 和 excluded_domains")
		}
	}
	converted := map[string]any{"type": "web_search"}
	if len(resultFilters) > 0 {
		converted["filters"] = resultFilters
	}
	return converted, nil
}

func normalizeChatWebSearchDomains(value any, field string) ([]any, error) {
	if value == nil {
		return nil, nil
	}
	domains, ok := value.([]any)
	if !ok {
		return nil, fmt.Errorf("web_search %s 必须是字符串数组", field)
	}
	if len(domains) > MaxWebSearchDomains {
		return nil, fmt.Errorf("web_search %s 不能超过 %d 个域名", field, MaxWebSearchDomains)
	}
	for index, value := range domains {
		domain, ok := value.(string)
		if !ok || strings.TrimSpace(domain) == "" {
			return nil, fmt.Errorf("web_search %s[%d] 必须是非空字符串", field, index)
		}
	}
	return domains, nil
}

func sameChatWebSearchDomains(left, right []any) bool {
	if len(left) != len(right) {
		return false
	}
	for index := range left {
		if left[index] != right[index] {
			return false
		}
	}
	return true
}

func containsToolType(tools []any, kind string) bool {
	for _, raw := range tools {
		tool, ok := raw.(map[string]any)
		if ok && tool["type"] == kind {
			return true
		}
	}
	return false
}

func convertChatToolChoice(raw json.RawMessage) (json.RawMessage, error) {
	var value map[string]json.RawMessage
	if json.Unmarshal(raw, &value) != nil {
		return raw, nil
	}
	var typeName string
	_ = json.Unmarshal(value["type"], &typeName)
	if typeName != "function" {
		return raw, nil
	}
	var function struct {
		Name string `json:"name"`
	}
	if json.Unmarshal(value["function"], &function) != nil || strings.TrimSpace(function.Name) == "" {
		return nil, errors.New("tool_choice.function.name 无效")
	}
	return mustJSON(map[string]any{"type": "function", "name": function.Name}), nil
}

func restoreReasoningForCalls(calls []any, cache *ReasoningCache, scope string) []any {
	if cache == nil || strings.TrimSpace(scope) == "" {
		return calls
	}
	// A cached reasoning item may be inserted before each call, so the final
	// slice can be larger than calls. Use the input size as a safe initial
	// capacity and let append grow it; len(calls)+1 is unnecessary and can
	// overflow for a maximally sized input slice.
	result := make([]any, 0, len(calls))
	seenIDs := make(map[string]struct{})
	seenEncrypted := make(map[string]struct{})
	for _, raw := range calls {
		callMap, ok := raw.(map[string]any)
		if !ok {
			result = append(result, raw)
			continue
		}
		callID, _ := callMap["call_id"].(string)
		if item, found := cache.GetScoped(scope, callID); found && item.ID != "" && item.Encrypted != "" && !reasoningAlreadyEmitted(seenIDs, seenEncrypted, item) {
			result = append(result, reasoningInputItem(item))
			markReasoningEmitted(seenIDs, seenEncrypted, item)
		}
		result = append(result, raw)
	}
	return result
}

func reasoningAlreadyEmitted(ids, encrypted map[string]struct{}, item responseItem) bool {
	if id := strings.TrimSpace(item.ID); id != "" {
		if _, exists := ids[id]; exists {
			return true
		}
	}
	if value := strings.TrimSpace(item.Encrypted); value != "" {
		if _, exists := encrypted[value]; exists {
			return true
		}
	}
	return false
}

func markReasoningEmitted(ids, encrypted map[string]struct{}, item responseItem) {
	if id := strings.TrimSpace(item.ID); id != "" {
		ids[id] = struct{}{}
	}
	if value := strings.TrimSpace(item.Encrypted); value != "" {
		encrypted[value] = struct{}{}
	}
}

func reasoningInputItem(item responseItem) map[string]any {
	payload := map[string]any{
		"type":   "reasoning",
		"id":     item.ID,
		"status": "completed",
	}
	if item.Encrypted != "" {
		payload["encrypted_content"] = item.Encrypted
	}
	if summary := cleanReasoningContents(item.Summary); len(summary) > 0 {
		payload["summary"] = summary
	} else if item.Encrypted != "" {
		// Build's replay schema requires a summary member when an opaque proof is
		// present. An empty array is the canonical representation for a redacted
		// or summary-less reasoning item.
		payload["summary"] = []any{}
	}
	// Omit content when it is nil/empty. Build treats content:null as a
	// mutation of the opaque reasoning/compaction payload.
	if content := cleanReasoningContents(item.Content); len(content) > 0 {
		payload["content"] = content
	}
	return payload
}

// cleanReasoningContents converts the internal response representation back to
// the small Responses input shape. responseContent's struct tags intentionally
// do not use omitempty because they are also used for decoding upstream output;
// assigning the structs directly here would therefore emit refusal:"" and
// annotations:null and make an opaque reasoning item look rewritten.
func cleanReasoningContents(contents []responseContent) []any {
	if len(contents) == 0 {
		return nil
	}
	cleaned := make([]any, 0, len(contents))
	for _, content := range contents {
		value := make(map[string]any, 4)
		if content.Type != "" {
			value["type"] = content.Type
		}
		if content.Text != "" || content.Type == "summary_text" || content.Type == "reasoning_text" || content.Type == "output_text" {
			value["text"] = content.Text
		}
		if content.Refusal != "" {
			value["refusal"] = content.Refusal
		}
		if content.Annotations != nil {
			value["annotations"] = content.Annotations
		}
		cleaned = append(cleaned, value)
	}
	return cleaned
}
