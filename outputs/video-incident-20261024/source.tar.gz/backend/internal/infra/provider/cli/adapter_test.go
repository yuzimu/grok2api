package cli

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/google/uuid"

	"github.com/chenyme/grok2api/backend/internal/domain/account"
	modeldomain "github.com/chenyme/grok2api/backend/internal/domain/model"
	settingsdomain "github.com/chenyme/grok2api/backend/internal/domain/settings"
	"github.com/chenyme/grok2api/backend/internal/infra/buildtransport"
	infraegress "github.com/chenyme/grok2api/backend/internal/infra/egress"
	"github.com/chenyme/grok2api/backend/internal/infra/provider"
	"github.com/chenyme/grok2api/backend/internal/infra/provider/conversation"
	"github.com/chenyme/grok2api/backend/internal/infra/runtime/memory"
	"github.com/chenyme/grok2api/backend/internal/infra/security"
	"github.com/chenyme/grok2api/backend/internal/pkg/neterror"
	"github.com/chenyme/grok2api/backend/internal/pkg/reasoningreplay"
)

type roundTripFunc func(*http.Request) (*http.Response, error)

func (fn roundTripFunc) RoundTrip(request *http.Request) (*http.Response, error) {
	return fn(request)
}

func TestBuildDirectTransportEnablesHTTP2Health(t *testing.T) {
	transport := newBuildHTTPTransport(5 * time.Minute)
	if transport.IdleConnTimeout != buildtransport.IdleConnTimeout {
		t.Fatalf("idle connection timeout = %s", transport.IdleConnTimeout)
	}
	// Go 1.27 moved the HTTP/2 switch from TLSNextProto["h2"] to the public
	// Transport.Protocols field; accept whichever one is enabled.
	http2Enabled := transport.Protocols != nil && transport.Protocols.HTTP2()
	if !http2Enabled && transport.TLSNextProto["h2"] == nil {
		t.Fatal("Build direct transport did not install HTTP/2 health checks")
	}
}

func TestResponseRequestForcedEgressOverridesCredentialBinding(t *testing.T) {
	var gotNodeID uint64
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, nil)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		gotNodeID = infraegress.EgressNodeFromContext(request.Context())
		return &http.Response{
			StatusCode: http.StatusOK,
			Status:     "200 OK",
			Header:     make(http.Header),
			Body:       io.NopCloser(strings.NewReader(`{}`)),
			Request:    request,
		}, nil
	})
	call := adapter.doResponseRequest(context.Background(), provider.ResponseResourceRequest{
		Credential:         account.Credential{ID: 7, Provider: account.ProviderBuild, EgressNodeID: 11},
		ForcedEgressNodeID: 22,
		Method:             http.MethodPost,
		Path:               "/responses",
	}, "access-token", nil, "https://cli-chat-proxy.grok.com/v1")
	if call.err != nil {
		t.Fatal(call.err)
	}
	_ = call.response.Body.Close()
	if gotNodeID != 22 {
		t.Fatalf("egress node=%d, want forced node=22", gotNodeID)
	}
}

func TestResponseRequestSendsTransientRetryHeaderOnlyForResubmissions(t *testing.T) {
	tests := []struct {
		name  string
		retry int
		want  string
	}{
		{name: "initial submission", retry: 0},
		{name: "invalid negative value", retry: -1},
		{name: "first resubmission", retry: 1, want: "1"},
		{name: "second resubmission", retry: 2, want: "2"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			var got string
			adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, nil)
			adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
				got = request.Header.Get("x-grok-transient-retry")
				return &http.Response{
					StatusCode: http.StatusOK,
					Status:     "200 OK",
					Header:     make(http.Header),
					Body:       io.NopCloser(strings.NewReader(`{}`)),
					Request:    request,
				}, nil
			})
			call := adapter.doResponseRequest(context.Background(), provider.ResponseResourceRequest{
				Credential:     account.Credential{ID: 7, Provider: account.ProviderBuild},
				Method:         http.MethodPost,
				Path:           "/responses",
				TransientRetry: test.retry,
			}, "access-token", nil, "https://cli-chat-proxy.grok.com/v1")
			if call.err != nil {
				t.Fatal(call.err)
			}
			_ = call.response.Body.Close()
			if got != test.want {
				t.Fatalf("x-grok-transient-retry = %q, want %q", got, test.want)
			}
		})
	}
}

func TestAdapterHotUpdatesDirectResponseHeaderTimeout(t *testing.T) {
	adapter := NewAdapter(Config{ResponseHeaderTimeout: 2 * time.Minute, StreamIdleTimeout: 3 * time.Minute}, nil)
	before := adapter.base.current.Load()
	if before.ResponseHeaderTimeout != 2*time.Minute {
		t.Fatalf("initial timeout = %s", before.ResponseHeaderTimeout)
	}
	if got := adapter.config().StreamIdleTimeout; got != 3*time.Minute {
		t.Fatalf("initial stream idle timeout = %s", got)
	}
	adapter.UpdateConfig(Config{ResponseHeaderTimeout: 7 * time.Minute, StreamIdleTimeout: 11 * time.Minute})
	after := adapter.base.current.Load()
	if after == before || after.ResponseHeaderTimeout != 7*time.Minute {
		t.Fatalf("updated transport=%p timeout=%s", after, after.ResponseHeaderTimeout)
	}
	if got := adapter.config().StreamIdleTimeout; got != 11*time.Minute {
		t.Fatalf("updated stream idle timeout = %s", got)
	}
}

func TestAdapterDefaultsStreamIdleTimeout(t *testing.T) {
	adapter := NewAdapter(Config{}, nil)
	if got := adapter.config().StreamIdleTimeout; got != settingsdomain.DefaultBuildStreamIdleTimeout {
		t.Fatalf("stream idle timeout = %s, want %s", got, settingsdomain.DefaultBuildStreamIdleTimeout)
	}
}

func TestNonStreamingConversationResponseHealthBoundaries(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	request := provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 7, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", Operation: conversation.OperationChat,
		NormalizeBody: true, Streaming: false,
		Body: []byte(`{"model":"grok-4.5","messages":[{"role":"user","content":"hello"}]}`),
	}

	t.Run("internal idle deadline", func(t *testing.T) {
		adapter := NewAdapter(Config{BaseURL: "https://build.example/v1", StreamIdleTimeout: 25 * time.Millisecond}, cipher)
		adapter.http.Transport = roundTripFunc(func(req *http.Request) (*http.Response, error) {
			return &http.Response{
				StatusCode: http.StatusOK, Status: "200 OK", Header: http.Header{"Content-Type": {"application/json"}},
				Body: &contextBlockingResponseBody{ctx: req.Context()}, Request: req,
			}, nil
		})
		ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
		defer cancel()
		started := time.Now()
		_, err := adapter.ForwardResponse(ctx, request)
		if !errors.Is(err, neterror.ErrUpstreamStreamIdleTimeout) || neterror.IdleTimeoutObservedData(err) {
			t.Fatalf("idle error = %#v, observed=%t", err, neterror.IdleTimeoutObservedData(err))
		}
		if elapsed := time.Since(started); elapsed >= 250*time.Millisecond {
			t.Fatalf("idle timeout took %s; parent deadline was used", elapsed)
		}
	})

	t.Run("client cancellation remains cancellation", func(t *testing.T) {
		adapter := NewAdapter(Config{BaseURL: "https://build.example/v1", StreamIdleTimeout: time.Second}, cipher)
		adapter.http.Transport = roundTripFunc(func(req *http.Request) (*http.Response, error) {
			return &http.Response{
				StatusCode: http.StatusOK, Status: "200 OK", Header: http.Header{"Content-Type": {"application/json"}},
				Body: &contextBlockingResponseBody{ctx: req.Context()}, Request: req,
			}, nil
		})
		ctx, cancel := context.WithCancel(context.Background())
		time.AfterFunc(20*time.Millisecond, cancel)
		_, err := adapter.ForwardResponse(ctx, request)
		if !errors.Is(err, context.Canceled) || neterror.IsUpstreamStreamIdleTimeout(err) {
			t.Fatalf("client cancellation error = %v", err)
		}
	})

	t.Run("empty successful body", func(t *testing.T) {
		adapter := NewAdapter(Config{BaseURL: "https://build.example/v1", StreamIdleTimeout: time.Second}, cipher)
		adapter.http.Transport = roundTripFunc(func(req *http.Request) (*http.Response, error) {
			return &http.Response{
				StatusCode: http.StatusOK, Status: "200 OK", Header: http.Header{"Content-Type": {"application/json"}},
				Body: io.NopCloser(strings.NewReader("")), Request: req,
			}, nil
		})
		_, err := adapter.ForwardResponse(context.Background(), request)
		if !errors.Is(err, neterror.ErrUpstreamResponseEmpty) {
			t.Fatalf("empty body error = %v", err)
		}
	})
}

type contextBlockingResponseBody struct {
	ctx context.Context
}

func (b *contextBlockingResponseBody) Read([]byte) (int, error) {
	<-b.ctx.Done()
	return 0, b.ctx.Err()
}

func (*contextBlockingResponseBody) Close() error { return nil }

func TestCredentialMetadataMarksNumericBotFlagOneOrTwo(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{}, cipher)
	tests := []struct {
		name       string
		provider   account.Provider
		claims     map[string]any
		token      string
		wantFlag   bool
		wantSource int
	}{
		{name: "numeric one", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 1}, wantFlag: true, wantSource: 1},
		{name: "bfs numeric one", provider: account.ProviderBuild, claims: map[string]any{"bfs": 1}, wantFlag: true, wantSource: 1},
		{name: "numeric two", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 2}, wantFlag: true, wantSource: 2},
		{name: "bfs numeric two", provider: account.ProviderBuild, claims: map[string]any{"bfs": 2}, wantFlag: true, wantSource: 2},
		{name: "bfs preferred when bot_flag_source missing", provider: account.ProviderBuild, claims: map[string]any{"bfs": 1, "sub": "user"}, wantFlag: true, wantSource: 1},
		{name: "either claim one is enough", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 0, "bfs": 1}, wantFlag: true, wantSource: 1},
		{name: "bot_flag_source preferred over bfs", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 1, "bfs": 2}, wantFlag: true, wantSource: 1},
		{name: "bot_flag_source two preferred over bfs one", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 2, "bfs": 1}, wantFlag: true, wantSource: 2},
		{name: "numeric zero", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 0}},
		{name: "bfs numeric zero", provider: account.ProviderBuild, claims: map[string]any{"bfs": 0}},
		{name: "numeric three", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 3}},
		{name: "fractional one", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": 1.5}},
		{name: "bfs fractional two", provider: account.ProviderBuild, claims: map[string]any{"bfs": 2.5}},
		{name: "string one", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": "1"}},
		{name: "bfs string one", provider: account.ProviderBuild, claims: map[string]any{"bfs": "1"}},
		{name: "string two", provider: account.ProviderBuild, claims: map[string]any{"bot_flag_source": "2"}},
		{name: "missing claim", provider: account.ProviderBuild, claims: map[string]any{"sub": "user"}},
		{name: "malformed jwt", provider: account.ProviderBuild, token: "not-a-jwt"},
		{name: "non build", provider: account.ProviderWeb, claims: map[string]any{"bot_flag_source": 1}},
		{name: "non build bfs two", provider: account.ProviderWeb, claims: map[string]any{"bfs": 2}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			token := test.token
			if test.claims != nil {
				payload, marshalErr := json.Marshal(test.claims)
				if marshalErr != nil {
					t.Fatal(marshalErr)
				}
				token = "e30." + base64.RawURLEncoding.EncodeToString(payload) + ".signature"
			}
			encrypted, encryptErr := cipher.Encrypt(token)
			if encryptErr != nil {
				t.Fatal(encryptErr)
			}
			metadata := adapter.CredentialMetadata(account.Credential{Provider: test.provider, EncryptedAccessToken: encrypted})
			wantInspected := test.provider == account.ProviderBuild && test.claims != nil
			if metadata.BuildBotFlagInspected != wantInspected {
				t.Fatalf("inspected = %t, want %t", metadata.BuildBotFlagInspected, wantInspected)
			}
			if metadata.BuildBotFlagged != test.wantFlag || metadata.BuildBotFlagSource != test.wantSource {
				t.Fatalf("flagged/source = %t/%d, want %t/%d", metadata.BuildBotFlagged, metadata.BuildBotFlagSource, test.wantFlag, test.wantSource)
			}
		})
	}

	metadata := adapter.CredentialMetadata(account.Credential{Provider: account.ProviderBuild, EncryptedAccessToken: "invalid-ciphertext"})
	if metadata.BuildBotFlagInspected || metadata.BuildBotFlagged || metadata.BuildBotFlagSource != 0 {
		t.Fatal("decrypt failure must not mark the account")
	}
}

func TestBuildBotFlagSourceFromClaims(t *testing.T) {
	if buildBotFlagSourceFromClaims(nil) != 0 {
		t.Fatal("nil claims must not flag")
	}
	if source := buildBotFlagSourceFromClaims(map[string]any{"bfs": float64(1)}); source != 1 {
		t.Fatalf("bfs=1 source = %d", source)
	}
	if source := buildBotFlagSourceFromClaims(map[string]any{"bot_flag_source": float64(2)}); source != 2 {
		t.Fatalf("bot_flag_source=2 source = %d", source)
	}
	if !buildBotFlaggedFromClaims(map[string]any{"bfs": float64(2)}) {
		t.Fatal("bfs=2 must flag")
	}
	if buildBotFlaggedFromClaims(map[string]any{"bfs": "1", "bot_flag_source": "2"}) {
		t.Fatal("string values must not flag")
	}
}

func TestForwardResponseMatchesGrokBuildHeadersAndPreservesReasoning(t *testing.T) {
	var captured map[string]any
	transport := roundTripFunc(func(r *http.Request) (*http.Response, error) {
		if r.Method != http.MethodPost || r.URL.Path != "/v1/responses" {
			t.Fatalf("request = %s %s", r.Method, r.URL.Path)
		}
		if r.Header.Get("Authorization") != "Bearer access-token" || r.Header.Get("X-XAI-Token-Auth") != "xai-grok-cli" || r.Header.Get("x-authenticateresponse") != "authenticate-response" || r.Header.Get("x-grok-client-version") != "0.2.102" || r.Header.Get("x-grok-client-identifier") != "grok-shell" || r.Header.Get("x-grok-client-mode") != "headless" || r.Header.Get("User-Agent") != "grok-shell/0.2.102 (linux; x86_64)" {
			t.Fatalf("headers = %#v", r.Header)
		}
		requestID := r.Header.Get("x-grok-req-id")
		sessionID := r.Header.Get("x-grok-session-id")
		expectedSessionID, err := grokSessionID("isolated-key")
		if err != nil {
			t.Fatal(err)
		}
		requestUUID, requestErr := uuid.Parse(requestID)
		agentUUID, agentErr := uuid.Parse(r.Header.Get("x-grok-agent-id"))
		if requestErr != nil || requestUUID.Version() != uuid.Version(4) || agentErr != nil || agentUUID.Version() != uuid.Version(4) || sessionID != expectedSessionID || r.Header.Get("x-grok-conv-id") != sessionID || r.Header.Get("x-grok-conv-group-id") != grokConversationGroupID(sessionID) {
			t.Fatalf("client identity headers = %#v", r.Header)
		}
		for _, legacy := range []string{"x-grok-client-surface", "x-grok-client-name", "x-grok-conversation-id", "x-grok-session-id-legacy", "x-grok-request-id"} {
			if r.Header.Get(legacy) != "" {
				t.Fatalf("legacy header %s = %q", legacy, r.Header.Get(legacy))
			}
		}
		if r.Header.Get("x-grok-user-id") != "user-123" || r.Header.Get("x-grok-turn-idx") != "7" || r.Header.Get("x-userid") != "" || r.Header.Get("Accept-Encoding") != "gzip" || len(r.Header.Get("traceparent")) != 55 {
			t.Fatalf("protocol headers = %#v", r.Header)
		}
		if _, ok := r.Header["Tracestate"]; ok {
			t.Fatalf("tracestate = %#v", r.Header["Tracestate"])
		}
		body, _ := io.ReadAll(r.Body)
		if err := json.Unmarshal(body, &captured); err != nil {
			t.Fatal(err)
		}
		return &http.Response{
			StatusCode: http.StatusOK,
			Status:     "200 OK",
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(strings.NewReader(`{"id":"resp_1","object":"response"}`)),
			Request:    r,
		}, nil
	})

	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1", ClientVersion: "0.2.102", ClientIdentifier: "grok-shell", TokenAuth: "xai-grok-cli", UserAgent: "grok-shell/0.2.102 (linux; x86_64)"}, cipher)
	adapter.http.Transport = transport
	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 7, UserID: "user-123", EncryptedAccessToken: encrypted}, Method: http.MethodPost, Path: "/responses",
		Model: "grok-4.5", PromptCacheKey: "isolated-key", GrokTurnIndex: "7", NormalizeBody: true,
		Body: []byte(`{"model":"public","prompt_cache_key":"client-key","input":[{"type":"reasoning","id":"rs_1","encrypted_content":"cipher"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	_ = response.Body.Close()
	input := captured["input"].([]any)
	if captured["model"] != "grok-4.5" || captured["prompt_cache_key"] != "isolated-key" || len(input) != 1 || input[0].(map[string]any)["type"] != "reasoning" || input[0].(map[string]any)["encrypted_content"] != "cipher" {
		t.Fatalf("captured = %#v", captured)
	}
}

func TestNormalizeGrokTurnIndex(t *testing.T) {
	tests := []struct {
		name  string
		value string
		want  string
	}{
		{name: "missing"},
		{name: "zero", value: "0", want: "0"},
		{name: "positive", value: "42", want: "42"},
		{name: "trimmed", value: " 7 ", want: "7"},
		{name: "max uint64", value: "18446744073709551615", want: "18446744073709551615"},
		{name: "negative", value: "-1"},
		{name: "explicit positive", value: "+1"},
		{name: "decimal", value: "1.0"},
		{name: "overflow", value: "18446744073709551616"},
		{name: "too long", value: "000000000000000000001"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := normalizeGrokTurnIndex(test.value); got != test.want {
				t.Fatalf("turn index = %q, want %q", got, test.want)
			}
		})
	}
}

func TestGrokTurnIndexRequiresStableSession(t *testing.T) {
	request := httptest.NewRequest(http.MethodPost, "https://cli-chat-proxy.grok.com/v1/responses", nil)
	applyGrokTurnIndexHeader(request, "7")
	if got := request.Header.Get("x-grok-turn-idx"); got != "" {
		t.Fatalf("turn index without session = %q", got)
	}

	request.Header.Set("x-grok-session-id", "session-1")
	applyGrokTurnIndexHeader(request, "7")
	if got := request.Header.Get("x-grok-turn-idx"); got != "7" {
		t.Fatalf("turn index with session = %q, want 7", got)
	}
}

func TestForwardResponseReplaysReasoningAcrossAccountsAndMessagesTurns(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}

	rawEncrypted := make([]byte, 64)
	for index := range rawEncrypted {
		rawEncrypted[index] = byte(index)
	}
	replayEncrypted := base64.RawStdEncoding.EncodeToString(rawEncrypted)
	requestCount := 0
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.SetReasoningReplay(reasoningreplay.New(
		memory.NewReasoningReplayStore(16),
		reasoningreplay.Config{Enabled: true, TTL: time.Hour},
		nil,
	))
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		requestCount++
		var payload struct {
			Input          []map[string]any `json:"input"`
			PromptCacheKey string           `json:"prompt_cache_key"`
		}
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		switch requestCount {
		case 2:
			expectedSessionID, err := grokSessionID(payload.PromptCacheKey)
			if err != nil {
				t.Fatal(err)
			}
			if payload.PromptCacheKey != "messages-cache-key" || request.Header.Get("x-grok-session-id") != expectedSessionID || len(payload.Input) != 1 || payload.Input[0]["role"] != "user" {
				t.Fatalf("WebSearch replay isolation = key %q input %#v", payload.PromptCacheKey, payload.Input)
			}
		case 3:
			if len(payload.Input) != 4 || payload.Input[0]["role"] != "user" || payload.Input[1]["type"] != "reasoning" || payload.Input[1]["encrypted_content"] != replayEncrypted || payload.Input[2]["role"] != "assistant" || payload.Input[3]["role"] != "user" {
				t.Fatalf("ordinary replay after WebSearch = %#v", payload.Input)
			}
			if _, exists := payload.Input[1]["content"]; exists {
				t.Fatalf("cross-account replay included content: %#v", payload.Input[1])
			}
		}
		body := `{"id":"resp_3","model":"grok-4.5","status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"second"}]}]}`
		if requestCount == 1 {
			body = `{"id":"resp_1","model":"grok-4.5","status":"completed","output":[{"type":"reasoning","encrypted_content":"` + replayEncrypted + `"},{"type":"message","role":"assistant","content":[{"type":"output_text","text":"first"}]}]}`
		} else if requestCount == 2 {
			body = `{"id":"resp_search","model":"grok-4.5","status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"search"}]}]}`
		}
		return &http.Response{
			StatusCode: http.StatusOK,
			Status:     "200 OK",
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(strings.NewReader(body)),
			Request:    request,
		}, nil
	})

	credential := account.Credential{ID: 7, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted}
	first, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: credential, Method: http.MethodPost, Path: "/responses", Model: "grok-4.5",
		NormalizeBody: true, Operation: conversation.OperationMessages, PromptCacheKey: "messages-cache-key", ReasoningReplayKey: "messages-replay-key",
		Body: []byte(`{"model":"public","max_tokens":128,"messages":[{"role":"user","content":"first"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := io.ReadAll(first.Body); err != nil {
		t.Fatal(err)
	}
	if err := first.Body.Close(); err != nil {
		t.Fatal(err)
	}

	webSearch, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: credential, Method: http.MethodPost, Path: "/responses", Model: "grok-4.5",
		NormalizeBody: true, Operation: conversation.OperationMessages, PromptCacheKey: "messages-cache-key", ReasoningReplayKey: "messages-replay-key",
		Body: []byte(`{
			"model":"public","max_tokens":128,
			"messages":[{"role":"user","content":"weather"}],
			"tools":[{"type":"web_search_20250305","name":"web_search"}]
		}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := io.ReadAll(webSearch.Body); err != nil {
		t.Fatal(err)
	}
	if err := webSearch.Body.Close(); err != nil {
		t.Fatal(err)
	}

	otherCredential := credential
	otherCredential.ID = 8
	second, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: otherCredential, Method: http.MethodPost, Path: "/responses", Model: "grok-4.5",
		NormalizeBody: true, Operation: conversation.OperationMessages, PromptCacheKey: "messages-cache-key", ReasoningReplayKey: "messages-replay-key",
		Body: []byte(`{"model":"public","max_tokens":128,"messages":[{"role":"user","content":"first"},{"role":"assistant","content":"first"},{"role":"user","content":"second"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer second.Body.Close()
	if _, err := io.ReadAll(second.Body); err != nil {
		t.Fatal(err)
	}
	if requestCount != 3 {
		t.Fatalf("request count = %d", requestCount)
	}
}

func TestReasoningReplayScopeSharesAccountSeparatesPlane(t *testing.T) {
	adapter := NewAdapter(Config{
		BaseURL:         "https://build.example/v1",
		FallbackBaseURL: "https://xai.example/v1",
	}, nil)
	request := provider.ResponseResourceRequest{
		Credential:         account.Credential{ID: 7},
		ReasoningReplayKey: "explicit-session",
	}
	buildKey := adapter.scopedReasoningReplayKey(request, "https://build.example/v1")
	if buildKey == "" {
		t.Fatal("explicit session did not produce replay scope")
	}
	otherAccount := request
	otherAccount.Credential.ID = 8
	if got := adapter.scopedReasoningReplayKey(otherAccount, "https://build.example/v1"); got != buildKey {
		t.Fatal("reasoning replay scope was not shared across accounts")
	}
	zeroAccount := request
	zeroAccount.Credential.ID = 0
	if got := adapter.scopedReasoningReplayKey(zeroAccount, "https://build.example/v1"); got != buildKey {
		t.Fatal("reasoning replay scope still depended on account identity")
	}
	if got := adapter.scopedReasoningReplayKey(request, "https://xai.example/v1"); got == buildKey {
		t.Fatal("reasoning replay scope was shared across Build and XAI")
	}
	request.ReasoningReplayKey = ""
	if got := adapter.scopedReasoningReplayKey(request, "https://build.example/v1"); got != "" {
		t.Fatalf("soft/empty session unexpectedly enabled replay: %q", got)
	}
}

func TestConversationReasoningReplaySharesExplicitSessionAcrossAccounts(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://build.example/v1"}, cipher)
	var requestCount int
	var secondRequest map[string]any
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		requestCount++
		body, readErr := io.ReadAll(request.Body)
		if readErr != nil {
			return nil, readErr
		}
		if requestCount == 2 {
			if err := json.Unmarshal(body, &secondRequest); err != nil {
				return nil, err
			}
		}
		responseBody := `{"id":"resp_first","model":"grok-4.6","status":"completed","output":[{"id":"rs_first","type":"reasoning","status":"completed","encrypted_content":"portable-proof"},{"id":"fc_first","type":"function_call","call_id":"call_portable","name":"list_dir","arguments":"{}"}]}`
		if requestCount > 1 {
			responseBody = `{"id":"resp_second","model":"grok-4.6","status":"completed","output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"done"}]}]}`
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK",
			Header: http.Header{"Content-Type": []string{"application/json"}},
			Body:   io.NopCloser(strings.NewReader(responseBody)), Request: request,
		}, nil
	})
	firstRequest := provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.6", Operation: conversation.OperationChat,
		ReasoningReplayKey: "portable-session", NormalizeBody: true,
		Body: []byte(`{"model":"public","messages":[{"role":"user","content":"hello"}]}`),
	}
	first, err := adapter.ForwardResponse(context.Background(), firstRequest)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := io.ReadAll(first.Body); err != nil {
		t.Fatal(err)
	}
	_ = first.Body.Close()
	secondRequestInput := firstRequest
	secondRequestInput.Credential.ID = 2
	secondRequestInput.Body = []byte(`{"model":"public","messages":[{"role":"user","content":"hello"},{"role":"assistant","content":null,"tool_calls":[{"id":"call_portable","type":"function","function":{"name":"list_dir","arguments":"{}"}}]},{"role":"tool","tool_call_id":"call_portable","content":"ok"}]}`)
	second, err := adapter.ForwardResponse(context.Background(), secondRequestInput)
	if err != nil {
		t.Fatal(err)
	}
	_ = second.Body.Close()
	if requestCount != 2 {
		t.Fatalf("upstream request count = %d, want 2", requestCount)
	}
	input, ok := secondRequest["input"].([]any)
	if !ok {
		t.Fatalf("second upstream input = %#v", secondRequest["input"])
	}
	found := false
	for _, raw := range input {
		item, ok := raw.(map[string]any)
		if ok && item["type"] == "reasoning" && item["encrypted_content"] == "portable-proof" {
			found = true
			if _, hasContent := item["content"]; hasContent {
				t.Fatalf("replayed opaque reasoning contains content: %#v", item)
			}
		}
	}
	if !found {
		t.Fatalf("portable reasoning was not restored: %#v", input)
	}
	if firstScope := adapter.conversationReasoningScope(firstRequest, adapter.primaryBaseURL()); firstScope == "" || firstScope != adapter.conversationReasoningScope(secondRequestInput, adapter.primaryBaseURL()) {
		t.Fatal("conversation reasoning scope unexpectedly depends on account")
	}
}

func TestListModelsUsesOfficialMetadataHeaders(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1", ClientVersion: "0.2.102", ClientIdentifier: "grok-shell", TokenAuth: "xai-grok-cli", UserAgent: "grok-shell/0.2.102 (linux; x86_64)"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		if request.URL.Path != "/v1/models" || request.Header.Get("Authorization") != "Bearer access-token" || request.Header.Get("X-XAI-Token-Auth") != "xai-grok-cli" || request.Header.Get("x-grok-client-version") != "0.2.102" || request.Header.Get("x-grok-client-identifier") != "grok-shell" || request.Header.Get("x-grok-client-mode") != "headless" || request.Header.Get("User-Agent") != "grok-shell/0.2.102 (linux; x86_64)" {
			t.Fatalf("headers = %#v", request.Header)
		}
		if request.Header.Get("x-userid") != "user-123" || request.Header.Get("x-email") != "user@example.com" || request.Header.Get("x-grok-user-id") != "" || request.Header.Get("x-authenticateresponse") != "" || request.Header.Get("x-grok-session-id") != "" {
			t.Fatalf("metadata headers = %#v", request.Header)
		}
		return &http.Response{StatusCode: http.StatusOK, Status: "200 OK", Header: make(http.Header), Body: io.NopCloser(strings.NewReader(`{"data":[{"id":"grok-4.5"}]}`)), Request: request}, nil
	})
	models, err := adapter.ListModels(context.Background(), account.Credential{UserID: "user-123", Email: "user@example.com", EncryptedAccessToken: encrypted})
	if err != nil {
		t.Fatal(err)
	}
	if len(models) != 1 || models[0] != "grok-4.5" {
		t.Fatalf("models = %#v", models)
	}
}

func TestListModelsParsesOfficialIdentifierFallbacksAdditively(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		body := `{"data":[
			{"id":"grok-4.5","model":"must-not-replace-id"},
			{"model":"grok-composer-2.5-fast"},
			{"modelId":"future-model"},
			{"_meta":{"model":"meta-model"}},
			{"_meta":{"modelId":"meta-id-model"}},
			{"id":"hidden-model","hidden":true},
			{"id":"meta-hidden-model","_meta":{"hidden":true}},
			{"id":"grok-4.5"},
			"malformed"
		]}`
		return &http.Response{StatusCode: http.StatusOK, Status: "200 OK", Header: make(http.Header), Body: io.NopCloser(strings.NewReader(body)), Request: request}, nil
	})
	models, err := adapter.ListModels(context.Background(), account.Credential{EncryptedAccessToken: encrypted})
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"grok-4.5", modeldomain.GrokComposer25Fast, "future-model", "meta-model", "meta-id-model"}
	if len(models) != len(want) {
		t.Fatalf("models = %#v, want %#v", models, want)
	}
	for index := range want {
		if models[index] != want[index] {
			t.Fatalf("models = %#v, want %#v", models, want)
		}
	}
}

func TestModelCatalogETagSignalsMissingOrChangedCatalogBaseline(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	modelETag := `"catalog-v1"`
	responseETag := modelETag
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		header := make(http.Header)
		body := `{"id":"resp_1","status":"completed","output":[]}`
		if request.URL.Path == "/v1/models" {
			header.Set("ETag", modelETag)
			body = `{"data":[{"id":"grok-4.5"}]}`
		} else {
			header.Set("x-models-etag", responseETag)
		}
		return &http.Response{StatusCode: http.StatusOK, Status: "200 OK", Header: header, Body: io.NopCloser(strings.NewReader(body)), Request: request}, nil
	})
	credential := account.Credential{ID: 42, EncryptedAccessToken: encrypted}
	if !adapter.modelCatalogChanged(43, `"catalog-v1"`) {
		t.Fatal("缺少进程内目录基线时应补一次账号模型同步")
	}
	if _, err := adapter.ListModels(context.Background(), credential); err != nil {
		t.Fatal(err)
	}
	forward := func() *provider.Response {
		response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
			Credential: credential, Method: http.MethodPost, Path: "/responses", Body: []byte(`{}`), Operation: conversation.OperationResponses,
		})
		if err != nil {
			t.Fatal(err)
		}
		defer response.Body.Close()
		return response
	}
	if response := forward(); response.ModelCatalogChanged {
		t.Fatal("与最近模型同步相同的 ETag 不应触发刷新")
	}
	responseETag = `"catalog-v2"`
	if response := forward(); !response.ModelCatalogChanged {
		t.Fatal("推理响应报告新 ETag 时应触发账号模型刷新")
	}
	modelETag = responseETag
	if _, err := adapter.ListModels(context.Background(), credential); err != nil {
		t.Fatal(err)
	}
	if response := forward(); response.ModelCatalogChanged {
		t.Fatal("成功同步新目录后不应继续重复触发刷新")
	}
}

func TestGetBillingUsesCreditsAndLiveSubscriptionTier(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1", ClientVersion: "0.2.102", ClientIdentifier: "grok-shell", TokenAuth: "xai-grok-cli", UserAgent: "grok-shell/0.2.102 (linux; x86_64)"}, cipher)
	calls := 0
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		calls++
		var body string
		switch request.URL.Path {
		case "/v1/billing":
			if request.URL.Query().Get("format") != "credits" {
				t.Fatalf("billing request = %s", request.URL.String())
			}
			body = `{"config":{"creditUsagePercent":0,"currentPeriod":{"type":"USAGE_PERIOD_TYPE_WEEKLY","start":"2026-07-01T00:00:00Z","end":"2026-07-08T00:00:00Z"}}}`
		case "/v1/user":
			if request.URL.Query().Get("include") != "subscription" {
				t.Fatalf("subscription request = %s", request.URL.String())
			}
			body = `{"subscriptionTier":"SuperGrokPro"}`
		default:
			t.Fatalf("unexpected request = %s", request.URL.String())
		}
		return &http.Response{StatusCode: http.StatusOK, Status: "200 OK", Header: make(http.Header), Body: io.NopCloser(strings.NewReader(body)), Request: request}, nil
	})
	billing, err := adapter.GetBilling(context.Background(), account.Credential{ID: 7, EncryptedAccessToken: encrypted})
	if err != nil {
		t.Fatal(err)
	}
	if calls != 2 || billing.AccountID != 7 || billing.CreditUsagePercent != 0 || billing.UsagePeriodType != "USAGE_PERIOD_TYPE_WEEKLY" || billing.PlanName != "SuperGrokPro" || !billing.IsPaid() || billing.SyncedAt.IsZero() {
		t.Fatalf("calls=%d billing=%#v", calls, billing)
	}
}

func TestNormalizeAccountModelCapabilitiesSuperAddsVideo15(t *testing.T) {
	adapter := &Adapter{}
	build := account.Credential{Provider: account.ProviderBuild}
	// Super / paid: add 1.5 even when primary Build returns only grok-4.5.
	got := adapter.NormalizeAccountModelCapabilities([]string{"grok-4.5", "  ", "grok-4.5"}, &account.Billing{MonthlyLimit: 100}, build)
	if len(got) != 2 || got[0] != "grok-4.5" || got[1] != buildVideoModel {
		t.Fatalf("super primary catalog = %#v", got)
	}
	// Super with 1.5 already present: deduplicate idempotently and preserve other models.
	got = adapter.NormalizeAccountModelCapabilities(
		[]string{"grok-4.5", buildVideoModel, "grok-code-fast-1", buildVideoModel},
		&account.Billing{OnDemandCap: 10},
		build,
	)
	if len(got) != 3 || got[0] != "grok-4.5" || got[1] != buildVideoModel || got[2] != "grok-code-fast-1" {
		t.Fatalf("super catalog = %#v", got)
	}
	// Free: remove 1.5 even when the catalog exposes it.
	got = adapter.NormalizeAccountModelCapabilities([]string{"grok-4.5", buildVideoModel}, &account.Billing{Used: 1, PlanName: "free"}, build)
	if len(got) != 1 || got[0] != "grok-4.5" {
		t.Fatalf("free catalog = %#v", got)
	}
	// Unknown (no Billing): treat as Free and remove 1.5.
	got = adapter.NormalizeAccountModelCapabilities([]string{buildVideoModel, "grok-4.5"}, nil, build)
	if len(got) != 1 || got[0] != "grok-4.5" {
		t.Fatalf("unknown catalog = %#v", got)
	}
	// Do not depend on BuildAPIFallback; an empty catalog with Billing Super adds only 1.5.
	got = adapter.NormalizeAccountModelCapabilities(nil, &account.Billing{PlanName: "SuperGrok", CreditUsagePercent: 1}, build)
	if len(got) != 1 || got[0] != buildVideoModel {
		t.Fatalf("super empty catalog = %#v", got)
	}
	// Zero-value Billing with BuildSuperEntitled: add 1.5.
	entitled := account.Credential{Provider: account.ProviderBuild, BuildSuperEntitled: true}
	got = adapter.NormalizeAccountModelCapabilities([]string{"grok-4.5"}, &account.Billing{IsUnifiedBillingUser: true}, entitled)
	if len(got) != 2 || got[0] != "grok-4.5" || got[1] != buildVideoModel {
		t.Fatalf("entitled catalog = %#v", got)
	}
}

func TestNormalizeAccountModelCapabilitiesAddsComposerOnlyForBuildOAuth(t *testing.T) {
	adapter := &Adapter{}
	oauth := account.Credential{Provider: account.ProviderBuild, AuthType: account.AuthTypeOAuth}
	got := adapter.NormalizeAccountModelCapabilities([]string{"grok-4.5"}, &account.Billing{PlanName: "free"}, oauth)
	if len(got) != 2 || got[0] != "grok-4.5" || got[1] != modeldomain.GrokComposer25Fast {
		t.Fatalf("OAuth Free capabilities = %#v", got)
	}
	got = adapter.NormalizeAccountModelCapabilities([]string{"grok-4.5", modeldomain.GrokComposer25Fast, modeldomain.GrokComposer25Fast}, nil, oauth)
	if len(got) != 2 || got[0] != "grok-4.5" || got[1] != modeldomain.GrokComposer25Fast {
		t.Fatalf("Composer capability was not deduplicated: %#v", got)
	}
	for _, credential := range []account.Credential{
		{Provider: account.ProviderBuild, AuthType: account.AuthTypeSSO},
		{Provider: account.ProviderWeb, AuthType: account.AuthTypeOAuth},
	} {
		got = adapter.NormalizeAccountModelCapabilities([]string{"grok-4.5"}, nil, credential)
		if len(got) != 1 || got[0] != "grok-4.5" {
			t.Fatalf("Composer leaked outside Build OAuth for %#v: %#v", credential, got)
		}
	}
}

func TestNormalizeAccountModelCapabilitiesKeepsGrok45ForBuildGrok46(t *testing.T) {
	adapter := &Adapter{}
	build := account.Credential{Provider: account.ProviderBuild}
	got := adapter.NormalizeAccountModelCapabilities([]string{buildGrok46Model}, nil, build)
	if len(got) != 2 || got[0] != buildGrok46Model || got[1] != buildGrok45Model {
		t.Fatalf("Build Grok 4.6 compatibility capabilities = %#v", got)
	}

	got = adapter.NormalizeAccountModelCapabilities([]string{buildGrok45Model, buildGrok46Model, buildGrok45Model}, nil, build)
	if len(got) != 2 || got[0] != buildGrok45Model || got[1] != buildGrok46Model {
		t.Fatalf("Build Grok 4.5 compatibility was not deduplicated: %#v", got)
	}

	console := account.Credential{Provider: account.ProviderConsole}
	got = adapter.NormalizeAccountModelCapabilities([]string{buildGrok46Model}, nil, console)
	if len(got) != 1 || got[0] != buildGrok46Model {
		t.Fatalf("Build compatibility leaked to Console: %#v", got)
	}
}

func TestGrokSessionIDFollowsConversationIdentity(t *testing.T) {
	explicit := "019f6b02-5bae-7cf3-b26e-73e85c861749"
	if value, err := grokSessionID(explicit); err != nil || value != explicit {
		t.Fatalf("explicit session = %q, %v", value, err)
	}
	first, err := grokSessionID("client-conversation")
	if err != nil {
		t.Fatal(err)
	}
	second, err := grokSessionID("client-conversation")
	if err != nil {
		t.Fatal(err)
	}
	parsed, err := uuid.Parse(first)
	if err != nil || parsed.Version() != uuid.Version(8) || first != second {
		t.Fatalf("derived sessions = %q %q, %v", first, second, err)
	}
	// Never fabricate a random conv-id without a session key; it breaks xAI server affinity and keeps cached_tokens at zero.
	generated, err := grokSessionID("")
	if err != nil {
		t.Fatal(err)
	}
	if generated != "" {
		t.Fatalf("empty session key must not invent conv-id, got %q", generated)
	}
}

func TestInferenceIdentityIsConversationScopedNotAccountScoped(t *testing.T) {
	adapter := NewAdapter(Config{ClientVersion: "0.2.102", ClientIdentifier: "grok-shell", TokenAuth: "xai-grok-cli", UserAgent: "grok-shell/0.2.102 (linux; x86_64)"}, nil)
	build := func(accountID uint64, conversation string) http.Header {
		request := httptest.NewRequest(http.MethodPost, "https://cli-chat-proxy.grok.com/v1/responses", nil)
		if err := adapter.applyHeaders(request, account.Credential{ID: accountID}, "token", "grok-4.5", conversation, true); err != nil {
			t.Fatal(err)
		}
		return request.Header
	}
	first := build(1, "conversation-a")
	second := build(2, "conversation-a")
	third := build(1, "conversation-b")
	if first.Get("x-grok-agent-id") != second.Get("x-grok-agent-id") || first.Get("x-grok-session-id") != second.Get("x-grok-session-id") {
		t.Fatalf("same conversation identity changed across accounts: first=%#v second=%#v", first, second)
	}
	if first.Get("x-grok-req-id") == second.Get("x-grok-req-id") {
		t.Fatalf("request ID was reused: %q", first.Get("x-grok-req-id"))
	}
	if first.Get("x-grok-session-id") == third.Get("x-grok-session-id") {
		t.Fatalf("different conversations shared session ID: %q", first.Get("x-grok-session-id"))
	}
}

func TestForwardResponseSupportsResourceMethodsAndQuery(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1", ClientVersion: "0.2.102", ClientIdentifier: "grok-shell", TokenAuth: "xai-grok-cli", UserAgent: "grok-shell/0.2.102 (linux; x86_64)"}, cipher)
	methods := []string{http.MethodGet, http.MethodDelete}
	next := 0
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		if request.Method != methods[next] || request.URL.Path != "/v1/responses/resp_1" || request.URL.RawQuery != "include=reasoning.encrypted_content" {
			t.Fatalf("request = %s %s", request.Method, request.URL.RequestURI())
		}
		if request.Header.Get("Accept") != "application/json" || request.Header.Get("Content-Type") != "" {
			t.Fatalf("headers = %#v", request.Header)
		}
		if request.Body != nil {
			t.Fatal("resource request unexpectedly gained a body")
		}
		next++
		return &http.Response{StatusCode: http.StatusOK, Status: "200 OK", Header: make(http.Header), Body: io.NopCloser(strings.NewReader(`{"id":"resp_1"}`)), Request: request}, nil
	})

	for _, method := range methods {
		response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
			Credential:     account.Credential{Provider: account.ProviderBuild, AuthType: account.AuthTypeOAuth, EncryptedAccessToken: encrypted},
			Method:         method,
			Path:           "/responses/resp_1?include=reasoning.encrypted_content",
			PromptCacheKey: "resource-cache-key",
		})
		if err != nil {
			t.Fatal(err)
		}
		_ = response.Body.Close()
	}
	if next != len(methods) {
		t.Fatalf("requests = %d", next)
	}
}

func TestForwardResponseDecodesExplicitGzipResponse(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	var compressed bytes.Buffer
	writer := gzip.NewWriter(&compressed)
	if _, err := writer.Write([]byte(`{"id":"resp_gzip"}`)); err != nil {
		t.Fatal(err)
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		if request.Header.Get("Accept-Encoding") != "gzip" {
			t.Fatalf("Accept-Encoding = %q", request.Header.Get("Accept-Encoding"))
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK",
			Header: http.Header{"Content-Encoding": []string{"gzip"}, "Content-Length": []string{"999"}},
			Body:   io.NopCloser(bytes.NewReader(compressed.Bytes())), Request: request,
		}, nil
	})
	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 8, EncryptedAccessToken: encrypted}, Method: http.MethodPost, Path: "/responses",
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(response.Body)
	if err != nil {
		t.Fatal(err)
	}
	if string(body) != `{"id":"resp_gzip"}` || response.Header.Get("Content-Encoding") != "" || response.Header.Get("Content-Length") != "" {
		t.Fatalf("body=%q headers=%#v", body, response.Header)
	}
}

func TestForwardResponseDowngradesServerToolSearchBeforeUpstream(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		var payload map[string]any
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		if _, exists := payload["tools"]; exists {
			t.Fatalf("server tool_search 未从上游请求移除: %#v", payload)
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK",
			Header:  http.Header{"Content-Type": []string{"application/json"}},
			Body:    io.NopCloser(strings.NewReader(`{"id":"resp_search"}`)),
			Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5",
		NormalizeBody: true, Operation: conversation.OperationResponses,
		Body: []byte(`{"model":"public","input":"hello","tools":[{"type":"tool_search"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		t.Fatalf("status = %d", response.StatusCode)
	}
	if !strings.Contains(response.Header.Get("X-Grok2API-Compatibility-Warnings"), "server_tool_search_eager_loaded") {
		t.Fatalf("compatibility warnings = %q", response.Header.Get("X-Grok2API-Compatibility-Warnings"))
	}
	var payload map[string]any
	if err := json.NewDecoder(response.Body).Decode(&payload); err != nil {
		t.Fatal(err)
	}
	if payload["id"] != "resp_search" {
		t.Fatalf("response = %#v", payload)
	}
}

func TestForwardResponseRestoresNamespaceResponse(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		var payload map[string]any
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		tools := payload["tools"].([]any)
		if len(tools) != 1 || tools[0].(map[string]any)["name"] != "crm__lookup" {
			t.Fatalf("上游 tools = %#v", tools)
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK",
			Header: http.Header{"Content-Type": []string{"application/json"}},
			Body: io.NopCloser(strings.NewReader(`{
				"id":"resp_1","object":"response",
				"tools":[{"type":"function","name":"crm__lookup"}],
				"output":[{"type":"function_call","call_id":"call_1","name":"crm__lookup","arguments":"{}"}]
			}`)),
			Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5",
		NormalizeBody: true, Operation: conversation.OperationResponses,
		Body: []byte(`{
			"model":"public","input":"lookup",
			"tools":[{"type":"namespace","name":"crm","tools":[{"type":"function","name":"lookup","parameters":{"type":"object"}}]}]
		}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.Header.Get("X-Grok2API-Compatibility-Warnings") != "namespace_flattened" {
		t.Fatalf("compatibility warnings = %q", response.Header.Get("X-Grok2API-Compatibility-Warnings"))
	}
	var payload map[string]any
	if err := json.NewDecoder(response.Body).Decode(&payload); err != nil {
		t.Fatal(err)
	}
	call := payload["output"].([]any)[0].(map[string]any)
	if call["name"] != "lookup" || call["namespace"] != "crm" {
		t.Fatalf("下游 function_call = %#v", call)
	}
	tools := payload["tools"].([]any)
	if len(tools) != 1 || tools[0].(map[string]any)["type"] != "namespace" {
		t.Fatalf("下游 tools = %#v", tools)
	}
}

func TestForwardResponseAliasesTopLevelViewImageForBuild(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		var payload map[string]any
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		tools, ok := payload["tools"].([]any)
		if !ok || len(tools) != 1 || tools[0].(map[string]any)["name"] != "grok2api_view_image" {
			t.Fatalf("Build tools = %#v", payload["tools"])
		}
		if payload["tool_choice"] != "auto" {
			t.Fatalf("Build tool_choice = %#v", payload["tool_choice"])
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK",
			Header: http.Header{"Content-Type": []string{"application/json"}},
			Body: io.NopCloser(strings.NewReader(`{
				"id":"resp_view_image",
				"tools":[{"type":"function","name":"grok2api_view_image"}],
				"output":[{"type":"function_call","call_id":"call_1","name":"grok2api_view_image","arguments":"{}"}]
			}`)),
			Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 8, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.6",
		NormalizeBody: true, Operation: conversation.OperationResponses,
		Body: []byte(`{
			"model":"grok-4.6","input":[{"type":"message","role":"user","content":[{"type":"input_text","text":"hello"}]}],
			"tools":[{"type":"function","name":"view_image","description":"View a local image","parameters":{"type":"object","properties":{},"required":[]}}],
			"tool_choice":"auto"
		}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		t.Fatalf("status = %d", response.StatusCode)
	}
	if response.Header.Get("X-Grok2API-Compatibility-Warnings") != "view_image_name_normalized" {
		t.Fatalf("compatibility warnings = %q", response.Header.Get("X-Grok2API-Compatibility-Warnings"))
	}
	var payload map[string]any
	if err := json.NewDecoder(response.Body).Decode(&payload); err != nil {
		t.Fatal(err)
	}
	call := payload["output"].([]any)[0].(map[string]any)
	if call["name"] != "view_image" {
		t.Fatalf("client function call = %#v", call)
	}
	visibleTools := payload["tools"].([]any)
	if visibleTools[0].(map[string]any)["name"] != "view_image" {
		t.Fatalf("client tools = %#v", visibleTools)
	}
}

func TestForwardResponsePreservesClaudeCodeMessagesOptions(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		var payload map[string]any
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		if payload["instructions"] != "legacy system" || payload["store"] != false || payload["reasoning"].(map[string]any)["effort"] != "high" || payload["prompt_cache_key"] != "messages-cache-key" {
			t.Fatalf("upstream payload = %#v", payload)
		}
		expectedSessionID, err := grokSessionID("messages-cache-key")
		if err != nil {
			t.Fatal(err)
		}
		if request.Header.Get("x-grok-conv-id") != expectedSessionID || request.Header.Get("x-grok-session-id") != expectedSessionID {
			t.Fatalf("prompt cache headers = %#v", request.Header)
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK", Header: http.Header{"Content-Type": []string{"application/json"}},
			Body: io.NopCloser(strings.NewReader(`{
				"id":"resp_1","model":"grok-4.5","status":"completed",
				"output":[
					{"type":"reasoning","summary":[{"type":"summary_text","text":"thought"}],"encrypted_content":"signature"},
					{"type":"message","content":[{"type":"output_text","text":"ABCSTOPXYZ"}]}
				]
			}`)),
			Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", NormalizeBody: true, PromptCacheKey: "messages-cache-key",
		Operation: conversation.OperationMessages,
		Body: []byte(`{
			"model":"public","max_tokens":256,"stop_sequences":["STOP"],
			"thinking":{"type":"enabled","budget_tokens":20000},
			"output_config":{"effort":"max"},
			"messages":[{"role":"system","content":"legacy system"},{"role":"user","content":"hello"}]
		}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	var payload map[string]any
	if err := json.NewDecoder(response.Body).Decode(&payload); err != nil {
		t.Fatal(err)
	}
	content := payload["content"].([]any)
	if payload["stop_reason"] != "stop_sequence" || payload["stop_sequence"] != "STOP" || content[0].(map[string]any)["type"] != "thinking" || content[1].(map[string]any)["text"] != "ABC" {
		t.Fatalf("messages response = %#v", payload)
	}
}

func TestForwardResponseMapsClaudeCodeWebSearchEndToEnd(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		var payload map[string]any
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		tools, _ := payload["tools"].([]any)
		if len(tools) != 1 || tools[0].(map[string]any)["type"] != "web_search" || payload["tool_choice"] != "required" {
			t.Fatalf("upstream web search payload = %#v", payload)
		}
		domains := tools[0].(map[string]any)["filters"].(map[string]any)["allowed_domains"].([]any)
		if len(domains) != 1 || domains[0] != "doc.rust-lang.org" {
			t.Fatalf("upstream web search filters = %#v", tools[0])
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK", Header: http.Header{"Content-Type": []string{"application/json"}},
			Body: io.NopCloser(strings.NewReader(`{
				"id":"resp_search","model":"grok-4.5","status":"completed",
				"output":[
					{"type":"web_search_call","id":"ws_1","status":"completed","action":{"type":"search","query":"rust tutorials","sources":[{"url":"https://doc.rust-lang.org"}]}},
					{"type":"message","content":[{"type":"output_text","text":"Here you go.","annotations":[{"type":"url_citation","url":"https://doc.rust-lang.org","title":"The Rust Book"}]}]}
				],
					"usage":{"input_tokens":7,"output_tokens":5,"total_tokens":12,"cost_in_usd_ticks":12000,"context_details":{"input_tokens":6,"output_tokens":4}}
			}`)),
			Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", NormalizeBody: true,
		Operation: conversation.OperationMessages,
		Body: []byte(`{
			"model":"public","max_tokens":256,
			"messages":[{"role":"user","content":"Perform a web search for the query: rust tutorials"}],
			"tools":[{"type":"web_search_20250305","name":"web_search","max_uses":8,"allowed_domains":["doc.rust-lang.org"]}],
			"tool_choice":{"type":"tool","name":"web_search"}
		}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	var payload map[string]any
	if err := json.NewDecoder(response.Body).Decode(&payload); err != nil {
		t.Fatal(err)
	}
	content := payload["content"].([]any)
	if len(content) != 3 || content[0].(map[string]any)["type"] != "server_tool_use" || content[1].(map[string]any)["type"] != "web_search_tool_result" || content[2].(map[string]any)["text"] != "Here you go." {
		t.Fatalf("messages web search response = %#v", payload)
	}
	use := content[0].(map[string]any)
	if use["input"].(map[string]any)["query"] != "rust tutorials" || content[1].(map[string]any)["tool_use_id"] != use["id"] {
		t.Fatalf("web search block linkage = %#v", content)
	}
	hits := content[1].(map[string]any)["content"].([]any)
	if len(hits) != 1 || hits[0].(map[string]any)["title"] != "The Rust Book" {
		t.Fatalf("web search hits = %#v", hits)
	}
	serverUsage := payload["usage"].(map[string]any)["server_tool_use"].(map[string]any)
	if serverUsage["web_search_requests"] != float64(1) || payload["stop_reason"] != "end_turn" {
		t.Fatalf("messages web search usage = %#v", payload)
	}
	usage := payload["usage"].(map[string]any)
	if usage["cost_in_usd_ticks"] != float64(12000) || usage["context_details"].(map[string]any)["input_tokens"] != float64(6) {
		t.Fatalf("messages upstream usage = %#v", usage)
	}
}

func TestForwardResponseInjectsPromptCacheKeyAfterChatConversion(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		var payload map[string]any
		if err := json.NewDecoder(request.Body).Decode(&payload); err != nil {
			t.Fatal(err)
		}
		includes, _ := payload["include"].([]any)
		if payload["store"] != false || len(includes) != 1 || includes[0] != "reasoning.encrypted_content" {
			t.Fatalf("Build defaults = %#v", payload)
		}
		expectedSessionID, err := grokSessionID("chat-cache-key")
		if err != nil {
			t.Fatal(err)
		}
		if payload["prompt_cache_key"] != "chat-cache-key" || request.Header.Get("x-grok-conv-id") != expectedSessionID || request.Header.Get("x-grok-session-id") != expectedSessionID {
			t.Fatalf("prompt cache request: payload=%#v headers=%#v", payload, request.Header)
		}
		return &http.Response{
			StatusCode: http.StatusOK, Status: "200 OK", Header: http.Header{"Content-Type": []string{"application/json"}},
			Body: io.NopCloser(strings.NewReader(`{
				"id":"resp_1","model":"grok-4.5","status":"completed",
				"output":[{"type":"message","role":"assistant","content":[{"type":"output_text","text":"ok"}]}],
				"usage":{"input_tokens":11,"output_tokens":2,"cost_in_usd_ticks":7000,"context_details":{"input_tokens":10,"output_tokens":2}}
			}`)),
			Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{Provider: account.ProviderBuild, AuthType: account.AuthTypeOAuth, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", NormalizeBody: true,
		Operation: conversation.OperationChat, PromptCacheKey: "chat-cache-key",
		Body: []byte(`{"model":"public","messages":[{"role":"user","content":"hello"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		t.Fatalf("status = %d", response.StatusCode)
	}
	var payload map[string]any
	if err := json.NewDecoder(response.Body).Decode(&payload); err != nil {
		t.Fatal(err)
	}
	usage := payload["usage"].(map[string]any)
	if payload["object"] != "chat.completion" || usage["prompt_tokens"] != float64(11) || usage["cost_in_usd_ticks"] != float64(7000) || usage["context_details"].(map[string]any)["input_tokens"] != float64(10) {
		t.Fatalf("chat response = %#v", payload)
	}
}

func TestForwardResponseRejectsInvalidChatWebSearchBeforeUpstream(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	upstreamCalled := false
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		upstreamCalled = true
		return nil, errors.New("unexpected upstream call")
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{Provider: account.ProviderBuild, AuthType: account.AuthTypeOAuth, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.6", NormalizeBody: true,
		Operation: conversation.OperationChat,
		Body: []byte(`{
			"model":"public","messages":[{"role":"user","content":"search"}],
			"tools":[{"type":"web_search","filters":{"allowed_domains":["allow.example"],"excluded_domains":["deny.example"]}}]
		}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if upstreamCalled || response.StatusCode != http.StatusBadRequest {
		t.Fatalf("upstreamCalled=%v status=%d", upstreamCalled, response.StatusCode)
	}
}

func TestShouldSkipXAIFallbackForSafetyAndBlocked(t *testing.T) {
	if !shouldSkipXAIFallback([]byte(`{"code":"permission-denied","error":"Content violates usage guidelines. SAFETY_CHECK_TYPE_VIOLENCE"}`)) {
		t.Fatal("safety body must skip XAI fallback")
	}
	if !shouldSkipXAIFallback([]byte(`{"code":"unauthorized:blocked-user","error":"User is blocked"}`)) {
		t.Fatal("blocked body must skip XAI fallback")
	}
	if shouldSkipXAIFallback([]byte(`{"code":"permission-denied","error":"Access to the chat endpoint is denied"}`)) {
		t.Fatal("ordinary permission denial may still probe XAI for Super Auto accounts")
	}
}

func TestParseBuildTeamRPSRateLimitMetadata(t *testing.T) {
	body := []byte(`{"code":"resource-exhausted","error":"Too many requests for team 00000000-0000-0000-0000-000000000013 and model grok-4.20. Requests per Second (actual/limit): 2/2."}`)
	metadata := provider.ParseRateLimitMetadata(body)
	if metadata == nil {
		t.Fatal("expected rate limit metadata")
	}
	if metadata.Scope != provider.RateLimitScopeRPS || metadata.TeamID != "00000000-0000-0000-0000-000000000013" || metadata.Model != "grok-4.20" || metadata.Actual != 2 || metadata.Limit != 2 {
		t.Fatalf("metadata = %#v", metadata)
	}
}

func TestForwardResponsePreservesTruncatedRateLimitDiagnostic(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	body := `{"code":"resource-exhausted","error":"Too many requests"}` + strings.Repeat("x", provider.MaxDiagnosticBodyBytes)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: http.StatusTooManyRequests, Status: "429 Too Many Requests", Header: make(http.Header),
			Body: io.NopCloser(strings.NewReader(body)), Request: request,
		}, nil
	})

	response, err := adapter.ForwardResponse(context.Background(), provider.ResponseResourceRequest{
		Credential: account.Credential{Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", NormalizeBody: true,
		Body: []byte(`{"model":"grok-4.5","input":"hello"}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.Diagnostic == nil || !response.Diagnostic.BodyTruncated || len(response.Diagnostic.Body) != provider.MaxDiagnosticBodyBytes {
		t.Fatalf("diagnostic = %#v", response.Diagnostic)
	}
}

// TestListModelsRegistersUpstreamReasoningMenu replays a real cli-chat-proxy
// /v1/models payload (grok-build 1.0.40 era) and checks the live reasoning
// menu drives domain capabilities the same way it drives grok-build's picker.
func TestListModelsRegistersUpstreamReasoningMenu(t *testing.T) {
	modeldomain.ResetUpstreamProfiles()
	t.Cleanup(modeldomain.ResetUpstreamProfiles)
	catalog, err := os.ReadFile("testdata/build_models_catalog.json")
	if err != nil {
		t.Fatal(err)
	}
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{BaseURL: "https://cli-chat-proxy.grok.com/v1"}, cipher)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: http.StatusOK, Status: "200 OK", Header: make(http.Header), Body: io.NopCloser(bytes.NewReader(catalog)), Request: request}, nil
	})
	models, err := adapter.ListModels(context.Background(), account.Credential{EncryptedAccessToken: encrypted})
	if err != nil {
		t.Fatal(err)
	}
	if len(models) != 2 || models[0] != "grok-4.7" || models[1] != "grok-4.6" {
		t.Fatalf("models = %#v", models)
	}
	for _, model := range models {
		profile, ok := modeldomain.UpstreamProfile(model)
		if !ok {
			t.Fatalf("%s profile not registered", model)
		}
		wantMenu := []string{"xhigh", "high", "medium", "low"}
		if strings.Join(profile.ReasoningEfforts, ",") != strings.Join(wantMenu, ",") || profile.DefaultReasoningEffort != "high" || !profile.SupportsReasoningEffort || profile.ContextWindow != 500000 {
			t.Fatalf("%s profile = %#v", model, profile)
		}
		if got := modeldomain.DefaultReasoningEffort(model); got != "high" {
			t.Fatalf("%s default = %q", model, got)
		}
		if !modeldomain.SupportsReasoningEffort(model, "xhigh") || modeldomain.SupportsReasoningEffort(model, "max") || modeldomain.SupportsReasoningEffort(model, "none") {
			t.Fatalf("%s effort gate drifted from catalog", model)
		}
	}
	if profile, _ := modeldomain.UpstreamProfile("grok-4.7"); profile.MaxCompletionTokens != 1000000 || !profile.SupportsBackendSearch {
		t.Fatalf("grok-4.7 profile = %#v", profile)
	}
	if profile, _ := modeldomain.UpstreamProfile("grok-4.6"); profile.MaxCompletionTokens != 0 || profile.SupportsBackendSearch {
		t.Fatalf("grok-4.6 profile = %#v", profile)
	}
}

func TestCatalogEntryReasoningMenuAcceptsBareAndObjectEntries(t *testing.T) {
	var entry buildModelCatalogEntry
	if err := json.Unmarshal([]byte(`{"id":"m","reasoningEfforts":["low",{"value":"max","default":true},{"label":"no value"},"","medium"],"contextWindow":1234,"supportsReasoningEffort":true}`), &entry); err != nil {
		t.Fatal(err)
	}
	profile := modeldomain.NormalizeUpstreamProfile(entry.upstreamProfile())
	if strings.Join(profile.ReasoningEfforts, ",") != "low,max,medium" || profile.DefaultReasoningEffort != "max" || profile.ContextWindow != 1234 || !profile.SupportsReasoningEffort {
		t.Fatalf("profile = %#v", profile)
	}
}
