package cli

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"math"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/google/uuid"

	"github.com/chenyme/grok2api/backend/internal/domain/account"
	modeldomain "github.com/chenyme/grok2api/backend/internal/domain/model"
	settingsdomain "github.com/chenyme/grok2api/backend/internal/domain/settings"
	"github.com/chenyme/grok2api/backend/internal/infra/buildtransport"
	infraegress "github.com/chenyme/grok2api/backend/internal/infra/egress"
	"github.com/chenyme/grok2api/backend/internal/infra/provider"
	"github.com/chenyme/grok2api/backend/internal/infra/provider/conversation"
	providerstreamidle "github.com/chenyme/grok2api/backend/internal/infra/provider/streamidle"
	"github.com/chenyme/grok2api/backend/internal/infra/security"
	neterrorpkg "github.com/chenyme/grok2api/backend/internal/pkg/neterror"
	"github.com/chenyme/grok2api/backend/internal/pkg/reasoningreplay"
)

type Config struct {
	BaseURL               string
	FallbackBaseURL       string
	ClientVersion         string
	ClientIdentifier      string
	TokenAuth             string
	UserAgent             string
	ResponseHeaderTimeout time.Duration
	StreamIdleTimeout     time.Duration
}

const (
	subscriptionTierTimeout = 10 * time.Second
	buildControlTimeout     = 30 * time.Second
	buildGrok45Model        = "grok-4.5"
	buildGrok46Model        = "grok-4.6"
)

// Adapter implements the Grok Build CLI Responses, model, Billing, and OAuth protocols.
type Adapter struct {
	cfgMu          sync.RWMutex
	cfg            Config
	http           *http.Client
	oauth          *oauthClient
	cipher         *security.Cipher
	base           *buildDirectTransport
	agentID        string
	modelsMu       sync.Mutex
	modelsETags    map[uint64]string
	fallbackMarker FallbackMarker
	uploadIssuer   VideoUploadIssuer
	replay         *reasoningreplay.ReasoningReplay
	// conversationReasoningCache bridges Chat/Messages tool calls to the
	// upstream Responses reasoning proof. It is deliberately separate from
	// the persistent native Responses replay, and its keys never contain an
	// account ID: encrypted reasoning is portable across Build accounts.
	conversationReasoningCache *conversation.ReasoningCache
	compaction                 *gatewayCompactionCodec
	logger                     *slog.Logger
}

func NewAdapter(cfg Config, cipher *security.Cipher) *Adapter {
	cfg.ResponseHeaderTimeout = normalizeBuildResponseHeaderTimeout(cfg.ResponseHeaderTimeout)
	cfg.StreamIdleTimeout = normalizeBuildStreamIdleTimeout(cfg.StreamIdleTimeout)
	transport := newBuildDirectTransport(cfg.ResponseHeaderTimeout)
	httpClient := &http.Client{Transport: transport}
	// The official CLI uses a persistent machine identity. The gateway does not collect machine fingerprints;
	// instead each backend process generates one random UUID for its lifetime as the Agent identity.
	agentID := uuid.NewString()
	adapter := &Adapter{
		cfg: cfg, http: httpClient, cipher: cipher, base: transport,
		agentID: agentID, modelsETags: make(map[uint64]string),
		conversationReasoningCache: conversation.NewReasoningCache(0, 0),
		compaction:                 newGatewayCompactionCodec(cipher), logger: slog.Default(),
	}
	adapter.oauth = newOAuthClient(httpClient, func() string { return adapter.config().ClientVersion })
	return adapter
}

func (a *Adapter) SetLogger(logger *slog.Logger) {
	if logger != nil {
		a.logger = logger
	}
}

func (a *Adapter) SetEgress(manager *infraegress.Manager) {
	if manager != nil {
		a.http.Transport = &egressTransport{manager: manager, fallback: a.base}
	}
}

// SetReasoningReplay injects the optional server-side reasoning replay cache.
func (a *Adapter) SetReasoningReplay(replay *reasoningreplay.ReasoningReplay) {
	a.replay = replay
}

func (a *Adapter) Provider() account.Provider { return account.ProviderBuild }

// CredentialMetadata extracts only non-sensitive risk flags from a Build access token.
// bot_flag_source or its short alias bfs must be JSON number 1 or 2; other values, malformed
// tokens, and decryption failures are not marked. bot_flag_source is preferred when both are set.
func (a *Adapter) CredentialMetadata(credential account.Credential) provider.CredentialMetadata {
	if credential.Provider != account.ProviderBuild || a.cipher == nil || credential.EncryptedAccessToken == "" {
		return provider.CredentialMetadata{}
	}
	accessToken, err := a.cipher.Decrypt(credential.EncryptedAccessToken)
	if err != nil {
		return provider.CredentialMetadata{}
	}
	claims := decodeJWTClaims(accessToken)
	if claims == nil {
		return provider.CredentialMetadata{}
	}
	source := buildBotFlagSourceFromClaims(claims)
	return provider.CredentialMetadata{
		BuildBotFlagInspected: true,
		BuildBotFlagged:       source != 0,
		BuildBotFlagSource:    source,
	}
}

// buildBotFlagSourceFromClaims returns the bot-risk source from JWT claims.
// Accepts bot_flag_source or bfs; only JSON numbers 1 and 2 count (string "1"/"2" do not).
// Prefer bot_flag_source when it is 1 or 2; otherwise fall back to bfs.
func buildBotFlagSourceFromClaims(claims map[string]any) int {
	if claims == nil {
		return 0
	}
	if source := botFlagSourceClaim(claims, "bot_flag_source"); source != 0 {
		return source
	}
	return botFlagSourceClaim(claims, "bfs")
}

func botFlagSourceClaim(claims map[string]any, key string) int {
	value, ok := claims[key].(float64)
	if !ok {
		return 0
	}
	switch value {
	case 1, 2:
		return int(value)
	default:
		return 0
	}
}

// buildBotFlaggedFromClaims reports whether JWT claims mark a Build account as bot-risked.
func buildBotFlaggedFromClaims(claims map[string]any) bool {
	return buildBotFlagSourceFromClaims(claims) != 0
}

func (a *Adapter) UpdateConfig(cfg Config) {
	cfg.ResponseHeaderTimeout = normalizeBuildResponseHeaderTimeout(cfg.ResponseHeaderTimeout)
	cfg.StreamIdleTimeout = normalizeBuildStreamIdleTimeout(cfg.StreamIdleTimeout)
	a.cfgMu.Lock()
	previousTimeout := a.cfg.ResponseHeaderTimeout
	a.cfg = cfg
	a.cfgMu.Unlock()
	if previousTimeout != cfg.ResponseHeaderTimeout && a.base != nil {
		a.base.UpdateResponseHeaderTimeout(cfg.ResponseHeaderTimeout)
	}
}

type buildDirectTransport struct {
	current atomic.Pointer[http.Transport]
}

func newBuildDirectTransport(responseHeaderTimeout time.Duration) *buildDirectTransport {
	value := &buildDirectTransport{}
	value.current.Store(newBuildHTTPTransport(responseHeaderTimeout))
	return value
}

func (t *buildDirectTransport) RoundTrip(request *http.Request) (*http.Response, error) {
	return t.current.Load().RoundTrip(request)
}

func (t *buildDirectTransport) UpdateResponseHeaderTimeout(responseHeaderTimeout time.Duration) {
	next := newBuildHTTPTransport(responseHeaderTimeout)
	previous := t.current.Swap(next)
	if previous != nil {
		previous.CloseIdleConnections()
	}
}

func newBuildHTTPTransport(responseHeaderTimeout time.Duration) *http.Transport {
	transport := &http.Transport{
		Proxy: infraegress.EnvironmentProxy, ForceAttemptHTTP2: true,
		MaxIdleConns: 256, MaxIdleConnsPerHost: 128, MaxConnsPerHost: 256,
		IdleConnTimeout: buildtransport.IdleConnTimeout, TLSHandshakeTimeout: 10 * time.Second,
		ResponseHeaderTimeout: normalizeBuildResponseHeaderTimeout(responseHeaderTimeout),
		ExpectContinueTimeout: time.Second,
	}
	if _, err := buildtransport.ConfigureHTTP2Health(transport); err != nil {
		slog.Warn("build_http2_health_config_failed", "error", err)
	}
	return transport
}

func normalizeBuildResponseHeaderTimeout(value time.Duration) time.Duration {
	if value <= 0 {
		return settingsdomain.DefaultBuildResponseHeaderTimeout
	}
	return value
}

func normalizeBuildStreamIdleTimeout(value time.Duration) time.Duration {
	if value <= 0 {
		return settingsdomain.DefaultBuildStreamIdleTimeout
	}
	return value
}

func (a *Adapter) config() Config {
	a.cfgMu.RLock()
	defer a.cfgMu.RUnlock()
	return a.cfg
}

func (a *Adapter) ForwardResponse(ctx context.Context, request provider.ResponseResourceRequest) (*provider.Response, error) {
	if request.NormalizedMetadata != nil {
		*request.NormalizedMetadata = provider.NormalizedRequestMetadata{}
	}
	accessToken, err := a.cipher.Decrypt(request.Credential.EncryptedAccessToken)
	if err != nil {
		return nil, err
	}
	body := request.Body
	var toolCompatibility *responsesToolCompatibility
	var conversationOptions conversation.ResponseOptions
	cacheRoute := buildPromptCacheRoute{}
	compactionRequested := false
	// Resolve the physical inference plane before normalization so Chat and
	// Anthropic conversion can use the same scope for capture and restoration.
	// The scope contains the trusted session seed, model, and plane only; it is
	// intentionally independent of the selected account.
	primaryBase := a.primaryBaseURL()
	base := a.inferenceBaseForOperation(request.Credential, request.Billing, request.Method, request.Path)
	conversationScope := a.conversationReasoningScope(request, base)
	if request.NormalizeBody {
		if request.Operation == conversation.OperationChat || request.Operation == conversation.OperationMessages {
			body, conversationOptions, err = conversation.ConvertRequestWithReasoningReplay(body, request.Model, request.Operation, a.conversationReasoningCache, conversationScope)
			if err == nil && conversationOptions.ReasoningEffortSet && request.NormalizedMetadata != nil {
				request.NormalizedMetadata.ReasoningEffort = conversationOptions.ReasoningEffort
			}
		} else {
			var driftedCompactions int
			body, driftedCompactions, err = expandGatewayCompactionHistory(body, a.compaction, request.PromptCacheKey)
			if err != nil {
				return invalidResponsesResponse(err), nil
			}
			body, toolCompatibility, err = normalizeResponsesRequestWithMetadata(body, request.Model, request.NormalizedMetadata)
			if toolCompatibility != nil {
				compactionRequested = toolCompatibility.compactionRequested
				if driftedCompactions > 0 {
					toolCompatibility.addWarning("compaction_session_drifted")
				}
			}
		}
		if err != nil {
			if request.Operation == conversation.OperationChat || request.Operation == conversation.OperationMessages {
				return invalidConversationResponse(request.Operation, err), nil
			}
			return invalidResponsesResponse(err), nil
		}
		body, err = normalizeBuildRequestWithMetadata(body, request.Model, request.Operation, request.NormalizedMetadata)
		if err != nil {
			if request.Operation == conversation.OperationChat || request.Operation == conversation.OperationMessages {
				return invalidConversationResponse(request.Operation, err), nil
			}
			return invalidResponsesResponse(err), nil
		}
	}
	if request.Operation == conversation.OperationMessages && conversationOptions.AnthropicWebSearch {
		request.ReasoningReplayKey = ""
		conversationScope = ""
		conversationOptions = conversationOptions.WithReasoningReplay(nil, "")
	}
	if compactionRequested {
		body, err = prepareGatewayCompactionSample(body)
		if err != nil {
			return invalidResponsesResponse(err), nil
		}
	}
	if len(body) > 0 && request.Method == http.MethodPost {
		if !compactionRequested {
			allowClientTools := request.AllowClientToolCacheRoute || (account.RoutingCandidate{Credential: request.Credential, Billing: request.Billing}).IsKnownFreeBuild()
			body, cacheRoute, err = prepareBuildPromptCacheRoute(body, request.Operation, request.Model, request.PromptCacheKey, allowClientTools)
			if err != nil {
				err = fmt.Errorf("准备 Build prompt cache 路由: %w", err)
				if request.Operation == conversation.OperationChat || request.Operation == conversation.OperationMessages {
					return invalidConversationResponse(request.Operation, err), nil
				}
				return invalidResponsesResponse(err), nil
			}
			body, err = injectPromptCacheKey(body, request.PromptCacheKey)
			if err != nil {
				err = fmt.Errorf("写入 prompt_cache_key: %w", err)
				if request.Operation == conversation.OperationChat || request.Operation == conversation.OperationMessages {
					return invalidConversationResponse(request.Operation, err), nil
				}
				return invalidResponsesResponse(err), nil
			}
		}
	}
	if compactionRequested {
		warnings := ""
		if toolCompatibility != nil {
			warnings = toolCompatibility.warningHeader()
		}
		return a.forwardGatewayCompaction(ctx, request, accessToken, body, warnings)
	}
	// Explicit mode wins; in auto mode only confirmed Super accounts with bot_flag_source/bfs in {1,2} default to XAI.
	// Prompt-cache affinity and reasoning replay use separate identities. The
	// native Responses replay remains account-scoped, while the Chat/Messages
	// bridge is scoped to the client session, model, and physical plane only;
	// encrypted reasoning is portable across accounts on that plane.
	replayBaseBody := body
	body, replayKey := a.applyReasoningReplay(ctx, request, replayBaseBody, base)
	call := a.doResponseRequest(ctx, request, accessToken, body, base)
	if call.err != nil {
		return nil, call.err
	}
	if err := normalizeGzipResponse(call.response); err != nil {
		return nil, err
	}
	call, reasoningRecovery, recoveryErr := a.recoverReasoningDecodeFailure(ctx, request, accessToken, body, base, replayKey, call)
	if recoveryErr != nil {
		return nil, recoveryErr
	}
	resp, reqURL := call.response, call.upstreamURL
	var recoveredPrimaryFailure *provider.DiagnosticResponse
	var recoveredPrimaryAttempt *provider.RecoveredAttempt
	// Only eligible operations probe XAI with an equivalent request after the Build primary explicitly returns 403.
	if strings.EqualFold(base, primaryBase) && shouldProbeXAIInferenceFallback(request.Credential, request.Billing, request.Method, request.Path, resp.StatusCode) {
		primaryCall := call
		// Buffer the primary 403 body and replay it unchanged if fallback fails; never issue a second primary POST.
		primaryBody, primaryTruncated, readErr := provider.ReadDiagnosticBody(resp.Body)
		_ = resp.Body.Close()
		if readErr != nil {
			return nil, readErr
		}
		primaryResp := cloneBufferedResponse(resp, primaryBody, primaryTruncated)
		if shouldSkipXAIFallback(primaryBody) {
			resp = primaryResp
		} else {
			fallbackBase := a.fallbackBaseURL()
			if fallbackBase != "" && !strings.EqualFold(fallbackBase, base) {
				fallbackBody, fallbackReplayKey := a.applyReasoningReplay(ctx, request, replayBaseBody, fallbackBase)
				fallbackCtx := infraegress.WithPhysicalCallStage(ctx, "plane_fallback")
				fallbackCall := a.doResponseRequest(fallbackCtx, request, accessToken, fallbackBody, fallbackBase)
				fallbackErr := fallbackCall.err
				if fallbackErr == nil {
					fallbackErr = normalizeGzipResponse(fallbackCall.response)
				}
				fallbackRecovery := reasoningRecoveryOutcome{}
				if fallbackErr == nil {
					fallbackCall, fallbackRecovery, fallbackErr = a.recoverReasoningDecodeFailure(ctx, request, accessToken, fallbackBody, fallbackBase, fallbackReplayKey, fallbackCall)
				}
				if fallbackErr == nil && isHTTPSuccess(fallbackCall.response.StatusCode) {
					recoveredPrimaryFailure = bufferedFailureDiagnostic(primaryResp, primaryBody, primaryTruncated)
					recoveredPrimaryAttempt = &provider.RecoveredAttempt{
						Stage:       "primary_plane_response",
						Result:      "replaced_by_plane_fallback",
						UpstreamURL: primaryCall.upstreamURL,
						StartedAt:   primaryCall.startedAt,
						DurationMS:  primaryCall.durationMS,
						Diagnostic:  *recoveredPrimaryFailure,
					}
					a.activateBuildAPIFallback(ctx, &request.Credential)
					call = fallbackCall
					resp, reqURL, base, body, replayKey = call.response, call.upstreamURL, fallbackBase, fallbackBody, fallbackReplayKey
					conversationOptions = conversationOptions.WithReasoningReplay(a.conversationReasoningCache, a.conversationReasoningScope(request, base))
					reasoningRecovery = reasoningRecovery.merge(fallbackRecovery)
				} else {
					if fallbackErr == nil && fallbackCall.response != nil {
						_ = fallbackCall.response.Body.Close()
					}
					// Preserve the original primary 403 URL and buffered body without requesting the primary again.
					resp = primaryResp
				}
			} else {
				resp = primaryResp
			}
		}
	}
	var rateLimit *provider.RateLimitMetadata
	var rateLimitDiagnostic *provider.DiagnosticResponse
	if resp.StatusCode == http.StatusTooManyRequests {
		body, truncated, readErr := provider.ReadDiagnosticBody(resp.Body)
		_ = resp.Body.Close()
		if readErr != nil {
			return nil, readErr
		}
		resp.Body = io.NopCloser(bytes.NewReader(body))
		resp.ContentLength = int64(len(body))
		resp.Header.Set("Content-Length", strconv.Itoa(len(body)))
		rateLimit = provider.RateLimitFromResponse(resp.StatusCode, resp.Header, body)
		if truncated {
			rateLimitDiagnostic = &provider.DiagnosticResponse{
				StatusCode: resp.StatusCode, Status: resp.Status, Header: resp.Header.Clone(),
				Body: append([]byte(nil), body...), BodyTruncated: true,
			}
		}
	}
	if request.Streaming && isHTTPSuccess(resp.StatusCode) && resp.Body != nil {
		resp.Body = wrapBuildSemanticIdle(resp.Body, a.config().StreamIdleTimeout)
	}
	modelCatalogChanged := a.modelCatalogChanged(request.Credential.ID, resp.Header.Get("x-models-etag"))
	// Capture or clear reasoning replay in the upstream Responses shape before protocol conversion.
	if a.shouldCaptureReplay(request, resp, replayKey) {
		resp.Body = a.replay.CaptureBody(resp.Body, request.Model, replayKey, request.Streaming, isCompactPath(request.Path))
	}
	// Replay must read the raw upstream output. Hide xAI native search subcalls from downstream clients
	// only after capture wrapping has completed.
	if isHTTPSuccess(resp.StatusCode) {
		if err := filterBuildPromptCacheResponse(resp, request.Streaming, cacheRoute); err != nil {
			return nil, err
		}
	}
	responsesOperation := request.Operation == "" || request.Operation == conversation.OperationResponses || request.Operation == conversation.OperationCompaction
	if responsesOperation && toolCompatibility != nil {
		if warnings := toolCompatibility.warningHeader(); warnings != "" {
			resp.Header.Set("X-Grok2API-Compatibility-Warnings", warnings)
		}
	}
	reasoningRecovery.appendWarnings(resp.Header)
	if responsesOperation && resp.StatusCode >= 200 && resp.StatusCode < 300 {
		if request.Streaming {
			resp.Body = toolCompatibility.normalizeResponseStream(resp.Body)
			resp.Header.Del("Content-Length")
			resp.Header.Set("Content-Type", "text/event-stream")
		} else if toolCompatibility != nil {
			data, readErr := io.ReadAll(io.LimitReader(resp.Body, maxCompatibleResponseBytes+1))
			_ = resp.Body.Close()
			if readErr != nil {
				return nil, readErr
			}
			if len(bytes.TrimSpace(data)) == 0 {
				return nil, neterrorpkg.ErrUpstreamResponseEmpty
			}
			if len(data) > maxCompatibleResponseBytes {
				return nil, fmt.Errorf("上游兼容 Responses 响应超过 128 MiB")
			}
			converted, convertErr := toolCompatibility.normalizeResponseJSON(data)
			if convertErr != nil {
				return nil, convertErr
			}
			resp.Body = io.NopCloser(bytes.NewReader(converted))
			resp.Header.Set("Content-Length", strconv.Itoa(len(converted)))
			resp.Header.Set("Content-Type", "application/json")
		}
	}
	if request.Operation == conversation.OperationChat || request.Operation == conversation.OperationMessages {
		if request.Streaming && resp.StatusCode >= 200 && resp.StatusCode < 300 {
			resp.Body = conversation.ConvertResponseStreamWithOptions(resp.Body, request.Operation, conversationOptions)
			resp.Header.Del("Content-Length")
			resp.Header.Set("Content-Type", "text/event-stream")
		} else {
			var data []byte
			var readErr error
			var diagnosticTruncated bool
			if resp.StatusCode >= 200 && resp.StatusCode < 300 {
				data, readErr = io.ReadAll(io.LimitReader(resp.Body, (64<<20)+1))
			} else {
				data, diagnosticTruncated, readErr = provider.ReadDiagnosticBody(resp.Body)
			}
			_ = resp.Body.Close()
			if readErr != nil {
				return nil, readErr
			}
			if resp.StatusCode >= 200 && resp.StatusCode < 300 && len(bytes.TrimSpace(data)) == 0 {
				return nil, neterrorpkg.ErrUpstreamResponseEmpty
			}
			if resp.StatusCode >= 200 && resp.StatusCode < 300 && len(data) > 64<<20 {
				return nil, fmt.Errorf("上游对话响应超过 64 MiB")
			}
			var diagnostic *provider.DiagnosticResponse
			if resp.StatusCode < 200 || resp.StatusCode >= 300 {
				diagnostic = &provider.DiagnosticResponse{StatusCode: resp.StatusCode, Status: resp.Status, Header: resp.Header.Clone(), Body: data, BodyTruncated: diagnosticTruncated || rateLimitDiagnostic != nil}
			}
			converted, convertErr := conversation.ConvertResponseJSONWithOptions(data, request.Operation, conversationOptions)
			if convertErr != nil {
				if diagnostic == nil {
					return nil, convertErr
				}
				return &provider.Response{StatusCode: resp.StatusCode, Status: resp.Status, Header: diagnostic.Header.Clone(), Body: io.NopCloser(bytes.NewReader(data)), UpstreamURL: reqURL, Diagnostic: diagnostic, ReasoningRecoveryFailed: reasoningRecovery.failed, RecoveredPrimaryFailure: recoveredPrimaryFailure, RecoveredAttempts: recoveredAttempts(recoveredPrimaryAttempt, reasoningRecovery), RateLimit: rateLimit, ModelCatalogChanged: modelCatalogChanged}, nil
			}
			resp.Body = io.NopCloser(bytes.NewReader(converted))
			resp.Header.Set("Content-Length", strconv.Itoa(len(converted)))
			resp.Header.Set("Content-Type", "application/json")
			return &provider.Response{StatusCode: resp.StatusCode, Status: resp.Status, Header: resp.Header.Clone(), Body: resp.Body, UpstreamURL: reqURL, Diagnostic: diagnostic, ReasoningRecoveryFailed: reasoningRecovery.failed, RecoveredPrimaryFailure: recoveredPrimaryFailure, RecoveredAttempts: recoveredAttempts(recoveredPrimaryAttempt, reasoningRecovery), RateLimit: rateLimit, ModelCatalogChanged: modelCatalogChanged}, nil
		}
	}
	return &provider.Response{StatusCode: resp.StatusCode, Status: resp.Status, Header: resp.Header.Clone(), Body: resp.Body, UpstreamURL: reqURL, Diagnostic: rateLimitDiagnostic, ReasoningRecoveryFailed: reasoningRecovery.failed, RecoveredPrimaryFailure: recoveredPrimaryFailure, RecoveredAttempts: recoveredAttempts(recoveredPrimaryAttempt, reasoningRecovery), RateLimit: rateLimit, ModelCatalogChanged: modelCatalogChanged}, nil
}

// recoveredAttempts 按真实调用顺序汇总被 fallback 与 reasoning recovery 隐藏的失败。
func recoveredAttempts(primary *provider.RecoveredAttempt, recovery reasoningRecoveryOutcome) []provider.RecoveredAttempt {
	attempts := append([]provider.RecoveredAttempt(nil), recovery.attempts...)
	if primary != nil {
		attempts = append([]provider.RecoveredAttempt{*primary}, attempts...)
	}
	return attempts
}

func (a *Adapter) shouldCaptureReplay(request provider.ResponseResourceRequest, resp *http.Response, replayKey string) bool {
	if a.replay == nil || !a.replay.Enabled() || resp == nil {
		return false
	}
	if request.Method != http.MethodPost || strings.TrimSpace(replayKey) == "" {
		return false
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return false
	}
	return true
}

func (a *Adapter) applyReasoningReplay(ctx context.Context, request provider.ResponseResourceRequest, body []byte, base string) ([]byte, string) {
	if a.replay == nil || !a.replay.Enabled() || request.Method != http.MethodPost {
		return body, ""
	}
	key := a.scopedReasoningReplayKey(request, base)
	if key == "" {
		return body, ""
	}
	if isCompactPath(request.Path) {
		// compact does not inject history, but a successful request still clears old replay in the same scope.
		return body, key
	}
	return a.replay.Apply(ctx, request.Model, key, body), key
}

func (a *Adapter) scopedReasoningReplayKey(request provider.ResponseResourceRequest, base string) string {
	seed := strings.TrimSpace(request.ReasoningReplayKey)
	if seed == "" {
		return ""
	}
	plane := "build"
	if fallback := a.fallbackBaseURL(); fallback != "" && strings.EqualFold(strings.TrimRight(base, "/"), fallback) {
		plane = "xai"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf("grok2api:reasoning-replay:v3:%s:%s", seed, plane)))
	return hex.EncodeToString(digest[:])
}

func (a *Adapter) conversationReasoningScope(request provider.ResponseResourceRequest, base string) string {
	seed := strings.TrimSpace(request.ReasoningReplayKey)
	model := strings.ToLower(strings.TrimSpace(request.Model))
	if seed == "" || model == "" {
		return ""
	}
	plane := "build"
	if fallback := a.fallbackBaseURL(); fallback != "" && strings.EqualFold(strings.TrimRight(base, "/"), fallback) {
		plane = "xai"
	}
	digest := sha256.Sum256([]byte(fmt.Sprintf("grok2api:conversation-reasoning:v1:%s:%s:%s", seed, model, plane)))
	return hex.EncodeToString(digest[:])
}

func isCompactPath(path string) bool {
	return strings.Contains(strings.ToLower(path), "compact")
}

type responseCall struct {
	response    *http.Response
	upstreamURL string
	startedAt   time.Time
	durationMS  int64
	err         error
}

// doResponseRequest 发起一次真实 Responses 上游调用，并保留该次调用自己的审计来源信息。
func (a *Adapter) doResponseRequest(ctx context.Context, request provider.ResponseResourceRequest, accessToken string, body []byte, base string) (call responseCall) {
	startedAt := time.Now()
	call = responseCall{upstreamURL: a.urlWithBase(base, request.Path), startedAt: startedAt.UTC()}
	defer func() {
		call.durationMS = time.Since(startedAt).Milliseconds()
	}()
	var bodyReader io.Reader
	if len(body) > 0 {
		bodyReader = bytes.NewReader(body)
	}
	requestCtx := infraegress.WithCredential(ctx, request.Credential)
	if request.ForcedEgressNodeID != 0 {
		requestCtx = infraegress.WithEgressNode(requestCtx, request.ForcedEgressNodeID)
	}
	plane := "build"
	if fallback := a.fallbackBaseURL(); fallback != "" && strings.EqualFold(strings.TrimRight(base, "/"), fallback) {
		plane = "xai"
	}
	requestCtx = infraegress.WithPhysicalCallPlane(requestCtx, plane)
	req, err := http.NewRequestWithContext(requestCtx, request.Method, call.upstreamURL, bodyReader)
	if err != nil {
		call.err = err
		return call
	}
	call.upstreamURL = req.URL.String()
	if err := a.applyHeaders(req, request.Credential, accessToken, request.Model, request.PromptCacheKey, true); err != nil {
		call.err = err
		return call
	}
	applyGrokTurnIndexHeader(req, request.GrokTurnIndex)
	if request.TransientRetry > 0 {
		req.Header.Set("x-grok-transient-retry", strconv.Itoa(request.TransientRetry))
	}
	if len(body) > 0 {
		req.Header.Set("Content-Type", "application/json")
	}
	if request.Streaming {
		req.Header.Set("Accept", "text/event-stream")
		req.Header.Set("Accept-Encoding", "identity")
	} else {
		req.Header.Set("Accept", "application/json")
	}
	if request.IdempotencyID != "" {
		req.Header.Set("Idempotency-Key", request.IdempotencyID)
	}
	// Streaming requests already receive transport/semantic idle protection.
	// Non-streaming text inference needs its own cancel-cause-aware body timer:
	// ResponseHeaderTimeout stops once headers arrive and cannot interrupt a
	// server that then leaves the JSON body silent indefinitely. Create the
	// derived context only after every fallible request-construction step so
	// every remaining path either cancels it or transfers ownership to the body.
	var responseIdleCancel context.CancelCauseFunc
	responseIdle := a.config().StreamIdleTimeout
	if !request.Streaming && responseIdle > 0 {
		requestCtx, responseIdleCancel = context.WithCancelCause(requestCtx)
		req = req.WithContext(requestCtx)
	}
	resp, err := a.http.Do(req)
	if err != nil {
		if responseIdleCancel != nil {
			responseIdleCancel(nil)
		}
		call.err = err
		return call
	}
	if responseIdleCancel != nil {
		switch {
		case resp.Body == nil:
			responseIdleCancel(nil)
		case isHTTPSuccess(resp.StatusCode):
			resp.Body = providerstreamidle.New(resp.Body, responseIdle, responseIdleCancel)
		default:
			resp.Body = &cancelOnCloseReadCloser{ReadCloser: resp.Body, cancel: responseIdleCancel}
		}
	}
	call.response = resp
	return call
}

// applyGrokTurnIndexHeader forwards a real client turn only when the request has a stable Grok session.
func applyGrokTurnIndexHeader(request *http.Request, value string) {
	if request.Header.Get("x-grok-session-id") == "" {
		return
	}
	if turnIndex := normalizeGrokTurnIndex(value); turnIndex != "" {
		request.Header.Set("x-grok-turn-idx", turnIndex)
	}
}

// normalizeGrokTurnIndex accepts only non-negative decimal u64 values generated by an official client.
// Empty or invalid values are omitted; the gateway never fabricates turns from history, tool loops, or compaction.
func normalizeGrokTurnIndex(value string) string {
	value = strings.TrimSpace(value)
	if value == "" || len(value) > 20 {
		return ""
	}
	for _, char := range value {
		if char < '0' || char > '9' {
			return ""
		}
	}
	if _, err := strconv.ParseUint(value, 10, 64); err != nil {
		return ""
	}
	return value
}

// invalidResponsesResponse converts local protocol validation errors to a standard OpenAI error response,
// avoiding an upstream account retry.
func invalidResponsesResponse(err error) *provider.Response {
	code := "invalid_request"
	param := ""
	message := err.Error()
	var requestErr *responsesRequestError
	if errors.As(err, &requestErr) {
		code = requestErr.Code
		param = requestErr.Param
		message = requestErr.Message
	}
	errorBody := map[string]any{"type": "invalid_request_error", "message": message, "code": code}
	if param != "" {
		errorBody["param"] = param
	}
	data, _ := json.Marshal(map[string]any{"error": errorBody})
	return &provider.Response{
		StatusCode: http.StatusBadRequest, Status: "400 Bad Request",
		Header: http.Header{"Content-Type": []string{"application/json"}, "Content-Length": []string{strconv.Itoa(len(data))}},
		Body:   io.NopCloser(bytes.NewReader(data)),
	}
}

func invalidConversationResponse(operation string, err error) *provider.Response {
	var payload any = map[string]any{"error": map[string]any{"type": "invalid_request_error", "message": err.Error()}}
	if operation == conversation.OperationMessages {
		payload = map[string]any{"type": "error", "error": map[string]any{"type": "invalid_request_error", "message": err.Error()}}
	}
	data, _ := json.Marshal(payload)
	return &provider.Response{
		StatusCode: http.StatusBadRequest, Status: "400 Bad Request",
		Header: http.Header{"Content-Type": []string{"application/json"}, "Content-Length": []string{strconv.Itoa(len(data))}},
		Body:   io.NopCloser(bytes.NewReader(data)),
	}
}

func (a *Adapter) ListModels(ctx context.Context, credential account.Credential) ([]string, error) {
	ctx, cancel := context.WithTimeout(ctx, buildControlTimeout)
	defer cancel()
	accessToken, err := a.cipher.Decrypt(credential.EncryptedAccessToken)
	if err != nil {
		return nil, err
	}
	// Always request the model catalog from the Build primary; do not preemptively switch to XAI because 1.5 or Super entitlement is absent.
	// NormalizeAccountModelCapabilities fills session-contract capabilities such
	// as Composer and paid video entitlement locally.
	models, status, err := a.listModelsAt(ctx, credential, accessToken, a.primaryBaseURL())
	if err != nil {
		return nil, err
	}
	if models != nil {
		return models, nil
	}
	return nil, fmt.Errorf("上游模型接口返回 %d", status)
}

// NormalizeAccountModelCapabilities normalizes capabilities that the OAuth
// session contract exposes independently of the account's sparse /models list.
// Composer is available to Build OAuth sessions independently of the sparse
// live catalog. Grok 4.6 sessions retain the still-supported Grok 4.5 route for
// backwards compatibility. Super always includes video 1.5; Free and Unknown
// remove video 1.5 exactly. BuildAPIFallback is ignored.
func (a *Adapter) NormalizeAccountModelCapabilities(models []string, billing *account.Billing, credential account.Credential) []string {
	super := account.IsBuildSuper(credential, billing)
	composer := credential.Provider == account.ProviderBuild && credential.AuthType == account.AuthTypeOAuth
	result := make([]string, 0, len(models)+2)
	seen := make(map[string]struct{}, len(models)+2)
	hasVideo15 := false
	hasGrok46 := false
	for _, model := range models {
		model = strings.TrimSpace(model)
		if model == "" {
			continue
		}
		if _, exists := seen[model]; exists {
			continue
		}
		if model == buildVideoModel {
			if !super {
				continue
			}
			hasVideo15 = true
		}
		if model == buildGrok46Model {
			hasGrok46 = true
		}
		seen[model] = struct{}{}
		result = append(result, model)
	}
	if credential.Provider == account.ProviderBuild && hasGrok46 {
		if _, exists := seen[buildGrok45Model]; !exists {
			seen[buildGrok45Model] = struct{}{}
			result = append(result, buildGrok45Model)
		}
	}
	if super && !hasVideo15 {
		result = append(result, buildVideoModel)
	}
	if composer {
		if _, exists := seen[modeldomain.GrokComposer25Fast]; !exists {
			result = append(result, modeldomain.GrokComposer25Fast)
		}
	}
	return result
}

type buildModelCatalogEntry struct {
	ID      string `json:"id"`
	Model   string `json:"model"`
	ModelID string `json:"modelId"`
	Hidden  bool   `json:"hidden"`
	Meta    struct {
		Model   string `json:"model"`
		ModelID string `json:"modelId"`
		Hidden  bool   `json:"hidden"`
	} `json:"_meta"`
	// Reasoning and budget metadata, mirroring the keys grok-build reads in
	// xai-grok-shell remote/client.rs parse_remote_model_value. Snake and camel
	// case spellings are both accepted there, so both are accepted here.
	ContextWindow            int64  `json:"context_window"`
	ContextWindowCamel       int64  `json:"contextWindow"`
	MaxCompletionTokens      int64  `json:"max_completion_tokens"`
	MaxCompletionTokensCamel int64  `json:"maxCompletionTokens"`
	ReasoningEffort          string `json:"reasoning_effort"`
	ReasoningEffortCamel     string `json:"reasoningEffort"`
	SupportsReasoningEffort  *bool  `json:"supports_reasoning_effort"`
	SupportsReasoningCamel   *bool  `json:"supportsReasoningEffort"`
	SupportsBackendSearch    bool   `json:"supports_backend_search"`
	// reasoning_efforts entries are either bare strings ("high") or objects
	// {value,id,label,description,default}; decode lazily per entry.
	ReasoningEfforts      []json.RawMessage `json:"reasoning_efforts"`
	ReasoningEffortsCamel []json.RawMessage `json:"reasoningEfforts"`
}

// modelIdentifier keeps the legacy top-level id authoritative and uses the
// additional official Grok Build shapes only as fallbacks. This makes catalog
// parsing additive: existing route IDs never change merely because model or
// modelId metadata appears alongside id.
func (e buildModelCatalogEntry) modelIdentifier() string {
	if e.Hidden || e.Meta.Hidden {
		return ""
	}
	return firstNonEmpty(e.ID, e.Model, e.ModelID, e.Meta.Model, e.Meta.ModelID)
}

// reasoningMenu decodes reasoning_efforts the way grok-build's
// parse_reasoning_effort_options does: each entry is a bare effort string or an
// object with a required `value`; unreadable entries are skipped instead of
// discarding the whole menu. It returns the ordered values and the entry
// flagged default (empty when none is flagged).
func (e buildModelCatalogEntry) reasoningMenu() (values []string, defaultValue string) {
	raw := e.ReasoningEfforts
	if len(raw) == 0 {
		raw = e.ReasoningEffortsCamel
	}
	for _, entry := range raw {
		var bare string
		if err := json.Unmarshal(entry, &bare); err == nil {
			if bare = strings.TrimSpace(bare); bare != "" {
				values = append(values, bare)
			}
			continue
		}
		var option struct {
			Value   string `json:"value"`
			Default bool   `json:"default"`
		}
		if err := json.Unmarshal(entry, &option); err != nil {
			continue
		}
		value := strings.TrimSpace(option.Value)
		if value == "" {
			continue
		}
		values = append(values, value)
		if option.Default && defaultValue == "" {
			defaultValue = value
		}
	}
	return values, defaultValue
}

// upstreamProfile projects the catalog entry onto the domain profile.
func (e buildModelCatalogEntry) upstreamProfile() modeldomain.UpstreamModelProfile {
	menu, menuDefault := e.reasoningMenu()
	supports := false
	switch {
	case e.SupportsReasoningEffort != nil:
		supports = *e.SupportsReasoningEffort
	case e.SupportsReasoningCamel != nil:
		supports = *e.SupportsReasoningCamel
	}
	contextWindow := e.ContextWindow
	if contextWindow <= 0 {
		contextWindow = e.ContextWindowCamel
	}
	maxCompletion := e.MaxCompletionTokens
	if maxCompletion <= 0 {
		maxCompletion = e.MaxCompletionTokensCamel
	}
	return modeldomain.UpstreamModelProfile{
		ReasoningEfforts:        menu,
		DefaultReasoningEffort:  firstNonEmpty(menuDefault, e.ReasoningEffort, e.ReasoningEffortCamel),
		SupportsReasoningEffort: supports,
		ContextWindow:           clampInt(contextWindow),
		MaxCompletionTokens:     clampInt(maxCompletion),
		SupportsBackendSearch:   e.SupportsBackendSearch,
	}
}

func clampInt(value int64) int {
	if value <= 0 {
		return 0
	}
	if value > math.MaxInt32 {
		return math.MaxInt32
	}
	return int(value)
}

func (a *Adapter) listModelsAt(ctx context.Context, credential account.Credential, accessToken, base string) ([]string, int, error) {
	requestCtx := infraegress.WithCredential(ctx, credential)
	req, err := http.NewRequestWithContext(requestCtx, http.MethodGet, a.urlWithBase(base, "/models"), nil)
	if err != nil {
		return nil, 0, err
	}
	if err := a.applyHeaders(req, credential, accessToken, "", "", false); err != nil {
		return nil, 0, err
	}
	resp, err := a.http.Do(req)
	if err != nil {
		return nil, 0, err
	}
	if err := normalizeGzipResponse(resp); err != nil {
		return nil, 0, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	if err != nil {
		return nil, 0, err
	}
	if resp.StatusCode != http.StatusOK {
		return nil, resp.StatusCode, nil
	}
	var payload struct {
		Data []json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(body, &payload); err != nil {
		return nil, resp.StatusCode, err
	}
	models := make([]string, 0, len(payload.Data))
	seen := make(map[string]struct{}, len(payload.Data))
	for _, raw := range payload.Data {
		var item buildModelCatalogEntry
		if json.Unmarshal(raw, &item) != nil {
			continue
		}
		identifier := item.modelIdentifier()
		if identifier == "" {
			continue
		}
		if _, exists := seen[identifier]; exists {
			continue
		}
		seen[identifier] = struct{}{}
		models = append(models, identifier)
		// Publish the live reasoning menu / context budget so effort validation,
		// aliases, and catalog output follow the upstream catalog like grok-build does.
		modeldomain.RegisterUpstreamModelProfile(identifier, item.upstreamProfile())
	}
	a.recordModelsETag(credential.ID, resp.Header.Get("ETag"))
	return models, resp.StatusCode, nil
}

func (a *Adapter) recordModelsETag(accountID uint64, etag string) {
	etag = strings.TrimSpace(etag)
	if etag == "" {
		return
	}
	a.modelsMu.Lock()
	if a.modelsETags == nil {
		a.modelsETags = make(map[uint64]string)
	}
	a.modelsETags[accountID] = etag
	a.modelsMu.Unlock()
}

func (a *Adapter) modelCatalogChanged(accountID uint64, etag string) bool {
	etag = strings.TrimSpace(etag)
	if etag == "" {
		return false
	}
	a.modelsMu.Lock()
	defer a.modelsMu.Unlock()
	if a.modelsETags == nil {
		a.modelsETags = make(map[uint64]string)
	}
	current := a.modelsETags[accountID]
	if current == "" {
		// After a process restart there is no in-memory catalog baseline. Let the Gateway perform one account-level
		// /models sync; recordModelsETag establishes the baseline after success.
		return true
	}
	return current != etag
}

func (a *Adapter) GetBilling(ctx context.Context, credential account.Credential) (account.Billing, error) {
	ctx, cancel := context.WithTimeout(ctx, buildControlTimeout)
	defer cancel()
	accessToken, err := a.cipher.Decrypt(credential.EncryptedAccessToken)
	if err != nil {
		return account.Billing{}, err
	}
	billing, err := a.getBilling(ctx, credential, accessToken, "format=credits")
	if err != nil {
		return account.Billing{}, err
	}
	// A weekly quota at 0% usage cannot distinguish Free from a newly activated paid plan.
	// The official CLI uses /user?include=subscription for the live subscription tier, then falls back to the JWT tier.
	if tier, tierErr := a.getSubscriptionTier(ctx, credential, accessToken); tierErr == nil && tier != "" {
		billing.PlanName = tier
	} else if billing.PlanCode == "" && billing.PlanName == "" {
		billing.PlanName = subscriptionTierFromJWT(accessToken)
	}
	billing.AccountID = credential.ID
	billing.SyncedAt = time.Now().UTC()
	return billing, nil
}

func (a *Adapter) RefreshCredential(ctx context.Context, credential account.Credential) (provider.RefreshedCredential, error) {
	ctx, cancel := context.WithTimeout(ctx, buildControlTimeout)
	defer cancel()
	refreshToken, err := a.cipher.Decrypt(credential.EncryptedRefreshToken)
	if err != nil {
		// Decryption failures are usually temporary or mismatched local encryption keys and are recoverable;
		// do not mark them permanent, or manual/batch refresh will never retry after the key is fixed.
		// True permanent OAuth failures such as invalid_grant are returned by oauth.refresh with Permanent=true.
		return provider.RefreshedCredential{}, &provider.CredentialRefreshError{Code: "credential_decrypt_failed", Message: "Stored refresh credential could not be decrypted", Permanent: false, Cause: err}
	}
	if strings.TrimSpace(refreshToken) == "" {
		return provider.RefreshedCredential{}, &provider.CredentialRefreshError{Code: "missing_refresh_token", Message: "Refresh token is missing", Permanent: true}
	}
	refreshCtx := infraegress.WithCredential(ctx, credential)
	tokens, err := a.oauth.refreshWithClientID(refreshCtx, refreshToken, credential.OIDCClientID)
	if err != nil {
		return provider.RefreshedCredential{}, err
	}
	accessEncrypted, err := a.cipher.Encrypt(tokens.AccessToken)
	if err != nil {
		return provider.RefreshedCredential{}, err
	}
	refreshEncrypted, err := a.cipher.Encrypt(tokens.RefreshToken)
	if err != nil {
		return provider.RefreshedCredential{}, err
	}
	return provider.RefreshedCredential{EncryptedAccessToken: accessEncrypted, EncryptedRefreshToken: refreshEncrypted, ExpiresAt: tokens.ExpiresAt, RefreshTokenRotated: tokens.RefreshTokenRotated}, nil
}

func (a *Adapter) StartDeviceAuthorization(ctx context.Context) (provider.DeviceAuthorization, error) {
	ctx, cancel := context.WithTimeout(ctx, buildControlTimeout)
	defer cancel()
	return a.oauth.startDevice(ctx)
}

func (a *Adapter) PollDeviceAuthorization(ctx context.Context, deviceCode string) (provider.CredentialSeed, error) {
	ctx, cancel := context.WithTimeout(ctx, buildControlTimeout)
	defer cancel()
	tokens, err := a.oauth.pollDevice(ctx, deviceCode)
	if err != nil {
		return provider.CredentialSeed{}, err
	}
	claims := decodeJWTClaims(firstNonEmpty(tokens.IDToken, tokens.AccessToken))
	userID := stringClaim(claims, "sub")
	email := stringClaim(claims, "email")
	return provider.CredentialSeed{Name: firstNonEmpty(email, userID, "Grok Build account"), Email: email, UserID: userID, TeamID: stringClaim(claims, "team_id"), OIDCClientID: defaultOAuthClientID, AccessToken: tokens.AccessToken, RefreshToken: tokens.RefreshToken, ExpiresAt: tokens.ExpiresAt}, nil
}

func (a *Adapter) ParseImportedCredentials(data []byte) ([]provider.CredentialSeed, error) {
	return parseImportedCredentials(data)
}

// PrepareImportedCredential validates a refresh-token-only import and keeps
// the rotated tokens returned by xAI before the account is persisted.
func (a *Adapter) PrepareImportedCredential(ctx context.Context, seed provider.CredentialSeed) (provider.CredentialSeed, error) {
	if strings.TrimSpace(seed.AccessToken) != "" || strings.TrimSpace(seed.RefreshToken) == "" {
		return seed, nil
	}
	refreshCtx, cancel := context.WithTimeout(ctx, buildControlTimeout)
	defer cancel()
	tokens, err := a.oauth.refreshWithClientID(refreshCtx, strings.TrimSpace(seed.RefreshToken), seed.OIDCClientID)
	if err != nil {
		return provider.CredentialSeed{}, fmt.Errorf("验证 Grok Build refresh token: %w", err)
	}
	claims := decodeJWTClaims(firstNonEmpty(tokens.IDToken, tokens.AccessToken))
	seed.AccessToken = tokens.AccessToken
	seed.RefreshToken = tokens.RefreshToken
	seed.ExpiresAt = tokens.ExpiresAt
	seed.OIDCClientID = firstNonEmpty(seed.OIDCClientID, defaultOAuthClientID)
	seed.UserID = firstNonEmpty(seed.UserID, stringClaim(claims, "sub"))
	seed.Email = firstNonEmpty(seed.Email, stringClaim(claims, "email"))
	seed.TeamID = firstNonEmpty(seed.TeamID, stringClaim(claims, "team_id"))
	if seed.Name == "" || seed.Name == "Grok Build account" {
		seed.Name = firstNonEmpty(seed.Email, seed.UserID, "Grok Build account")
	}
	identity := firstNonEmpty(seed.UserID, strings.ToLower(seed.Email), seed.TeamID, seed.RefreshToken, seed.AccessToken)
	seed.SourceKey = "import:" + security.HashToken(strings.Join([]string{credentialImportProvider, seed.OIDCClientID, identity}, "|"))
	return seed, nil
}

func (a *Adapter) MarshalCredentials(values []provider.CredentialSeed) ([]byte, error) {
	return marshalCredentials(values)
}

func (a *Adapter) applyHeaders(req *http.Request, credential account.Credential, accessToken, model, promptCacheKey string, trace bool) error {
	cfg := a.config()
	req.Header.Set("Authorization", "Bearer "+accessToken)
	req.Header.Set("X-XAI-Token-Auth", cfg.TokenAuth)
	req.Header.Set("x-grok-client-version", cfg.ClientVersion)
	req.Header.Set("x-grok-client-identifier", cfg.ClientIdentifier)
	req.Header.Set("x-grok-client-mode", "headless")

	if trace {
		requestID := uuid.NewString()
		// Set x-grok-conv-id and session-id only when a stable session exists.
		// Never generate a random UUID per request; it breaks xAI session affinity and keeps cached_tokens at zero.
		sessionID, err := grokSessionID(promptCacheKey)
		if err != nil {
			return err
		}
		req.Header.Set("x-authenticateresponse", "authenticate-response")
		req.Header.Set("x-grok-agent-id", a.agentID)
		if sessionID != "" {
			req.Header.Set("x-grok-session-id", sessionID)
			req.Header.Set("x-grok-conv-id", sessionID)
			// grok-build derives x-grok-conv-group-id from the root session so the
			// proxy can group a root conversation with its subagent descendants.
			req.Header.Set("x-grok-conv-group-id", grokConversationGroupID(sessionID))
		}
		req.Header.Set("x-grok-req-id", requestID)
		// The gateway cannot reliably recover the CLI prompt index from a stateless API request.
		// The field is optional in the official protocol, so do not fabricate x-grok-turn-idx.
		if credential.UserID != "" {
			req.Header.Set("x-grok-user-id", credential.UserID)
		}
		traceID, traceErr := randomHex(16)
		if traceErr != nil {
			return traceErr
		}
		spanID, spanErr := randomHex(8)
		if spanErr != nil {
			return spanErr
		}
		req.Header.Set("traceparent", "00-"+traceID+"-"+spanID+"-01")
	} else {
		if credential.UserID != "" {
			req.Header.Set("x-userid", credential.UserID)
		}
		if credential.Email != "" {
			req.Header.Set("x-email", credential.Email)
		}
	}
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "gzip")
	req.Header.Set("User-Agent", cfg.UserAgent)
	if model != "" {
		req.Header.Set("x-grok-model-override", model)
	}
	return nil
}

// grokSessionID converts a stable session key to the upstream x-grok-conv-id.
// An empty key returns an empty string; stateless requests never receive a random ID.
func grokSessionID(promptCacheKey string) (string, error) {
	key := strings.TrimSpace(promptCacheKey)
	if key == "" {
		return "", nil
	}
	if parsed, err := uuid.Parse(key); err == nil {
		return parsed.String(), nil
	}
	return uuid.NewHash(sha256.New(), uuid.NameSpaceURL, []byte("grok2api:session:"+key), 8).String(), nil
}

// grokConversationGroupIDNamespace mirrors xai-grok-shell `CONVERSATION_GROUP_NAMESPACE`.
const grokConversationGroupIDNamespace = "xai:grok-build:conversation-group:"

// grokConversationGroupID reproduces grok-build `derive_conversation_group_id`:
// UUIDv5(NAMESPACE_OID, namespace + root_session_id). The gateway treats each
// stable session as its own root conversation, so the group id derives from the
// same session id sent as x-grok-conv-id.
func grokConversationGroupID(rootSessionID string) string {
	return uuid.NewSHA1(uuid.NameSpaceOID, []byte(grokConversationGroupIDNamespace+rootSessionID)).String()
}

func injectPromptCacheKey(body []byte, clientKey string) ([]byte, error) {
	key := strings.TrimSpace(clientKey)
	if key == "" {
		return body, nil
	}
	var payload map[string]json.RawMessage
	if err := json.Unmarshal(body, &payload); err != nil {
		return nil, err
	}
	if payload == nil {
		payload = make(map[string]json.RawMessage)
	}
	payload["prompt_cache_key"] = mustJSON(key)
	return json.Marshal(payload)
}

func randomHex(bytesLength int) (string, error) {
	value := make([]byte, bytesLength)
	if _, err := rand.Read(value); err != nil {
		return "", err
	}
	return hex.EncodeToString(value), nil
}

func normalizeGzipResponse(response *http.Response) error {
	if response == nil || response.Body == nil || !strings.EqualFold(strings.TrimSpace(response.Header.Get("Content-Encoding")), "gzip") {
		return nil
	}
	reader, err := gzip.NewReader(response.Body)
	if err != nil {
		_ = response.Body.Close()
		return err
	}
	response.Body = &gzipResponseBody{Reader: reader, source: response.Body}
	response.Header.Del("Content-Encoding")
	response.Header.Del("Content-Length")
	response.ContentLength = -1
	return nil
}

type gzipResponseBody struct {
	*gzip.Reader
	source io.Closer
}

func (b *gzipResponseBody) Close() error {
	readerErr := b.Reader.Close()
	sourceErr := b.source.Close()
	if readerErr != nil {
		return readerErr
	}
	return sourceErr
}

func (a *Adapter) url(path string) string {
	return strings.TrimRight(a.config().BaseURL, "/") + "/" + strings.TrimLeft(path, "/")
}

func (a *Adapter) getBilling(ctx context.Context, credential account.Credential, accessToken, query string) (account.Billing, error) {
	endpoint := a.url("/billing")
	if query != "" {
		endpoint += "?" + query
	}
	requestCtx := infraegress.WithCredential(ctx, credential)
	req, err := http.NewRequestWithContext(requestCtx, http.MethodGet, endpoint, nil)
	if err != nil {
		return account.Billing{}, err
	}
	if err := a.applyHeaders(req, credential, accessToken, "", "", false); err != nil {
		return account.Billing{}, err
	}
	resp, err := a.http.Do(req)
	if err != nil {
		return account.Billing{}, err
	}
	if err := normalizeGzipResponse(resp); err != nil {
		return account.Billing{}, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
	if err != nil {
		return account.Billing{}, err
	}
	if resp.StatusCode != http.StatusOK {
		return account.Billing{}, fmt.Errorf("上游 Billing 接口返回 %d", resp.StatusCode)
	}
	return parseBilling(body)
}

func (a *Adapter) getSubscriptionTier(ctx context.Context, credential account.Credential, accessToken string) (string, error) {
	endpoint := a.url("/user") + "?include=subscription"
	requestCtx, cancel := context.WithTimeout(infraegress.WithCredential(ctx, credential), subscriptionTierTimeout)
	defer cancel()
	req, err := http.NewRequestWithContext(requestCtx, http.MethodGet, endpoint, nil)
	if err != nil {
		return "", err
	}
	if err := a.applyHeaders(req, credential, accessToken, "", "", false); err != nil {
		return "", err
	}
	resp, err := a.http.Do(req)
	if err != nil {
		return "", err
	}
	if err := normalizeGzipResponse(resp); err != nil {
		return "", err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return "", err
	}
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("上游订阅接口返回 %d", resp.StatusCode)
	}
	return parseSubscriptionTier(body)
}
