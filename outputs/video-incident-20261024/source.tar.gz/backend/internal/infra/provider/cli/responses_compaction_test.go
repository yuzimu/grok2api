package cli

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/chenyme/grok2api/backend/internal/domain/account"
	"github.com/chenyme/grok2api/backend/internal/infra/provider"
	"github.com/chenyme/grok2api/backend/internal/infra/provider/conversation"
	"github.com/chenyme/grok2api/backend/internal/infra/security"
	"github.com/chenyme/grok2api/backend/internal/pkg/neterror"
)

func TestGatewayCompactionLifecycle(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	codec := newGatewayCompactionCodec(cipher)
	rawSummary := healthyCompactionSummary()
	upstream := compactionSampleSSE("resp_upstream", rawSummary)
	sample, err := parseGatewayCompactionStream([]byte(upstream))
	if err != nil {
		t.Fatal(err)
	}
	continuation := gatewayCompactionContinuation(sample.summary)
	if !strings.HasPrefix(continuation, "This session is being continued") || strings.Contains(continuation, "<summary>") || !strings.Contains(continuation, "Summary:\n1. Primary") {
		t.Fatalf("continuation = %q", continuation)
	}
	blob, err := codec.encode("session-1", continuation)
	if err != nil {
		t.Fatal(err)
	}
	stream, contentType, err := buildGatewayCompactionResponse(sample.response, blob, "grok-4.5", true)
	if err != nil {
		t.Fatal(err)
	}
	for _, event := range []string{"response.created", "response.in_progress", "response.output_item.added", "response.output_item.done", "response.completed"} {
		if !strings.Contains(string(stream), "event: "+event) {
			t.Fatalf("compaction stream missing %s: %s", event, stream)
		}
	}
	if contentType != "text/event-stream" {
		t.Fatalf("content type = %q", contentType)
	}
	blob = compactionBlobFromSSE(t, stream)
	expanded, drifted, err := expandGatewayCompactionHistory([]byte(`{"input":[{"type":"compaction","encrypted_content":`+mustJSONString(blob)+`}]} `), codec, "session-1")
	if err != nil {
		t.Fatal(err)
	}
	if drifted != 0 || !strings.Contains(string(expanded), "This session is being continued") || strings.Contains(string(expanded), `"type":"compaction"`) || !strings.Contains(string(expanded), `"role":"user"`) {
		t.Fatalf("expanded = %s, drifted = %d", expanded, drifted)
	}
	mismatched, drifted, err := expandGatewayCompactionHistory([]byte(`{"input":[{"type":"compaction","encrypted_content":`+mustJSONString(blob)+`}]} `), codec, "other-session")
	if err != nil || drifted != 1 || strings.Contains(string(mismatched), blob) || strings.Contains(string(mismatched), "could not be decoded") || !strings.Contains(string(mismatched), "This session is being continued") {
		t.Fatalf("session mismatch expansion = %s, drifted = %d, err = %v", mismatched, drifted, err)
	}
}

func TestForwardResponseRetainsSessionDriftedCompaction(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	blob, err := adapter.compaction.encode("old-session", gatewayCompactionContinuation(healthyCompactionSummary()))
	if err != nil {
		t.Fatal(err)
	}
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		data, readErr := io.ReadAll(request.Body)
		if readErr != nil {
			t.Fatal(readErr)
		}
		if strings.Contains(string(data), blob) || strings.Contains(string(data), "could not be decoded") || !strings.Contains(string(data), "This session is being continued") {
			t.Fatalf("session-drifted summary was not retained: %s", data)
		}
		return sseResponse(http.StatusOK, "event: response.completed\ndata: {\"type\":\"response.completed\",\"response\":{\"id\":\"resp_drifted\",\"object\":\"response\",\"status\":\"completed\",\"model\":\"grok-4.5\",\"output\":[]}}\n\n", request), nil
	})
	response, err := adapter.ForwardResponse(t.Context(), provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", PromptCacheKey: "new-session",
		Streaming: true, NormalizeBody: true,
		Body: []byte(`{"model":"public","stream":true,"input":[{"type":"compaction","encrypted_content":` + mustJSONString(blob) + `},{"role":"user","content":"continue"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if !strings.Contains(response.Header.Get("X-Grok2API-Compatibility-Warnings"), "compaction_session_drifted") {
		t.Fatalf("warnings = %q", response.Header.Get("X-Grok2API-Compatibility-Warnings"))
	}
}

func TestUndecodableGatewayCompactionReturnsRequestError(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	body := []byte(`{"input":[{"type":"compaction","encrypted_content":"g2a_compact_v1.invalid"}]}`)
	expanded, drifted, err := expandGatewayCompactionHistory(body, newGatewayCompactionCodec(cipher), "session-1")
	var requestErr *responsesRequestError
	if !errors.As(err, &requestErr) || requestErr.Code != "invalid_compaction_blob" || requestErr.Param != "input[0].encrypted_content" {
		t.Fatalf("error = %#v", err)
	}
	if drifted != 0 || !bytes.Equal(expanded, body) {
		t.Fatalf("expanded = %s, drifted = %d", expanded, drifted)
	}
}

func TestForwardResponseRejectsUndecodableGatewayCompactionBeforeUpstream(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	var calls atomic.Int32
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		calls.Add(1)
		return jsonHTTPResponse(request, http.StatusOK, `{}`), nil
	})
	response, err := adapter.ForwardResponse(t.Context(), provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", PromptCacheKey: "session-1",
		NormalizeBody: true,
		Body:          []byte(`{"model":"public","input":[{"type":"compaction","encrypted_content":"g2a_compact_v1.invalid"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	body, _ := io.ReadAll(response.Body)
	if calls.Load() != 0 || response.StatusCode != http.StatusBadRequest || !strings.Contains(string(body), `"code":"invalid_compaction_blob"`) || !strings.Contains(string(body), `"param":"input[0].encrypted_content"`) {
		t.Fatalf("calls=%d status=%d body=%s", calls.Load(), response.StatusCode, body)
	}
}

func TestGatewayCompactionHTTPFailureHonorsRetryVetoAndRateLimitMetadata(t *testing.T) {
	body := `{"code":"resource-exhausted","error":"Too many requests for team 00000000-0000-0000-0000-000000000013 and model grok-4.5. Requests per Second (actual/limit): 2/2."}`
	response, transient, err := gatewayCompactionHTTPFailure(&http.Response{
		StatusCode: http.StatusTooManyRequests,
		Status:     "429 Too Many Requests",
		Header: http.Header{
			"X-Should-Retry": {"false"},
			"Retry-After":    {"17"},
		},
		Body: io.NopCloser(strings.NewReader(body)),
	}, "https://build.test/v1/responses", false, "")
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if transient {
		t.Fatal("x-should-retry:false must suppress same-account compaction retries")
	}
	if response.RateLimit == nil || response.RateLimit.TeamID != "00000000-0000-0000-0000-000000000013" || response.RateLimit.Model != "grok-4.5" || response.RateLimit.RetryAfter != 17*time.Second {
		t.Fatalf("rate limit = %#v", response.RateLimit)
	}
}

func TestGatewayCompactionRetryVetoStopsSameAccountRetries(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	var attempts atomic.Int32
	body := `{"code":"subscription:free-usage-exhausted","error":"You have used all your free usage"}`
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		attempts.Add(1)
		response := sseResponse(http.StatusTooManyRequests, body, request)
		response.Header.Set("X-Should-Retry", "false")
		return response, nil
	})
	request := compactionProviderRequest(encrypted)
	response, err := adapter.forwardGatewayCompactionWithPolicy(t.Context(), request, "access-token", request.Body, "", 3, 0)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if attempts.Load() != 1 || response.StatusCode != http.StatusTooManyRequests {
		t.Fatalf("attempts=%d status=%d", attempts.Load(), response.StatusCode)
	}
}

func TestGatewayCompactionSemanticIdleIgnoresKeepalives(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	cfg := adapter.config()
	cfg.StreamIdleTimeout = 60 * time.Millisecond
	adapter.UpdateConfig(cfg)

	writeDone := make(chan struct{})
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		reader, writer := io.Pipe()
		go func() {
			defer close(writeDone)
			defer writer.Close()
			for {
				if _, err := io.WriteString(writer, ": keep-alive\n\n"); err != nil {
					return
				}
				time.Sleep(10 * time.Millisecond)
			}
		}()
		return &http.Response{
			StatusCode: http.StatusOK,
			Status:     "200 OK",
			Header:     http.Header{"Content-Type": []string{"text/event-stream"}},
			Body:       reader,
			Request:    request,
		}, nil
	})

	request := compactionProviderRequest(encrypted)
	_, err := adapter.forwardGatewayCompactionWithPolicy(t.Context(), request, "access-token", request.Body, "", 1, 0)
	if !errors.Is(err, neterror.ErrUpstreamStreamIdleTimeout) {
		t.Fatalf("compaction error = %v, want ErrUpstreamStreamIdleTimeout", err)
	}
	select {
	case <-writeDone:
	case <-time.After(time.Second):
		t.Fatal("semantic timeout did not close the compaction response body")
	}
}

func TestGatewayCompactionResponseNormalizesPartialUsage(t *testing.T) {
	response := map[string]any{
		"id":    "resp_usage",
		"usage": map[string]any{"input_tokens": float64(7), "output_tokens": float64(5)},
	}
	encoded, _, err := buildGatewayCompactionResponse(response, "opaque", "grok-4.5", true)
	if err != nil {
		t.Fatal(err)
	}
	var completed map[string]any
	for _, line := range strings.Split(string(encoded), "\n") {
		if !strings.HasPrefix(line, "data: ") || !strings.Contains(line, `"type":"response.completed"`) {
			continue
		}
		if err := json.Unmarshal([]byte(strings.TrimPrefix(line, "data: ")), &completed); err != nil {
			t.Fatal(err)
		}
	}
	responseValue, _ := completed["response"].(map[string]any)
	usage, _ := responseValue["usage"].(map[string]any)
	if usage["input_tokens"] != float64(7) || usage["output_tokens"] != float64(5) || usage["total_tokens"] != float64(12) {
		t.Fatalf("usage = %#v", usage)
	}
}

func TestCleanGatewayCompactionSummaryMatchesGrokBuildScratchpadRules(t *testing.T) {
	raw := "<summary>**Analysis**\nprivate draft\n</analysis>\n<summary>1. Primary Request: keep this. " + strings.Repeat("x", 520) + "</summary></summary>"
	cleaned := cleanGatewayCompactionSummary(raw)
	if strings.Contains(cleaned, "private draft") || !strings.HasPrefix(cleaned, "Summary:\n1. Primary Request") || strings.Contains(cleaned, "<summary>") {
		t.Fatalf("cleaned = %q", cleaned)
	}

	numbered := cleanGatewayCompactionSummary("<summary>1. Primary: quoted </analysis> token remains harmless.</summary>")
	if !strings.Contains(numbered, "1. Primary") || !strings.Contains(numbered, "<\u200b/analysis>") {
		t.Fatalf("numbered = %q", numbered)
	}
}

func TestPrepareGatewayCompactionSampleMatchesGrokBuild02106(t *testing.T) {
	prepared, err := prepareGatewayCompactionSample([]byte(`{
		"model":"grok-4.5","stream":true,"store":true,"instructions":"client instructions",
		"previous_response_id":"resp_old","max_output_tokens":200,
		"tools":[{"type":"function","name":"lookup","parameters":{"type":"object"}}],
		"input":[{"type":"message","role":"user","content":"hello"}]
	}`))
	if err != nil {
		t.Fatal(err)
	}
	var payload map[string]any
	if json.Unmarshal(prepared, &payload) != nil {
		t.Fatalf("payload = %s", prepared)
	}
	if payload["stream"] != true || payload["store"] != false || payload["instructions"] != nil || payload["temperature"] != float64(1) || payload["tool_choice"] != "auto" {
		t.Fatalf("sample controls = %#v", payload)
	}
	if _, exists := payload["previous_response_id"]; exists {
		t.Fatalf("previous_response_id leaked: %s", prepared)
	}
	if _, exists := payload["max_output_tokens"]; exists {
		t.Fatalf("max_output_tokens leaked: %s", prepared)
	}
	if len(payload["tools"].([]any)) != 1 || payload["reasoning"].(map[string]any)["summary"] != "concise" {
		t.Fatalf("sample tools/reasoning = %#v", payload)
	}
	items := payload["input"].([]any)
	last := items[len(items)-1].(map[string]any)
	if last["role"] != "user" || last["content"] != gatewayCompactionPrompt || strings.Contains(string(prepared), "compaction_trigger") {
		t.Fatalf("sample input = %#v", items)
	}
}

func TestPrepareGatewayCompactionSampleOmitsToolChoiceWithoutTools(t *testing.T) {
	prepared, err := prepareGatewayCompactionSample([]byte(`{"model":"grok-4.5","tool_choice":"auto","input":[{"role":"user","content":"hello"}]}`))
	if err != nil {
		t.Fatal(err)
	}
	var payload map[string]any
	if json.Unmarshal(prepared, &payload) != nil {
		t.Fatalf("payload = %s", prepared)
	}
	if _, exists := payload["tool_choice"]; exists {
		t.Fatalf("tool_choice without tools = %#v", payload["tool_choice"])
	}
}

func TestUpstreamCompactionBlobIsForwarded(t *testing.T) {
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	blob := "opaque/upstream+compact=blob"
	body := []byte(`{"previous_response_id":"resp_compacted","input":[{"type":"compaction","encrypted_content":` + mustJSONString(blob) + `},{"role":"user","content":"continue"}]}`)
	expanded, drifted, err := expandGatewayCompactionHistory(body, newGatewayCompactionCodec(cipher), "session-1")
	if err != nil {
		t.Fatal(err)
	}
	if drifted != 0 || !bytes.Equal(expanded, body) {
		t.Fatalf("expanded = %s, drifted = %d", expanded, drifted)
	}
}

func TestForwardResponseKeepsUpstreamCompactionBlob(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	blob := "opaque/upstream+compact=blob"
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		data, readErr := io.ReadAll(request.Body)
		if readErr != nil {
			t.Fatal(readErr)
		}
		var forwarded struct {
			PreviousResponseID string `json:"previous_response_id"`
			Input              []struct {
				Type             string `json:"type"`
				ID               string `json:"id"`
				EncryptedContent string `json:"encrypted_content"`
			} `json:"input"`
		}
		if json.Unmarshal(data, &forwarded) != nil || forwarded.PreviousResponseID != "resp_compacted" || len(forwarded.Input) != 2 || forwarded.Input[0].Type != "compaction" || forwarded.Input[0].ID != "cmp_upstream" || forwarded.Input[0].EncryptedContent != blob || strings.Contains(string(data), "could not be decoded") {
			t.Fatalf("upstream compact blob was rewritten: %s", data)
		}
		return jsonHTTPResponse(request, http.StatusOK, `{"id":"resp_ok","status":"completed","output":[]}`), nil
	})
	response, err := adapter.ForwardResponse(t.Context(), provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", PromptCacheKey: "session-1",
		NormalizeBody: true,
		Body:          []byte(`{"model":"public","previous_response_id":"resp_compacted","input":[{"type":"compaction","id":"cmp_upstream","encrypted_content":` + mustJSONString(blob) + `},{"role":"user","content":"continue"}]}`),
	})
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK || response.Header.Get("X-Grok2API-Compatibility-Warnings") != "" {
		t.Fatalf("status=%d warnings=%q", response.StatusCode, response.Header.Get("X-Grok2API-Compatibility-Warnings"))
	}
}

func TestRemoteCompactionTriggerMustBeTerminal(t *testing.T) {
	_, _, err := normalizeResponsesRequest([]byte(`{"model":"public","input":[{"type":"compaction_trigger"},{"role":"user","content":"late item"}]}`), "grok-4.5")
	var requestErr *responsesRequestError
	if err == nil || !strings.Contains(err.Error(), "最后一项") || !errors.As(err, &requestErr) || requestErr.Param != "input[0]" {
		t.Fatalf("error = %#v", err)
	}
}

func TestForwardResponseEmulatesRemoteCompactionV2(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		if request.Header.Get("Accept") != "text/event-stream" {
			t.Fatalf("upstream Accept = %q", request.Header.Get("Accept"))
		}
		data, readErr := io.ReadAll(request.Body)
		if readErr != nil {
			t.Fatal(readErr)
		}
		var payload map[string]any
		if json.Unmarshal(data, &payload) != nil {
			t.Fatalf("payload = %s", data)
		}
		if payload["stream"] != true || payload["store"] != false || payload["instructions"] != nil || payload["tool_choice"] != "auto" {
			t.Fatalf("sample flags = %#v", payload)
		}
		if _, exists := payload["prompt_cache_key"]; exists {
			t.Fatalf("prompt_cache_key must stay header-only for compaction: %s", data)
		}
		items := payload["input"].([]any)
		if strings.Contains(string(data), "compaction_trigger") || items[len(items)-1].(map[string]any)["content"] != gatewayCompactionPrompt {
			t.Fatalf("compaction sample = %s", data)
		}
		return sseResponse(http.StatusOK, compactionSampleSSE("resp_sample", healthyCompactionSummary()), request), nil
	})
	response, err := adapter.ForwardResponse(t.Context(), compactionProviderRequest(encrypted))
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	data, err := io.ReadAll(response.Body)
	if err != nil {
		t.Fatal(err)
	}
	if response.Header.Get("Content-Type") != "text/event-stream" || !strings.Contains(string(data), `"type":"compaction"`) || !strings.Contains(string(data), "response.completed") {
		t.Fatalf("response = %s, headers = %#v", data, response.Header)
	}
	if !strings.Contains(response.Header.Get("X-Grok2API-Compatibility-Warnings"), "remote_compaction_v2_emulated") {
		t.Fatalf("warnings = %q", response.Header.Get("X-Grok2API-Compatibility-Warnings"))
	}
}

// TestGatewayCompactionLifecycleWithMillionTokenScaleHistory 验证超长历史压缩后，
// 下一轮只会向上游发送解密出的摘要和新消息，不会重新发送原始历史或 opaque blob。
func TestGatewayCompactionLifecycleWithMillionTokenScaleHistory(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	// “x ”在常见 BPE 编码中接近一个 token；此处保守构造超过 1M token 量级的历史文本。
	history := strings.Repeat("x ", 2<<20)
	summary := healthyCompactionSummary()
	continuation := gatewayCompactionContinuation(summary)
	encodedSummary, err := json.Marshal(continuation)
	if err != nil {
		t.Fatal(err)
	}
	var calls atomic.Int32
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		call := calls.Add(1)
		data, readErr := io.ReadAll(request.Body)
		if readErr != nil {
			t.Fatal(readErr)
		}
		switch call {
		case 1:
			if len(data) < 4<<20 || strings.Contains(string(data), "compaction_trigger") {
				t.Fatalf("压缩采样未携带完整超长历史：size=%d", len(data))
			}
			return sseResponse(http.StatusOK, compactionSampleSSE("resp_million", summary), request), nil
		case 2:
			if len(data) >= 4096 || strings.Contains(string(data), `"type":"compaction"`) || strings.Contains(string(data), `"encrypted_content"`) || !strings.Contains(string(data), string(encodedSummary)) || !strings.Contains(string(data), "压缩后继续执行") {
				t.Fatalf("压缩回放泄漏原始状态：size=%d", len(data))
			}
			return jsonHTTPResponse(request, http.StatusOK, `{"id":"resp_continue","status":"completed","output":[]}`), nil
		default:
			t.Fatalf("unexpected call %d", call)
			return nil, nil
		}
	})

	initialBody, err := json.Marshal(map[string]any{
		"model": "grok-4.5",
		"input": []any{
			map[string]any{"type": "message", "role": "user", "content": history},
			map[string]any{"type": "compaction_trigger"},
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	compacted, err := adapter.ForwardResponse(t.Context(), provider.ResponseResourceRequest{
		Credential:     account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:         http.MethodPost,
		Path:           "/responses",
		Model:          "grok-4.5",
		PromptCacheKey: "million-token-session",
		Body:           initialBody,
		NormalizeBody:  true,
		Operation:      conversation.OperationResponses,
	})
	if err != nil {
		t.Fatal(err)
	}
	compactedBody, readErr := io.ReadAll(compacted.Body)
	_ = compacted.Body.Close()
	if readErr != nil {
		t.Fatal(readErr)
	}
	var compactedPayload struct {
		Output []struct {
			Type             string `json:"type"`
			EncryptedContent string `json:"encrypted_content"`
		} `json:"output"`
	}
	if json.Unmarshal(compactedBody, &compactedPayload) != nil || len(compactedPayload.Output) != 1 || compactedPayload.Output[0].Type != "compaction" || compactedPayload.Output[0].EncryptedContent == "" {
		t.Fatalf("压缩响应无有效 blob：%s", compactedBody)
	}

	continuedBody, err := json.Marshal(map[string]any{
		"model": "grok-4.5",
		"input": []any{
			map[string]any{"type": "compaction", "encrypted_content": compactedPayload.Output[0].EncryptedContent},
			map[string]any{"type": "message", "role": "user", "content": "压缩后继续执行"},
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	continued, err := adapter.ForwardResponse(t.Context(), provider.ResponseResourceRequest{
		Credential:     account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:         http.MethodPost,
		Path:           "/responses",
		Model:          "grok-4.5",
		PromptCacheKey: "million-token-session",
		Body:           continuedBody,
		NormalizeBody:  true,
		Operation:      conversation.OperationResponses,
	})
	if err != nil {
		t.Fatal(err)
	}
	defer continued.Body.Close()
	if calls.Load() != 2 || continued.StatusCode != http.StatusOK {
		t.Fatalf("calls=%d status=%d", calls.Load(), continued.StatusCode)
	}
}

func TestCompactionRetriesDegenerateSamplesOnSameAccount(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	var attempts atomic.Int32
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		attempt := attempts.Add(1)
		summary := "<summary>too short</summary>"
		if attempt == 3 {
			summary = healthyCompactionSummary()
		}
		return sseResponse(http.StatusOK, compactionSampleSSE("resp_retry", summary), request), nil
	})
	request := compactionProviderRequest(encrypted)
	prepared, compatibility, err := normalizeResponsesRequest(request.Body, request.Model)
	if err != nil {
		t.Fatal(err)
	}
	prepared, err = prepareGatewayCompactionSample(prepared)
	if err != nil {
		t.Fatal(err)
	}
	response, err := adapter.forwardGatewayCompactionWithPolicy(t.Context(), request, "access-token", prepared, compatibility.warningHeader(), 3, 0)
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if attempts.Load() != 3 || response.StatusCode != http.StatusOK {
		t.Fatalf("attempts = %d, status = %d", attempts.Load(), response.StatusCode)
	}
}

func TestCompactionStreamErrorsUseGrokBuildRetryClassification(t *testing.T) {
	deterministic := `event: response.failed
data: {"type":"response.failed","response":{"error":{"code":"invalid_request_error","message":"bad schema"}}}

`
	_, err := parseGatewayCompactionStream([]byte(deterministic))
	if err == nil || gatewayCompactionErrorIsTransient(err) {
		t.Fatalf("deterministic error = %#v", err)
	}

	transient := `event: error
data: {"type":"error","code":"503","message":"temporarily unavailable"}

`
	_, err = parseGatewayCompactionStream([]byte(transient))
	if err == nil || !gatewayCompactionErrorIsTransient(err) {
		t.Fatalf("transient error = %#v", err)
	}
}

func TestCompactionPostProcessingFailureDoesNotRetryAnotherAccount(t *testing.T) {
	adapter, encrypted := newCompactionTestAdapter(t)
	adapter.compaction = nil
	adapter.http.Transport = roundTripFunc(func(request *http.Request) (*http.Response, error) {
		return sseResponse(http.StatusOK, compactionSampleSSE("resp_sample", healthyCompactionSummary()), request), nil
	})
	response, err := adapter.ForwardResponse(t.Context(), compactionProviderRequest(encrypted))
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusBadGateway || response.Header.Get("X-Should-Retry") != "false" {
		t.Fatalf("status = %d, headers = %#v", response.StatusCode, response.Header)
	}
}

func newCompactionTestAdapter(t *testing.T) (*Adapter, string) {
	t.Helper()
	cipher, err := security.NewCipher(base64.StdEncoding.EncodeToString(make([]byte, 32)))
	if err != nil {
		t.Fatal(err)
	}
	encrypted, err := cipher.Encrypt("access-token")
	if err != nil {
		t.Fatal(err)
	}
	adapter := NewAdapter(Config{
		BaseURL: "https://build.test/v1", ClientVersion: "0.2.110",
		ClientIdentifier: "grok-shell", TokenAuth: "xai-grok-cli", UserAgent: "grok-shell/0.2.110 (linux; x86_64)",
	}, cipher)
	return adapter, encrypted
}

func compactionProviderRequest(encrypted string) provider.ResponseResourceRequest {
	return provider.ResponseResourceRequest{
		Credential: account.Credential{ID: 1, Provider: account.ProviderBuild, EncryptedAccessToken: encrypted},
		Method:     http.MethodPost, Path: "/responses", Model: "grok-4.5", PromptCacheKey: "session-1",
		Streaming: true, NormalizeBody: true,
		Body: []byte(`{"model":"public","stream":true,"tools":[{"type":"function","name":"lookup","parameters":{"type":"object"}}],"input":[{"role":"user","content":"hello"},{"type":"compaction_trigger"}]}`),
	}
}

func compactionSampleSSE(responseID, summary string) string {
	item, _ := json.Marshal(map[string]any{
		"type": "message", "id": "msg_compact", "role": "assistant", "status": "completed",
		"content": []any{map[string]any{"type": "output_text", "text": summary}},
	})
	completed, _ := json.Marshal(map[string]any{
		"type": "response.completed", "response": map[string]any{
			"id": responseID, "object": "response", "status": "completed", "model": "grok-4.5",
			"output": []any{json.RawMessage(item)},
			"usage":  map[string]any{"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
		},
	})
	return "event: response.output_item.done\ndata: {\"type\":\"response.output_item.done\",\"output_index\":0,\"item\":" + string(item) + "}\n\n" +
		"event: response.completed\ndata: " + string(completed) + "\n\n"
}

func healthyCompactionSummary() string {
	return "<summary>1. Primary Request and Intent: continue the task. 2. Key Technical Concepts: Responses and compaction. 3. Files and Code Sections: adapter.go. 4. Errors and Fixes: fixed the protocol. 5. Problem Solving: verified the flow. 6. All User Messages: continue. 7. Pending Tasks: tests. 8. Current Work: compaction. 9. Optional Next Step: verify. " + strings.Repeat("x", 600) + "</summary>"
}

func sseResponse(status int, body string, request *http.Request) *http.Response {
	return &http.Response{
		StatusCode: status, Status: http.StatusText(status), Request: request,
		Header: http.Header{"Content-Type": []string{"text/event-stream"}},
		Body:   io.NopCloser(strings.NewReader(body)),
	}
}

func compactionBlobFromSSE(t *testing.T, stream []byte) string {
	t.Helper()
	for _, line := range strings.Split(string(stream), "\n") {
		if !strings.HasPrefix(line, "data: ") {
			continue
		}
		var event map[string]any
		if json.Unmarshal([]byte(strings.TrimPrefix(line, "data: ")), &event) != nil || event["type"] != "response.output_item.done" {
			continue
		}
		item, _ := event["item"].(map[string]any)
		blob, _ := item["encrypted_content"].(string)
		if blob != "" {
			return blob
		}
	}
	t.Fatal("compaction blob missing")
	return ""
}

func mustJSONString(value string) string {
	data, _ := json.Marshal(value)
	return string(data)
}
