package web

import (
	"context"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"testing"
	"time"

	accountdomain "github.com/chenyme/grok2api/backend/internal/domain/account"
	"github.com/chenyme/grok2api/backend/internal/infra/provider"
)

type scriptedSSOClient struct {
	responses []*http.Response
	requests  []*http.Request
}

func (c *scriptedSSOClient) Do(request *http.Request) (*http.Response, error) {
	c.requests = append(c.requests, request)
	response := c.responses[0]
	c.responses = c.responses[1:]
	return response, nil
}

func TestSSOBuildFlowFollowsOnlyTrustedXAIHTTPSRedirects(t *testing.T) {
	client := &scriptedSSOClient{responses: []*http.Response{
		{StatusCode: http.StatusFound, Header: http.Header{"Location": []string{"https://auth.x.ai/next"}, "Set-Cookie": []string{"session=abc; Path=/; Secure"}}, Body: io.NopCloser(strings.NewReader(""))},
		{StatusCode: http.StatusOK, Header: http.Header{}, Body: io.NopCloser(strings.NewReader("ok"))},
	}}
	flow := &ssoBuildFlow{client: client, userAgent: "test-agent", cookies: map[string]string{"sso": "secret"}}
	status, finalURL, body, err := flow.do(context.Background(), http.MethodGet, ssoDeviceURL, nil)
	if err != nil {
		t.Fatal(err)
	}
	if status != http.StatusOK || finalURL != "https://auth.x.ai/next" || string(body) != "ok" {
		t.Fatalf("response = %d %s %q", status, finalURL, body)
	}
	if len(client.requests) != 2 || client.requests[1].Header.Get("User-Agent") != "test-agent" {
		t.Fatalf("requests = %#v", client.requests)
	}
	cookie := client.requests[1].Header.Get("Cookie")
	if !strings.Contains(cookie, "sso=secret") || !strings.Contains(cookie, "session=abc") {
		t.Fatalf("redirect cookies = %q", cookie)
	}

	unsafe := &scriptedSSOClient{responses: []*http.Response{{StatusCode: http.StatusFound, Header: http.Header{"Location": []string{"https://example.com/steal"}}, Body: io.NopCloser(strings.NewReader(""))}}}
	flow = &ssoBuildFlow{client: unsafe, userAgent: "test-agent", cookies: map[string]string{"sso": "secret"}}
	if _, _, _, err := flow.do(context.Background(), http.MethodGet, ssoDeviceURL, nil); err == nil {
		t.Fatal("unsafe redirect was accepted")
	}
}

func TestSSOBuildFlowMapsDeadSSOToUnauthorized(t *testing.T) {
	client := &scriptedSSOClient{responses: []*http.Response{
		{StatusCode: http.StatusOK, Header: http.Header{}, Body: io.NopCloser(strings.NewReader(
			`{"device_code":"dc","user_code":"uc","interval":1,"expires_in":1800}`))},
		{StatusCode: http.StatusSeeOther, Header: http.Header{"Location": []string{"https://accounts.x.ai/sign-in"}}, Body: io.NopCloser(strings.NewReader(""))},
	}}
	flow := &ssoBuildFlow{client: client, userAgent: "lease-agent", cookies: map[string]string{"sso": "dead"}}
	_, err := flow.convert(context.Background(), fakeCredential())
	if !errors.Is(err, provider.ErrUnauthorized) {
		t.Fatalf("err = %v, want ErrUnauthorized", err)
	}
	if len(client.requests) != 2 {
		t.Fatalf("requests = %d, want 2 (device, verify)", len(client.requests))
	}
}

// TestSSOBuildFlowUsesAuthEndpointsOnly 验证授权请求携带 consent 令牌及浏览器来源。
func TestSSOBuildFlowUsesAuthEndpointsOnly(t *testing.T) {
	client := &scriptedSSOClient{responses: []*http.Response{
		{StatusCode: http.StatusOK, Header: http.Header{}, Body: io.NopCloser(strings.NewReader(
			`{"device_code":"dc","user_code":"uc","interval":1,"expires_in":1800}`))},
		{StatusCode: http.StatusSeeOther, Header: http.Header{"Location": []string{"https://accounts.x.ai/oauth2/device/consent?user_code=uc"}}, Body: io.NopCloser(strings.NewReader(""))},
		{StatusCode: http.StatusOK, Header: http.Header{}, Body: io.NopCloser(strings.NewReader(
			`<html><form action="https://auth.x.ai/oauth2/device/approve" method="POST"><input type="hidden" name="consent_token" value="ct-123"/></form></html>`))},
		{StatusCode: http.StatusSeeOther, Header: http.Header{"Location": []string{"https://accounts.x.ai/oauth2/device/done"}}, Body: io.NopCloser(strings.NewReader(""))},
		{StatusCode: http.StatusOK, Header: http.Header{}, Body: io.NopCloser(strings.NewReader(
			`{"access_token":"access","refresh_token":"refresh","expires_in":3600}`))},
	}}
	flow := &ssoBuildFlow{client: client, userAgent: "lease-agent", cookies: map[string]string{"sso": "live", "sso-rw": "live"}}
	seed, err := flow.convert(context.Background(), fakeCredential())
	if err != nil {
		t.Fatal(err)
	}
	if seed.AccessToken != "access" || seed.RefreshToken != "refresh" || len(client.requests) != 5 {
		t.Fatalf("seed=%#v requests=%d", seed, len(client.requests))
	}
	for _, request := range client.requests {
		host := request.URL.Hostname()
		if host != "auth.x.ai" && host != "accounts.x.ai" {
			t.Fatalf("device flow visited unexpected host %q", host)
		}
	}
	approve := client.requests[3]
	if approve.URL.Hostname() != "auth.x.ai" || !strings.Contains(approve.URL.Path, "approve") {
		t.Fatalf("request[3] = %s, want approve POST", approve.URL)
	}
	if approve.Header.Get("Origin") != "https://accounts.x.ai" {
		t.Fatalf("approve missing Origin header: %v", approve.Header)
	}
	if approve.Header.Get("Referer") != "https://accounts.x.ai/oauth2/device/consent?user_code=uc" {
		t.Fatalf("approve Referer = %q", approve.Header.Get("Referer"))
	}
	body, err := io.ReadAll(approve.Body)
	if err != nil {
		t.Fatal(err)
	}
	form, err := url.ParseQuery(string(body))
	if err != nil {
		t.Fatal(err)
	}
	if form.Get("consent_token") != "ct-123" || form.Get("user_code") != "uc" {
		t.Fatalf("approve form = %v", form)
	}
}

func TestSSOBuildFlowVerifyDoesNotFollowRedirect(t *testing.T) {
	client := &scriptedSSOClient{responses: []*http.Response{
		{StatusCode: http.StatusSeeOther, Header: http.Header{"Location": []string{"https://accounts.x.ai/oauth2/device/consent"}}, Body: io.NopCloser(strings.NewReader(""))},
	}}
	flow := &ssoBuildFlow{client: client, userAgent: "lease-agent", cookies: map[string]string{"sso": "live"}}
	status, finalURL, _, err := flow.doWithFollow(context.Background(), http.MethodPost, ssoVerifyURL, url.Values{"user_code": {"uc"}}, false, nil)
	if err != nil {
		t.Fatal(err)
	}
	if status != http.StatusSeeOther {
		t.Fatalf("status = %d, want 303", status)
	}
	if finalURL != "https://accounts.x.ai/oauth2/device/consent" {
		t.Fatalf("finalURL = %q", finalURL)
	}
	if len(client.requests) != 1 {
		t.Fatalf("redirect must not be followed, requests = %d", len(client.requests))
	}
}

func TestSSODeviceRedirectStateRequiresExactTrustedPath(t *testing.T) {
	tests := map[string]string{
		"https://accounts.x.ai/oauth2/device/consent":           "consent",
		"https://accounts.x.ai/oauth2/device/done/":             "done",
		"https://accounts.x.ai/sign-in?returnTo=%2Foauth2":      "sign-in",
		"https://accounts.x.ai/other?next=consent":              "",
		"https://accounts.x.ai/oauth2/device/consent-untrusted": "",
		"https://example.com/oauth2/device/consent":             "",
	}
	for raw, wanted := range tests {
		if actual := ssoDeviceRedirectState(raw); actual != wanted {
			t.Fatalf("ssoDeviceRedirectState(%q)=%q want=%q", raw, actual, wanted)
		}
	}
}

func fakeCredential() accountdomain.Credential { return accountdomain.Credential{} }

func TestSSOBuildConversionSanitizesTokenAndURLs(t *testing.T) {
	if token := normalizeSSOToken("sso=token-value; x-userid=drop"); token != "token-value" {
		t.Fatalf("token = %q", token)
	}
	for _, value := range []string{"https://accounts.x.ai/", "https://auth.x.ai/oauth2/device/code"} {
		if !safeXAIURL(value) {
			t.Fatalf("trusted URL rejected: %s", value)
		}
	}
	for _, value := range []string{"http://auth.x.ai/", "https://x.ai.example.com/", "https://user@auth.x.ai/"} {
		if safeXAIURL(value) {
			t.Fatalf("unsafe URL accepted: %s", value)
		}
	}
}

// TestScrapeConsentToken 验证授权令牌解析不依赖属性排列。
func TestScrapeConsentToken(t *testing.T) {
	page := []byte(`<input type="hidden" name="user_code" value="x"/><input type="hidden" name="consent_token" value="tok-abc-123"/>`)
	if got := scrapeConsentToken(page); got != "tok-abc-123" {
		t.Fatalf("scrapeConsentToken = %q", got)
	}
	if got := scrapeConsentToken([]byte(`<input value="tok-reordered" type="hidden" name="consent_token">`)); got != "tok-reordered" {
		t.Fatalf("reordered consent input = %q", got)
	}
	if got := scrapeConsentToken([]byte(`<input name="other" value="x"/>`)); got != "" {
		t.Fatalf("expected empty, got %q", got)
	}
}

// TestConsentTokenBoundByUserCode mirrors the live consent page (2026-10-20):
// self-closing hidden inputs and a dc claim that is a server-side UUID.
func TestConsentTokenBoundByUserCode(t *testing.T) {
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"typ":"consent+jwt","alg":"ES256","kid":"k"}`))
	exp := time.Now().Add(5 * time.Minute).Unix()
	claims := base64.RawURLEncoding.EncodeToString([]byte(fmt.Sprintf(`{"dc":"0b7c6f0e-1111-4222-8333-444455556666","aud":"consent","exp":%d}`, exp)))
	token := header + "." + claims + ".sig"
	page := []byte(`<form><input type="hidden" name="user_code" value="5C3A-S5Y7"/><input type="hidden" name="principal_type" value="User"/><input type="hidden" name="consent_token" value="` + token + `"/></form>`)
	if got := extractConsentToken(page); got != token {
		t.Fatalf("self-closing consent_token = %q", got)
	}
	pageUserCode := extractConsentInput(page, "user_code")
	if !consentTokenMatchesUserCode(token, pageUserCode, "5C3A-S5Y7", time.Now()) {
		t.Fatal("consent token bound to our user_code was rejected")
	}
	if consentTokenMatchesUserCode(token, pageUserCode, "ZZZZ-ZZZZ", time.Now()) {
		t.Fatal("consent page for another user_code was accepted")
	}
	if consentTokenMatchesUserCode(token, pageUserCode, "5C3A-S5Y7", time.Now().Add(time.Hour)) {
		t.Fatal("expired consent token was accepted")
	}
	plain := base64.RawURLEncoding.EncodeToString([]byte(`{"typ":"JWT","alg":"ES256"}`)) + "." + claims + ".sig"
	if consentTokenMatchesUserCode(plain, pageUserCode, "5C3A-S5Y7", time.Now()) {
		t.Fatal("non-consent JWT was accepted")
	}
}

func TestBrowserVerificationRequiredBody(t *testing.T) {
	live := []byte(`<h1>Request could not be verified</h1><p>We could not verify this browser. Allow scripts and turn off ad or tracker blockers for this site, then enter the code again.</p>`)
	if !isBrowserVerificationRequired(live) {
		t.Fatal("live Castle rejection not recognized")
	}
	if isBrowserVerificationRequired([]byte(`{"error":"access_denied"}`)) {
		t.Fatal("ordinary 403 misclassified as browser verification")
	}
}
