package egress

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptrace"
	"net/netip"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	application "github.com/chenyme/grok2api/backend/internal/application/egress"
	accountdomain "github.com/chenyme/grok2api/backend/internal/domain/account"
	domain "github.com/chenyme/grok2api/backend/internal/domain/egress"
	settingsdomain "github.com/chenyme/grok2api/backend/internal/domain/settings"
	"github.com/chenyme/grok2api/backend/internal/infra/security"
	neterrorpkg "github.com/chenyme/grok2api/backend/internal/pkg/neterror"
	"github.com/chenyme/grok2api/backend/internal/repository"
	"golang.org/x/sync/singleflight"
)

const DefaultUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"
const nodeSnapshotTTL = time.Second
const operationsConfigSnapshotTTL = time.Second
const proxyPoolRetryLimit = 2
const clientCacheIdleTTL = 30 * time.Minute
const clientCacheCleanupInterval = time.Minute
const clientCacheTouchInterval = time.Minute
const maxCachedClients = 4096
const clearanceLockGrace = 30 * time.Second
const clearanceCacheCleanupInterval = time.Minute
const clearanceCacheMinIdleTTL = 30 * time.Minute
const maxCachedClearances = 16384
const clearanceCacheEvictionBatch = 256

// clientClosedRequestStatus is the conventional proxy status for a client-aborted request.
const clientClosedRequestStatus = 499
const egressIPv4ProbeEndpoint = "https://ipinfo.io/json"
const egressIPv6ProbeEndpoint = "https://v6.ipinfo.io/json"
const cloudflareIPv4ProbeEndpoint = "https://1.1.1.1/cdn-cgi/trace"
const cloudflareIPv6ProbeEndpoint = "https://[2606:4700:4700::1111]/cdn-cgi/trace"
const egressProbeTimeout = 15 * time.Second
const failureProbeCompletionGrace = 5 * time.Second
const failureProbeTimeout = 20 * time.Second
const failureProbeWaitTimeout = 5 * time.Second
const clientCreationRetryLimit = 3
const maxClientVersionEntries = 4096

var errNodeSnapshotInvalidated = errors.New("egress node snapshot invalidated")
var errClientCacheInvalidated = errors.New("egress client cache invalidated")
var errAccountConnectionIsolationDisabled = errors.New("egress account connection isolation disabled")

type Lease struct {
	NodeID           uint64
	NodeName         string
	Scope            domain.Scope
	ProxyURL         string
	UserAgent        string
	CFCookies        string
	client           requestClient
	browser          *browserClient
	sticky           bool
	proxyPool        bool
	freshTunnel      bool
	clearanceKey     string
	clearanceManager *Manager
	release          func()
}

type requestClient interface {
	Do(*http.Request) (*http.Response, error)
	CloseIdleConnections()
}

type FailureProber func(context.Context, uint64) (domain.ProbeResult, error)

type failureProbeState struct {
	running       bool
	lastCompleted time.Time
	done          chan struct{}
}

func (l *Lease) Do(request *http.Request) (*http.Response, error) {
	return l.doRequest(request, true)
}

// DoDeferredForbidden executes an HTTP request while leaving 403 clearance
// invalidation to the caller after it has classified the response body.
func (l *Lease) DoDeferredForbidden(request *http.Request) (*http.Response, error) {
	return l.doRequest(request, false)
}

func (l *Lease) doRequest(request *http.Request, invalidateForbidden bool) (*http.Response, error) {
	if l == nil || l.client == nil {
		return nil, errors.New("出口客户端未初始化")
	}
	// Rotating proxy endpoints choose an exit when a new CONNECT tunnel is
	// established. Reusing a Build keep-alive/HTTP2 connection would pin many
	// otherwise independent requests to one exit and defeat proxy-pool
	// rotation. Proxy-pool mode is explicit, so trade the extra handshake for a
	// fresh tunnel without changing fixed-proxy, direct, Web, or Console paths.
	if l.Scope == domain.ScopeBuild && l.freshTunnel {
		request.Close = true
	}
	response, err := l.do(request)
	recordPhysicalCall(request.Context(), response, err)
	if invalidateForbidden && err == nil && response != nil && response.StatusCode == http.StatusForbidden {
		l.InvalidateClearance()
	}
	return response, err
}

// InvalidateClearance invalidates the exact browser-session binding used by
// this lease after a 403 has been classified as egress-related.
func (l *Lease) InvalidateClearance() {
	if l != nil && l.clearanceManager != nil && l.clearanceKey != "" {
		l.clearanceManager.invalidateClearanceKey(l.clearanceKey, l.client)
	}
}

func (l *Lease) Release() {
	if l != nil && l.release != nil {
		l.release()
		l.release = nil
	}
}

type Manager struct {
	repository             repository.EgressRepository
	cipher                 *security.Cipher
	logger                 *slog.Logger
	nodeMu                 sync.RWMutex
	clientMu               sync.RWMutex
	clearanceMu            sync.Mutex
	operationsMu           sync.RWMutex
	clients                map[clientCacheKey]cachedClient
	inflight               sync.Map
	nodes                  map[domain.Scope]cachedNodeSnapshot
	healthyNodes           map[uint64]time.Time
	nodeVersions           map[domain.Scope]uint64
	nodeLoads              singleflight.Group
	clientLoads            singleflight.Group
	clientVersions         map[uint64]uint64
	clientGeneration       uint64
	buildHeaderTimeout     atomic.Int64
	buildStreamIdleTimeout atomic.Int64
	accountIsolated        atomic.Bool
	operationsConfig       cachedOperationsConfig
	operationsConfigLoad   singleflight.Group
	operationsConfigVer    uint64
	failureProbeMu         sync.Mutex
	failureProber          FailureProber
	failureProbes          map[uint64]failureProbeState
	lastClientCleanup      time.Time
	clearanceLoads         singleflight.Group
	clearanceConfig        ClearanceConfig
	clearanceVersion       uint64
	clearances             map[string]clearanceState
	lastClearanceCleanup   time.Time
	solver                 clearanceSolver
	clearanceLock          repository.DistributedLock
	newBuildClient         func(string, time.Duration) (requestClient, error)
	newBuildEnvClient      func(time.Duration) (requestClient, error)
	newBrowserClient       func(string, string) (*browserClient, error)
}

type clearanceState struct {
	cookies            string
	userAgent          string
	refreshedAt        time.Time
	invalid            bool
	used               bool
	version            uint64
	fingerprint        string
	bindingFingerprint string
	lastUsedAt         time.Time
}

type egressStateRepository interface {
	UpdateEgressNodeClearance(context.Context, uint64, string, string, string, string, time.Time) error
	UpdateEgressNodeHealth(context.Context, uint64, float64, int, *time.Time, string) error
	UpdateEgressNodeLastError(context.Context, uint64, string) error
}

// operationsConfigRepository is optional so lightweight routing repositories
// retain their narrow contract. The relational implementation supplies it,
// allowing fallback policy to be read only when primary selection fails.
type operationsConfigRepository interface {
	GetEgressOperationsConfig(context.Context) (domain.OperationsConfig, error)
}

type cachedClient struct {
	client   requestClient
	browser  *browserClient
	lastUsed time.Time
}

type clientCacheKey struct {
	nodeID          uint64
	scope           domain.Scope
	fingerprint     string
	accountIdentity string
}

type cachedNodeSnapshot struct {
	values    []domain.Node
	expiresAt time.Time
}

type cachedOperationsConfig struct {
	value     domain.OperationsConfig
	expiresAt time.Time
}

func NewManager(repository repository.EgressRepository, cipher *security.Cipher) *Manager {
	manager := &Manager{
		repository: repository, cipher: cipher,
		clients: make(map[clientCacheKey]cachedClient),
		nodes:   make(map[domain.Scope]cachedNodeSnapshot), healthyNodes: make(map[uint64]time.Time),
		nodeVersions: make(map[domain.Scope]uint64), clientVersions: make(map[uint64]uint64), clearances: make(map[string]clearanceState),
		failureProbes:  make(map[uint64]failureProbeState),
		newBuildClient: newBuildRequestClient, newBuildEnvClient: newBuildEnvironmentRequestClient, newBrowserClient: newBrowserClient,
		solver:          flaresolverrSolver{},
		clearanceConfig: ClearanceConfig{Mode: "manual", TargetURL: "https://grok.com", Timeout: time.Minute, RefreshInterval: 10 * time.Minute},
	}
	manager.buildHeaderTimeout.Store(int64(settingsdomain.DefaultBuildResponseHeaderTimeout))
	manager.buildStreamIdleTimeout.Store(int64(settingsdomain.DefaultBuildStreamIdleTimeout))
	return manager
}

func (m *Manager) SetLogger(logger *slog.Logger) {
	if logger == nil {
		logger = slog.Default()
	}
	m.logger = logger
}

func (m *Manager) log() *slog.Logger {
	if m == nil || m.logger == nil {
		return slog.Default()
	}
	return m.logger
}

// SetFailureProber enables an immediate, deduplicated connectivity probe after
// a fixed proxy reports a transport failure. The callback persists the probe
// result; it must not depend on the failed request context.
func (m *Manager) SetFailureProber(value FailureProber) {
	m.failureProbeMu.Lock()
	m.failureProber = value
	if value == nil {
		clear(m.failureProbes)
	}
	m.failureProbeMu.Unlock()
}

func (m *Manager) scheduleFailureProbe(node domain.Node) {
	m.failureProbeMu.Lock()
	prober := m.failureProber
	state := m.failureProbes[node.ID]
	if prober == nil || state.running {
		m.failureProbeMu.Unlock()
		return
	}
	state.running = true
	state.done = make(chan struct{})
	m.failureProbes[node.ID] = state
	done := state.done
	m.failureProbeMu.Unlock()

	m.log().Info("egress_failure_probe_scheduled", "node_id", node.ID, "node_name", node.Name, "scope", node.Scope)
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), failureProbeTimeout)
		result, err := prober(ctx, node.ID)
		cancel()

		m.failureProbeMu.Lock()
		state := m.failureProbes[node.ID]
		if state.done == done {
			state.running = false
			state.lastCompleted = time.Now().UTC()
			m.failureProbes[node.ID] = state
		}
		close(done)
		m.failureProbeMu.Unlock()

		if err != nil {
			m.log().Warn("egress_failure_probe_failed", "node_id", node.ID, "node_name", node.Name, "scope", node.Scope, "error", err)
			return
		}
		if result.Status == domain.ProbeStatusHealthy {
			m.invalidateNodes(node.Scope)
		}
		m.log().Info("egress_failure_probe_completed", "node_id", node.ID, "node_name", node.Name, "scope", node.Scope, "probe_status", result.Status, "latency_ms", result.LatencyMS)
	}()
}

func (m *Manager) waitForFailureProbe(ctx context.Context, nodeID uint64) (bool, error) {
	now := time.Now().UTC()
	m.failureProbeMu.Lock()
	state, exists := m.failureProbes[nodeID]
	m.failureProbeMu.Unlock()
	if !exists {
		return false, nil
	}
	if !state.running {
		return !state.lastCompleted.IsZero() && now.Sub(state.lastCompleted) < failureProbeCompletionGrace, nil
	}
	if state.done == nil {
		return false, nil
	}
	timer := time.NewTimer(failureProbeWaitTimeout)
	defer timer.Stop()
	select {
	case <-state.done:
		return true, nil
	case <-ctx.Done():
		return false, ctx.Err()
	case <-timer.C:
		return false, nil
	}
}

// UpdateBuildResponseHeaderTimeout rebuilds only cached Build clients. Active
// requests keep their current transport and are not interrupted.
func (m *Manager) UpdateBuildResponseHeaderTimeout(value time.Duration) {
	if value <= 0 {
		value = settingsdomain.DefaultBuildResponseHeaderTimeout
	}
	if previous := time.Duration(m.buildHeaderTimeout.Swap(int64(value))); previous == value {
		return
	}
	m.clientMu.Lock()
	var stale []requestClient
	for key, cached := range m.clients {
		if key.scope == domain.ScopeBuild {
			stale = append(stale, m.evictClientLocked(key, cached))
		}
	}
	m.clientMu.Unlock()
	closeRequestClients(stale)
}

// UpdateBuildStreamIdleTimeout affects subsequent Build streams. Active
// response bodies retain the deadline captured by their existing wrapper and
// are not interrupted; the underlying HTTP connection pool is unchanged.
func (m *Manager) UpdateBuildStreamIdleTimeout(value time.Duration) {
	if value <= 0 {
		value = settingsdomain.DefaultBuildStreamIdleTimeout
	}
	m.buildStreamIdleTimeout.Store(int64(value))
}

// BuildStreamIdleTimeout returns the configured stream idle deadline for Grok
// Build responses. Returns zero when idle enforcement is disabled.
func (m *Manager) BuildStreamIdleTimeout() time.Duration {
	return time.Duration(m.buildStreamIdleTimeout.Load())
}

// UpdateAccountIsolatedConnections toggles per-account upstream connection pools.
// When enabled, different accounts do not share TCP/HTTP clients so upstream
// egress load balancers can spread traffic by connection; the same account still
// reuses its own pool. Changing the setting rebuilds cached clients without
// interrupting in-flight requests.
func (m *Manager) UpdateAccountIsolatedConnections(enabled bool) {
	m.clientMu.Lock()
	if m.accountIsolated.Load() == enabled {
		m.clientMu.Unlock()
		return
	}
	// Change the mode while holding the same lock used to validate client-cache
	// keys. This makes the mode snapshot and cache invalidation one transition.
	m.accountIsolated.Store(enabled)
	stale := make([]requestClient, 0, len(m.clients))
	for key, cached := range m.clients {
		stale = append(stale, m.evictClientLocked(key, cached))
	}
	m.invalidateAllClientVersionsLocked()
	m.clientMu.Unlock()
	closeRequestClients(stale)
	m.log().Info("egress_account_connection_isolation_updated", "enabled", enabled, "evicted_clients", len(stale))
}

// AccountIsolatedConnections reports whether upstream clients are partitioned by account.
func (m *Manager) AccountIsolatedConnections() bool {
	return m != nil && m.accountIsolated.Load()
}

func isolationAccountIdentity(ctx context.Context, scope domain.Scope, affinity string) string {
	identity := accountFromContext(ctx)
	if identity != "" {
		return identity
	}
	affinity = strings.TrimSpace(affinity)
	if affinity != "" {
		return string(scope) + "_" + affinity
	}
	return "shared"
}

// SetClearanceLock enables cross-instance coordination for shared, fixed egress
// nodes. Account-bound Resin clearances remain process-local because they must
// never be persisted into the node-wide cookie fields.
func (m *Manager) SetClearanceLock(value repository.DistributedLock) {
	m.clearanceMu.Lock()
	m.clearanceLock = value
	m.clearanceMu.Unlock()
}

func (m *Manager) UpdateClearanceConfig(value ClearanceConfig) {
	value.Mode = strings.TrimSpace(value.Mode)
	value.FlareSolverrURL = strings.TrimSpace(value.FlareSolverrURL)
	value.TargetURL = strings.TrimRight(strings.TrimSpace(value.TargetURL), "/")
	m.clearanceMu.Lock()
	previous := m.clearanceConfig
	m.clearanceConfig = value
	configurationChanged := previous.Mode != value.Mode || previous.FlareSolverrURL != value.FlareSolverrURL || previous.TargetURL != value.TargetURL
	if configurationChanged {
		m.clearanceVersion++
		m.clientMu.Lock()
		m.invalidateAllClientVersionsLocked()
		m.clientMu.Unlock()
	}
	m.clearanceMu.Unlock()
}

func (m *Manager) Acquire(ctx context.Context, scope domain.Scope, affinity string) (*Lease, error) {
	lease, _, err := m.acquire(ctx, scope, affinity, true, "", egressNodeFromContext(ctx))
	return lease, err
}

// AcquireBuildEnvironmentDirectIfIsolated creates an account-partitioned direct
// Build lease while preserving the legacy direct transport's environment-proxy
// semantics. The bool is false when isolation was disabled before the lease was
// acquired, allowing the caller to retain its original fallback transport.
func (m *Manager) AcquireBuildEnvironmentDirectIfIsolated(ctx context.Context, affinity string) (*Lease, bool, error) {
	selected := domain.Node{ID: 0, Name: "direct", Scope: domain.ScopeBuild, Enabled: true, Health: 1}
	lease, _, err := m.leaseForNodeWithOptions(ctx, domain.ScopeBuild, affinity, "", false, selected, clientOptions{
		buildEnvironmentProxy:   true,
		requireAccountIsolation: true,
	})
	if errors.Is(err, errAccountConnectionIsolationDisabled) {
		return nil, false, nil
	}
	return lease, err == nil, err
}

// AcquireCredential binds the outbound proxy identity to one persisted
// Provider credential. Resin templates use this identity as their Account.
func (m *Manager) AcquireCredential(ctx context.Context, scope domain.Scope, credential accountdomain.Credential) (*Lease, error) {
	identity := strings.TrimSpace(credential.EgressIdentity)
	if identity == "" {
		identity = string(credential.Provider) + "_" + strconv.FormatUint(credential.ID, 10)
	}
	// Web and Console accounts can be two database projections of the same SSO
	// login. Resin must see one stable account identity across both channels;
	// otherwise the proxy rotates the IP while the clearance remains bound to
	// the other lease. The digest is non-reversible and is only used as a proxy
	// template account label.
	if strings.TrimSpace(credential.EgressIdentity) == "" && credential.AuthType == accountdomain.AuthTypeSSO && strings.TrimSpace(credential.EncryptedAccessToken) != "" {
		token, decryptErr := m.cipher.Decrypt(credential.EncryptedAccessToken)
		if decryptErr != nil {
			return nil, decryptErr
		}
		identity = "sso_" + security.HashToken(token)[:32]
	}
	ctx = WithAccountIdentity(ctx, identity)
	ctx = WithEgressNode(ctx, credential.EgressNodeID)
	lease, _, err := m.acquire(ctx, scope, strconv.FormatUint(credential.ID, 10), true, credential.EncryptedCloudflareCookie, credential.EgressNodeID)
	return lease, err
}

func (m *Manager) AcquireIfConfigured(ctx context.Context, scope domain.Scope, affinity string) (*Lease, bool, error) {
	return m.acquire(ctx, scope, affinity, false, "", egressNodeFromContext(ctx))
}

type preparedEgressProbe struct {
	nodeID    uint64
	nodeName  string
	nodeScope domain.Scope
	proxyURL  string
}

// ProbeEgressNode verifies IPv4 and IPv6 independently through fixed provider
// endpoints. Both requests share one immutable node snapshot so a concurrent
// administrator edit cannot mix results from different proxy configurations.
func (m *Manager) ProbeEgressNode(ctx context.Context, node domain.Node) (domain.ProbeResult, error) {
	type outcome struct {
		family string
		result domain.ProbeFamilyResult
		err    error
	}
	startedAt := time.Now().UTC()
	var provider domain.ProbeProvider
	config, supported, configErr := m.loadOperationsConfig(ctx, time.Now().UTC())
	if configErr != nil {
		message := "读取代理探测服务配置失败"
		result := failedEgressProbeResult(provider, message, startedAt)
		m.logProbeSetupFailure(ctx, node, provider, "load_probe_config", message, configErr, result.LatencyMS)
		return result, configErr
	}
	if supported {
		provider = config.ProbeProvider.Normalized()
	} else {
		provider = domain.ProbeProviderCloudflare
	}
	target, stage, message, prepareErr := m.prepareEgressProbe(node)
	if prepareErr != nil {
		result := failedEgressProbeResult(provider, message, startedAt)
		m.logProbeSetupFailure(ctx, node, provider, stage, message, prepareErr, result.LatencyMS)
		return result, prepareErr
	}
	ipv4Endpoint, ipv6Endpoint := probeEndpoints(provider)
	outcomes := make(chan outcome, 2)
	for _, probe := range []struct{ family, endpoint string }{{"ipv4", ipv4Endpoint}, {"ipv6", ipv6Endpoint}} {
		go func() {
			result, err := m.probeEgressEndpoint(ctx, target, provider, probe.family, probe.endpoint)
			outcomes <- outcome{family: probe.family, result: result, err: err}
		}()
	}
	var ipv4Err, ipv6Err error
	result := domain.ProbeResult{Status: domain.ProbeStatusUnhealthy, Provider: provider}
	for range 2 {
		current := <-outcomes
		if current.family == "ipv4" {
			result.IPv4, ipv4Err = current.result, current.err
		} else {
			result.IPv6, ipv6Err = current.result, current.err
		}
	}
	result.TestedAt = time.Now().UTC()
	result.LatencyMS = max(result.IPv4.LatencyMS, result.IPv6.LatencyMS)
	if result.IPv4.Status == domain.ProbeStatusHealthy {
		result.Status, result.ExitIP = domain.ProbeStatusHealthy, result.IPv4.ExitIP
	} else if result.IPv6.Status == domain.ProbeStatusHealthy {
		result.Status, result.ExitIP = domain.ProbeStatusHealthy, result.IPv6.ExitIP
	}
	if result.Status == domain.ProbeStatusHealthy {
		return result, nil
	}
	errorsByFamily := make([]string, 0, 2)
	if result.IPv4.Error != "" {
		errorsByFamily = append(errorsByFamily, "IPv4: "+result.IPv4.Error)
	}
	if result.IPv6.Error != "" {
		errorsByFamily = append(errorsByFamily, "IPv6: "+result.IPv6.Error)
	}
	result.Error = strings.Join(errorsByFamily, "; ")
	if result.Error == "" {
		result.Error = "IPv4 和 IPv6 代理探测均失败"
	}
	return result, errors.Join(ipv4Err, ipv6Err, errors.New(result.Error))
}

func (m *Manager) prepareEgressProbe(node domain.Node) (preparedEgressProbe, string, string, error) {
	target := preparedEgressProbe{nodeID: node.ID, nodeName: node.Name, nodeScope: node.Scope}
	if node.ID == 0 {
		message := "代理节点 ID 无效"
		return target, "validate_node", message, errors.New(message)
	}
	proxyURL, err := m.cipher.Decrypt(node.EncryptedProxyURL)
	if err != nil {
		return target, "decrypt_proxy", "读取代理配置失败", err
	}
	proxyURL, err = application.NormalizeProxyURL(proxyURL)
	if err != nil {
		return target, "normalize_proxy", "代理地址无效", err
	}
	if proxyURL == "" {
		message := "未配置代理地址"
		return target, "normalize_proxy", message, errors.New(message)
	}
	if strings.Contains(proxyURL, application.ProxyAccountPlaceholder) {
		proxyURL, err = renderAccountProxyURL(proxyURL, "egress_probe")
		if err != nil {
			return target, "render_proxy_identity", "账号代理模板无效", err
		}
	}
	target.proxyURL = proxyURL
	return target, "", "", nil
}

func failedEgressProbeResult(provider domain.ProbeProvider, message string, startedAt time.Time) domain.ProbeResult {
	completedAt := time.Now().UTC()
	latencyMS := max(1, int(completedAt.Sub(startedAt).Milliseconds()))
	family := domain.ProbeFamilyResult{
		Status: domain.ProbeStatusUnhealthy, TestedAt: completedAt, LatencyMS: latencyMS, Error: message,
	}
	return domain.ProbeResult{
		Status: domain.ProbeStatusUnhealthy, TestedAt: completedAt, LatencyMS: latencyMS, Error: message,
		Provider: provider, IPv4: family, IPv6: family,
	}
}

func (m *Manager) logProbeSetupFailure(ctx context.Context, node domain.Node, provider domain.ProbeProvider, stage, message string, err error, durationMS int) {
	attributes := []any{
		"node_id", node.ID, "node_name", node.Name, "scope", node.Scope,
		"probe_provider", provider, "address_family", "all", "endpoint", "",
		"stage", stage, "status_code", 0, "duration_ms", durationMS,
		"connect_ms", 0, "tls_ms", 0, "first_byte_ms", 0,
		"probe_error", message,
	}
	if err != nil {
		attributes = append(attributes, "error", sanitizeFlareSolverrMessage(err.Error()))
	}
	m.log().WarnContext(ctx, "egress_probe_failed", attributes...)
}

func probeEndpoints(provider domain.ProbeProvider) (string, string) {
	if provider.Normalized() == domain.ProbeProviderCloudflare {
		return cloudflareIPv4ProbeEndpoint, cloudflareIPv6ProbeEndpoint
	}
	return egressIPv4ProbeEndpoint, egressIPv6ProbeEndpoint
}

func (m *Manager) probeEgressEndpoint(ctx context.Context, target preparedEgressProbe, provider domain.ProbeProvider, family, targetURL string) (result domain.ProbeFamilyResult, probeErr error) {
	startedAt := time.Now().UTC()
	result = domain.ProbeFamilyResult{Status: domain.ProbeStatusUnhealthy, TestedAt: startedAt}
	stage := "create_client"
	statusCode := 0
	var traceMu sync.Mutex
	var connectStartedAt, tlsStartedAt time.Time
	connectDone, connectFailed := false, false
	tlsDone, tlsFailed := false, false
	gotFirstByte := false
	connectMS, tlsMS, firstByteMS := 0, 0, 0
	defer func() {
		completedAt := time.Now().UTC()
		durationMS := max(1, int(completedAt.Sub(startedAt).Milliseconds()))
		result.TestedAt = completedAt
		if result.LatencyMS == 0 {
			result.LatencyMS = durationMS
		}
		traceMu.Lock()
		if !connectStartedAt.IsZero() && connectMS == 0 {
			connectMS = max(1, int(time.Since(connectStartedAt).Milliseconds()))
		}
		if !tlsStartedAt.IsZero() && tlsMS == 0 {
			tlsMS = max(1, int(time.Since(tlsStartedAt).Milliseconds()))
		}
		if stage == "first_byte" && firstByteMS == 0 {
			firstByteMS = durationMS
		}
		connectDurationMS, tlsDurationMS, firstByteDurationMS := connectMS, tlsMS, firstByteMS
		traceMu.Unlock()
		attributes := []any{
			"node_id", target.nodeID,
			"node_name", target.nodeName,
			"scope", target.nodeScope,
			"probe_provider", provider,
			"address_family", family,
			"endpoint", targetURL,
			"stage", stage,
			"status_code", statusCode,
			"duration_ms", durationMS,
			"connect_ms", connectDurationMS,
			"tls_ms", tlsDurationMS,
			"first_byte_ms", firstByteDurationMS,
		}
		if probeErr != nil || result.Status != domain.ProbeStatusHealthy {
			attributes = append(attributes, "probe_error", result.Error)
			if probeErr != nil {
				attributes = append(attributes, "error", sanitizeFlareSolverrMessage(probeErr.Error()))
			}
			m.log().WarnContext(ctx, "egress_probe_failed", attributes...)
			return
		}
		attributes = append(attributes, "latency_ms", result.LatencyMS, "exit_ip", result.ExitIP)
		m.log().InfoContext(ctx, "egress_probe_succeeded", attributes...)
	}()
	clientFactory := m.newBuildClient
	if clientFactory == nil {
		clientFactory = newBuildRequestClient
	}
	client, err := clientFactory(target.proxyURL, egressProbeTimeout)
	if err != nil {
		result.Error = "创建代理连接失败"
		return result, err
	}
	defer client.CloseIdleConnections()
	probeCtx, cancel := context.WithTimeout(ctx, egressProbeTimeout)
	defer cancel()
	probeCtx = httptrace.WithClientTrace(probeCtx, &httptrace.ClientTrace{
		ConnectStart: func(_, _ string) {
			traceMu.Lock()
			if connectStartedAt.IsZero() {
				connectStartedAt = time.Now()
			}
			traceMu.Unlock()
		},
		ConnectDone: func(_, _ string, traceErr error) {
			traceMu.Lock()
			connectDone = true
			connectFailed = traceErr != nil
			if !connectStartedAt.IsZero() && connectMS == 0 {
				connectMS = max(1, int(time.Since(connectStartedAt).Milliseconds()))
			}
			traceMu.Unlock()
		},
		TLSHandshakeStart: func() {
			traceMu.Lock()
			if tlsStartedAt.IsZero() {
				tlsStartedAt = time.Now()
			}
			traceMu.Unlock()
		},
		TLSHandshakeDone: func(_ tls.ConnectionState, traceErr error) {
			traceMu.Lock()
			tlsDone = true
			tlsFailed = traceErr != nil
			if !tlsStartedAt.IsZero() && tlsMS == 0 {
				tlsMS = max(1, int(time.Since(tlsStartedAt).Milliseconds()))
			}
			traceMu.Unlock()
		},
		GotFirstResponseByte: func() {
			traceMu.Lock()
			gotFirstByte = true
			if firstByteMS == 0 {
				firstByteMS = max(1, int(time.Since(startedAt).Milliseconds()))
			}
			traceMu.Unlock()
		},
	})
	stage = "build_request"
	request, err := http.NewRequestWithContext(probeCtx, http.MethodGet, targetURL, nil)
	if err != nil {
		result.Error = "构造探测请求失败"
		return result, err
	}
	request.Header.Set("User-Agent", DefaultUserAgent)
	stage = "execute_request"
	response, err := client.Do(request)
	if err != nil {
		traceMu.Lock()
		switch {
		case !connectStartedAt.IsZero() && (!connectDone || connectFailed):
			stage = "connect"
		case !tlsStartedAt.IsZero() && (!tlsDone || tlsFailed):
			stage = "tls"
		case (connectDone || tlsDone) && !gotFirstByte:
			stage = "first_byte"
		default:
			stage = "execute_request"
		}
		traceMu.Unlock()
		result.Error = "代理连接失败"
		return result, err
	}
	statusCode = response.StatusCode
	defer response.Body.Close()
	stage = "read_response"
	body, readErr := io.ReadAll(io.LimitReader(response.Body, 64<<10))
	if readErr != nil {
		result.Error = "读取探测响应失败"
		return result, readErr
	}
	stage = "validate_status"
	if response.StatusCode < http.StatusOK || response.StatusCode >= http.StatusMultipleChoices {
		result.Error = fmt.Sprintf("探测服务返回 HTTP %d", response.StatusCode)
		return result, errors.New(result.Error)
	}
	stage = "decode_response"
	exitIP, err := decodeProbeIP(body)
	if err != nil {
		result.Error = "探测服务响应格式无效"
		return result, err
	}
	stage = "validate_exit_ip"
	address, err := netip.ParseAddr(exitIP)
	if err != nil || (family == "ipv4" && !address.Is4()) || (family == "ipv6" && !address.Is6()) {
		result.Error = fmt.Sprintf("探测服务未返回有效 %s 出口 IP", strings.ToUpper(family))
		if err == nil {
			err = errors.New(result.Error)
		}
		return result, err
	}
	result.Status = domain.ProbeStatusHealthy
	result.LatencyMS = max(1, int(time.Since(startedAt).Milliseconds()))
	result.ExitIP = address.String()
	result.Error = ""
	stage = "complete"
	return result, nil
}

func decodeProbeIP(body []byte) (string, error) {
	var payload struct {
		IP string `json:"ip"`
	}
	if json.Unmarshal(body, &payload) == nil && strings.TrimSpace(payload.IP) != "" {
		return strings.TrimSpace(payload.IP), nil
	}
	for line := range strings.SplitSeq(string(body), "\n") {
		key, value, found := strings.Cut(strings.TrimSpace(line), "=")
		if found && key == "ip" && strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value), nil
		}
	}
	return "", errors.New("probe response does not contain an IP address")
}

func (m *Manager) acquire(ctx context.Context, scope domain.Scope, affinity string, allowDirect bool, encryptedCredentialCookies string, boundNodeID uint64) (*Lease, bool, error) {
	now := time.Now().UTC()
	clearanceMode := m.clearanceMode()
	managedClearance := isGrokWebScope(scope) && (clearanceMode == "flaresolverr" || clearanceMode == "on_demand")
	configured := false
	var available []domain.Node
	if boundNodeID != 0 {
		waitedForProbe := false
		qualityProbe := qualityProbeFromContext(ctx)
		for {
			now = time.Now().UTC()
			selected, err := m.repository.GetEgressNode(ctx, boundNodeID)
			if err != nil {
				primaryErr := fmt.Errorf("读取绑定出口节点: %w", err)
				if !errors.Is(err, repository.ErrNotFound) {
					return nil, true, primaryErr
				}
				return m.acquireUnavailableFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, primaryErr)
			}
			if !domain.SupportsScope(selected.Scope, scope) {
				return m.acquireUnavailableFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, fmt.Errorf("绑定出口节点 %d 与 %s 作用域不兼容", boundNodeID, scope))
			}
			if !selected.Enabled && !qualityProbe {
				return m.acquireUnavailableFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, fmt.Errorf("绑定出口节点 %d 已禁用", boundNodeID))
			}
			if strings.TrimSpace(selected.EncryptedProxyURL) == "" {
				return m.acquireUnavailableFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, fmt.Errorf("绑定出口节点 %d 未配置代理地址", boundNodeID))
			}
			proxyPool := m.isProxyPoolNode(selected)
			if !qualityProbe && !proxyPool && selected.CooldownUntil != nil && now.Before(*selected.CooldownUntil) {
				if !waitedForProbe && selected.LastError == domain.LastErrorTransport {
					completed, waitErr := m.waitForFailureProbe(ctx, boundNodeID)
					if waitErr != nil {
						return nil, true, waitErr
					}
					if completed {
						waitedForProbe = true
						continue
					}
				}
				return m.acquireUnavailableFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, fmt.Errorf("绑定出口节点 %d 正在冷却", boundNodeID))
			}
			return m.leaseForNode(ctx, scope, affinity, encryptedCredentialCookies, managedClearance, selected)
		}
	}
	fallbackConfig, fallbackSupported, fallbackConfigErr := m.loadOperationsConfig(ctx, now)
	fallback := domain.FallbackConfig{Mode: domain.FallbackModeNone}
	reservedFallbackNodes := make(map[uint64]struct{}, len(allEgressScopes()))
	if fallbackConfigErr == nil && fallbackSupported {
		fallback = fallbackConfig.FallbackFor(scope)
		for _, fallbackScope := range allEgressScopes() {
			configuredFallback := fallbackConfig.FallbackFor(fallbackScope)
			if configuredFallback.Mode == domain.FallbackModeFixed && configuredFallback.NodeID != 0 {
				reservedFallbackNodes[configuredFallback.NodeID] = struct{}{}
			}
		}
	}
	for _, candidateScope := range fallbackScopes(scope) {
		nodes, err := m.listNodes(ctx, candidateScope, now)
		if err != nil {
			return nil, false, err
		}
		candidateAvailable := make([]domain.Node, 0, len(nodes))
		for _, node := range nodes {
			if !node.Enabled {
				continue
			}
			// A fixed fallback is a reserved last resort, not another member of
			// the primary pool. It is validated again immediately before use.
			if _, reserved := reservedFallbackNodes[node.ID]; reserved {
				continue
			}
			configured = true
			proxyPool := m.isProxyPoolNode(node)
			if node.CooldownUntil == nil || !now.Before(*node.CooldownUntil) || proxyPool {
				if proxyPool {
					node.Health, node.FailureCount, node.CooldownUntil, node.LastError = 1, 0, nil, ""
				}
				candidateAvailable = append(candidateAvailable, node)
			}
		}
		if len(candidateAvailable) > 0 {
			available = candidateAvailable
			break
		}
	}
	if len(available) == 0 {
		primaryErr := error(nil)
		if configured {
			primaryErr = fmt.Errorf("当前没有可用的 %s 出口节点", scope)
		}
		lease, fallbackConfigured, applied, err := m.applyFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, primaryErr, fallback, fallbackSupported, fallbackConfigErr)
		if err != nil {
			return nil, fallbackConfigured, err
		}
		if applied {
			return lease, fallbackConfigured, nil
		}
		if primaryErr != nil {
			return nil, false, primaryErr
		}
		if !allowDirect {
			recordSelection(ctx, Selection{NodeName: "direct", Scope: scope})
			return nil, false, nil
		}
		available = []domain.Node{{ID: 0, Name: "direct", Scope: scope, Enabled: true, Health: 1}}
	}
	sort.SliceStable(available, func(i, j int) bool { return available[i].ID < available[j].ID })
	selected := m.selectNode(available, affinity)
	return m.leaseForNode(ctx, scope, affinity, encryptedCredentialCookies, managedClearance, selected)
}

// acquireUnavailableFallback keeps the primary selection error when fallback
// is disabled. A fixed fallback is never silently replaced with direct traffic
// when it is invalid or unavailable.
func (m *Manager) acquireUnavailableFallback(ctx context.Context, scope domain.Scope, affinity string, allowDirect bool, encryptedCredentialCookies string, managedClearance bool, primaryErr error) (*Lease, bool, error) {
	lease, configured, applied, err := m.acquireFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, primaryErr)
	if err != nil {
		return nil, configured, err
	}
	if applied {
		return lease, configured, nil
	}
	return nil, true, primaryErr
}

// acquireFallback is called before an upstream request is written. Transport
// failures are intentionally not retried through this path because replaying
// a non-idempotent upstream request on a different IP can duplicate work.
func (m *Manager) acquireFallback(ctx context.Context, scope domain.Scope, affinity string, allowDirect bool, encryptedCredentialCookies string, managedClearance bool, primaryErr error) (*Lease, bool, bool, error) {
	fallback, supported, err := m.fallbackFor(ctx, scope, time.Now().UTC())
	return m.applyFallback(ctx, scope, affinity, allowDirect, encryptedCredentialCookies, managedClearance, primaryErr, fallback, supported, err)
}

func (m *Manager) applyFallback(ctx context.Context, scope domain.Scope, affinity string, allowDirect bool, encryptedCredentialCookies string, managedClearance bool, primaryErr error, fallback domain.FallbackConfig, supported bool, configErr error) (*Lease, bool, bool, error) {
	if configErr != nil {
		return nil, false, false, fallbackError(primaryErr, fmt.Errorf("读取出口回退配置: %w", configErr))
	}
	if !supported {
		return nil, false, false, nil
	}
	switch fallback.Mode {
	case domain.FallbackModeNone:
		return nil, false, false, nil
	case domain.FallbackModeDirect:
		if !allowDirect {
			recordSelection(ctx, Selection{NodeName: "direct", Scope: scope})
			return nil, false, true, nil
		}
		lease, _, err := m.leaseForNode(ctx, scope, affinity, encryptedCredentialCookies, managedClearance, domain.Node{ID: 0, Name: "direct", Scope: scope, Enabled: true, Health: 1})
		if err != nil {
			return nil, false, false, fallbackError(primaryErr, fmt.Errorf("获取本地直连回退: %w", err))
		}
		return lease, false, true, nil
	case domain.FallbackModeFixed:
		selected, err := m.fixedFallbackNode(ctx, scope, fallback.NodeID)
		if err != nil {
			return nil, false, false, fallbackError(primaryErr, err)
		}
		lease, _, err := m.leaseForNode(ctx, scope, affinity, encryptedCredentialCookies, managedClearance, selected)
		if err != nil {
			return nil, false, false, fallbackError(primaryErr, fmt.Errorf("获取固定回退节点 %d: %w", selected.ID, err))
		}
		return lease, true, true, nil
	default:
		return nil, false, false, fallbackError(primaryErr, fmt.Errorf("出口回退模式 %q 无效", fallback.Mode))
	}
}

func (m *Manager) fallbackFor(ctx context.Context, scope domain.Scope, now time.Time) (domain.FallbackConfig, bool, error) {
	config, supported, err := m.loadOperationsConfig(ctx, now)
	if err != nil || !supported {
		return domain.FallbackConfig{Mode: domain.FallbackModeNone}, supported, err
	}
	return config.FallbackFor(scope), true, nil
}

func (m *Manager) loadOperationsConfig(ctx context.Context, now time.Time) (domain.OperationsConfig, bool, error) {
	configRepository, ok := m.repository.(operationsConfigRepository)
	if !ok {
		return domain.OperationsConfig{}, false, nil
	}
	m.operationsMu.RLock()
	cached := m.operationsConfig
	m.operationsMu.RUnlock()
	if !cached.expiresAt.IsZero() && now.Before(cached.expiresAt) {
		return cached.value, true, nil
	}
	loaded, err, _ := m.operationsConfigLoad.Do("operations", func() (any, error) {
		checkTime := time.Now().UTC()
		m.operationsMu.RLock()
		cached := m.operationsConfig
		m.operationsMu.RUnlock()
		if !cached.expiresAt.IsZero() && checkTime.Before(cached.expiresAt) {
			return cached.value, nil
		}
		m.operationsMu.RLock()
		version := m.operationsConfigVer
		m.operationsMu.RUnlock()
		value, err := configRepository.GetEgressOperationsConfig(ctx)
		if err != nil {
			return domain.OperationsConfig{}, err
		}
		m.operationsMu.Lock()
		if version == m.operationsConfigVer {
			m.operationsConfig = cachedOperationsConfig{value: value, expiresAt: checkTime.Add(operationsConfigSnapshotTTL)}
		}
		m.operationsMu.Unlock()
		return value, nil
	})
	if err != nil {
		return domain.OperationsConfig{}, true, err
	}
	return loaded.(domain.OperationsConfig), true, nil
}

func (m *Manager) fixedFallbackNode(ctx context.Context, scope domain.Scope, nodeID uint64) (domain.Node, error) {
	if nodeID == 0 {
		return domain.Node{}, errors.New("固定回退节点未指定")
	}
	selected, err := m.repository.GetEgressNode(ctx, nodeID)
	if err != nil {
		return domain.Node{}, fmt.Errorf("读取固定回退节点 %d: %w", nodeID, err)
	}
	if !domain.SupportsScope(selected.Scope, scope) {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 与 %s 作用域不兼容", nodeID, scope)
	}
	if !selected.Enabled {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 已禁用", nodeID)
	}
	if selected.ProxyPool {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 使用代理池模式", nodeID)
	}
	if strings.TrimSpace(selected.EncryptedProxyURL) == "" {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 未配置代理地址", nodeID)
	}
	if selected.CooldownUntil != nil && time.Now().UTC().Before(*selected.CooldownUntil) {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 正在冷却", nodeID)
	}
	proxyURL, err := m.cipher.Decrypt(selected.EncryptedProxyURL)
	if err != nil {
		return domain.Node{}, fmt.Errorf("读取固定回退节点 %d 代理配置: %w", nodeID, err)
	}
	proxyURL, err = application.NormalizeProxyURL(proxyURL)
	if err != nil || proxyURL == "" {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 代理地址无效", nodeID)
	}
	if strings.Contains(proxyURL, application.ProxyAccountPlaceholder) {
		return domain.Node{}, fmt.Errorf("固定回退节点 %d 使用账号代理模板", nodeID)
	}
	return selected, nil
}

func fallbackError(primaryErr, fallbackErr error) error {
	if primaryErr == nil {
		return fallbackErr
	}
	return fmt.Errorf("%w；出口回退不可用: %v", primaryErr, fallbackErr)
}

type clientOptions struct {
	buildEnvironmentProxy   bool
	requireAccountIsolation bool
}

func (m *Manager) leaseForNode(ctx context.Context, scope domain.Scope, affinity, encryptedCredentialCookies string, managedClearance bool, selected domain.Node) (*Lease, bool, error) {
	return m.leaseForNodeWithOptions(ctx, scope, affinity, encryptedCredentialCookies, managedClearance, selected, clientOptions{})
}

func (m *Manager) leaseForNodeWithOptions(ctx context.Context, scope domain.Scope, affinity, encryptedCredentialCookies string, managedClearance bool, selected domain.Node, options clientOptions) (*Lease, bool, error) {
	credentialCookies := ""
	if !managedClearance && usesBrowserClearance(scope) && strings.TrimSpace(encryptedCredentialCookies) != "" {
		decryptedCookies, decryptErr := m.cipher.Decrypt(encryptedCredentialCookies)
		if decryptErr != nil {
			return nil, true, decryptErr
		}
		credentialCookies = application.SanitizeCloudflareCookies(decryptedCookies)
	}
	proxyURL, err := m.cipher.Decrypt(selected.EncryptedProxyURL)
	if err != nil {
		return nil, false, err
	}
	proxyURL, err = application.NormalizeProxyURL(proxyURL)
	if err != nil {
		return nil, false, err
	}
	sticky := strings.Contains(proxyURL, application.ProxyAccountPlaceholder)
	proxyPool := selected.ProxyPool || sticky
	freshTunnel := selected.ProxyPool && !sticky
	if sticky {
		accountKey := accountFromContext(ctx)
		if accountKey == "" && strings.TrimSpace(affinity) != "" {
			accountKey = string(scope) + "_" + strings.TrimSpace(affinity)
		}
		proxyURL, err = renderAccountProxyURL(proxyURL, accountKey)
		if err != nil {
			return nil, false, err
		}
	}
	cookies := ""
	if usesBrowserClearance(scope) {
		cookies, err = m.cipher.Decrypt(selected.EncryptedCloudflareCookie)
		if err != nil {
			// Managed mode can recover a damaged persisted cookie by asking the
			// solver for a fresh one. Manual mode must still surface the storage
			// error because it has no safe replacement source.
			if !managedClearance {
				return nil, false, err
			}
			cookies = ""
		}
		cookies = application.SanitizeCloudflareCookies(cookies)
		if credentialCookies != "" {
			cookies = credentialCookies
		}
	}
	userAgent := ""
	if scope != domain.ScopeBuild {
		userAgent = strings.TrimSpace(selected.UserAgent)
	}
	if scope != domain.ScopeBuild && userAgent == "" {
		userAgent = DefaultUserAgent
	}
	clearanceKey := ""
	// Manual mode may prefer account-bound cookies. Managed mode always enters
	// the FlareSolverr lifecycle so stale imported cookies cannot bypass refresh.
	if managedClearance {
		clearanceKey = clearanceCacheKey(selected.ID, proxyURL, sticky)
		cookies, userAgent, err = m.ensureClearance(ctx, selected, proxyURL, cookies, userAgent, clearanceKey, !sticky)
		if err != nil {
			return nil, false, err
		}
	}
	// Derive identity independently of the current toggle. clientFor applies one
	// authoritative toggle snapshot, so enabling isolation between these two
	// stages cannot accidentally place an account request in the shared bucket.
	accountIdentity := ""
	if scope != domain.ScopeConsoleAsset {
		accountIdentity = isolationAccountIdentity(ctx, scope, affinity)
	}
	client, err := m.clientForWithOptions(selected.ID, scope, proxyURL, userAgent, cookies, sticky, accountIdentity, options)
	if err != nil {
		return nil, false, err
	}
	m.incrementInflight(selected.ID)
	recordSelection(ctx, Selection{NodeID: selected.ID, NodeName: selected.Name, Scope: scope, Proxied: proxyURL != ""})
	var once sync.Once
	return &Lease{NodeID: selected.ID, NodeName: selected.Name, Scope: scope, ProxyURL: proxyURL, UserAgent: userAgent, CFCookies: cookies, client: client.client, browser: client.browser, sticky: sticky, proxyPool: proxyPool, freshTunnel: freshTunnel, clearanceKey: clearanceKey, clearanceManager: m, release: func() {
		once.Do(func() {
			m.decrementInflight(selected.ID)
		})
	}}, true, nil
}

// Console assets are served from public media hosts. They still need the
// selected proxy and browser user agent, but forwarding account or node
// clearance cookies would unnecessarily expose credentials to a different
// origin and make an otherwise anonymous download depend on cookie storage.
func usesBrowserClearance(scope domain.Scope) bool {
	return scope != domain.ScopeBuild && scope != domain.ScopeConsoleAsset
}

func (m *Manager) inflightCounter(nodeID uint64) *atomic.Int64 {
	// Counters remain address-stable for the manager lifetime so a concurrent
	// release can never decrement a replacement counter after an ABA deletion.
	if value, ok := m.inflight.Load(nodeID); ok {
		return value.(*atomic.Int64)
	}
	candidate := &atomic.Int64{}
	actual, _ := m.inflight.LoadOrStore(nodeID, candidate)
	return actual.(*atomic.Int64)
}

func (m *Manager) incrementInflight(nodeID uint64) {
	m.inflightCounter(nodeID).Add(1)
}

func (m *Manager) decrementInflight(nodeID uint64) {
	if value, ok := m.inflight.Load(nodeID); ok {
		value.(*atomic.Int64).Add(-1)
	}
}

func clearanceCacheKey(nodeID uint64, proxyURL string, sticky bool) string {
	if nodeID == 0 {
		return "direct"
	}
	base := "node:" + strconv.FormatUint(nodeID, 10)
	if !sticky {
		return base
	}
	digest := sha256.Sum256([]byte(proxyURL))
	return base + ":account:" + fmt.Sprintf("%x", digest[:16])
}

func renderAccountProxyURL(template, accountKey string) (string, error) {
	if !strings.Contains(template, application.ProxyAccountPlaceholder) {
		return template, nil
	}
	accountKey = normalizeProxyAccount(accountKey)
	if accountKey == "" {
		return "", errors.New("粘性代理需要有效的账号身份")
	}
	return strings.ReplaceAll(template, application.ProxyAccountPlaceholder, accountKey), nil
}

func normalizeProxyAccount(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	value = strings.Map(func(character rune) rune {
		if (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') ||
			(character >= '0' && character <= '9') || character == '_' || character == '-' {
			return character
		}
		return '_'
	}, value)
	if len(value) <= 128 {
		return value
	}
	digest := sha256.Sum256([]byte(value))
	return value[:95] + "_" + fmt.Sprintf("%x", digest[:16])
}

func (m *Manager) listNodes(ctx context.Context, scope domain.Scope, now time.Time) ([]domain.Node, error) {
	for {
		m.nodeMu.RLock()
		if snapshot, ok := m.nodes[scope]; ok && now.Before(snapshot.expiresAt) {
			// Node snapshots are replaced with a copied slice and treated as immutable
			// by callers. Returning the shared read-only slice avoids a per-request copy.
			values := snapshot.values
			m.nodeMu.RUnlock()
			return values, nil
		}
		m.nodeMu.RUnlock()
		loaded, err, _ := m.nodeLoads.Do(string(scope), func() (any, error) {
			checkTime := time.Now().UTC()
			m.nodeMu.RLock()
			if snapshot, ok := m.nodes[scope]; ok && checkTime.Before(snapshot.expiresAt) {
				values := snapshot.values
				m.nodeMu.RUnlock()
				return values, nil
			}
			version := m.nodeVersions[scope]
			m.nodeMu.RUnlock()
			values, err := m.repository.ListEgressNodes(ctx, scope, repository.SortQuery{})
			if err != nil {
				return nil, err
			}
			m.nodeMu.Lock()
			if m.nodeVersions[scope] != version {
				m.nodeMu.Unlock()
				return nil, errNodeSnapshotInvalidated
			}
			m.replaceNodeSnapshotLocked(scope, values, checkTime.Add(nodeSnapshotTTL))
			values = m.nodes[scope].values
			m.nodeMu.Unlock()
			return values, nil
		})
		if err != nil {
			if errors.Is(err, errNodeSnapshotInvalidated) && ctx.Err() == nil {
				now = time.Now().UTC()
				continue
			}
			return nil, err
		}
		return loaded.([]domain.Node), nil
	}
}

func (m *Manager) invalidateNodes(scope domain.Scope) {
	m.nodeMu.Lock()
	m.nodeVersions[scope]++
	snapshot, ok := m.nodes[scope]
	if ok {
		delete(m.nodes, scope)
	}
	for _, node := range snapshot.values {
		delete(m.healthyNodes, node.ID)
	}
	m.nodeMu.Unlock()
}

func (m *Manager) replaceNodeSnapshotLocked(scope domain.Scope, values []domain.Node, expiresAt time.Time) {
	for _, node := range m.nodes[scope].values {
		delete(m.healthyNodes, node.ID)
	}
	for _, node := range values {
		if nodeIsHealthy(node) {
			m.healthyNodes[node.ID] = expiresAt
		} else {
			delete(m.healthyNodes, node.ID)
		}
	}
	m.nodes[scope] = cachedNodeSnapshot{values: append([]domain.Node(nil), values...), expiresAt: expiresAt}
}

func (m *Manager) InvalidateOperationsConfig() {
	m.operationsMu.Lock()
	m.operationsConfig = cachedOperationsConfig{}
	m.operationsConfigVer++
	m.operationsMu.Unlock()
}

func fallbackScopes(scope domain.Scope) []domain.Scope {
	if scope == domain.ScopeWebAsset {
		return []domain.Scope{domain.ScopeWebAsset, domain.ScopeWeb}
	}
	if scope == domain.ScopeConsoleAsset {
		return []domain.Scope{domain.ScopeConsoleAsset, domain.ScopeConsole, domain.ScopeWeb}
	}
	if scope == domain.ScopeConsole {
		// Console uses the same browser/clearance surface as Grok Web. A
		// dedicated Console node is preferred, but a Web node is a safe and
		// expected fallback for deployments that configure one shared pool.
		return []domain.Scope{domain.ScopeConsole, domain.ScopeWeb}
	}
	return []domain.Scope{scope}
}

func (m *Manager) selectNode(nodes []domain.Node, affinity string) domain.Node {
	if affinity != "" {
		digest := sha256.Sum256([]byte(affinity))
		selected := nodes[int(binary.BigEndian.Uint64(digest[:8])%uint64(len(nodes)))]
		if selected.Health >= 0.8 || len(nodes) == 1 {
			return selected
		}
		for _, node := range nodes {
			if node.Health > selected.Health {
				selected = node
			}
		}
		return selected
	}
	best := nodes[0]
	bestCurrent := m.inflightCount(best.ID)
	for _, node := range nodes[1:] {
		current := m.inflightCount(node.ID)
		if current < bestCurrent || (current == bestCurrent && node.Health > best.Health) {
			best = node
			bestCurrent = current
		}
	}
	return best
}

func (m *Manager) inflightCount(nodeID uint64) int64 {
	if value, ok := m.inflight.Load(nodeID); ok {
		return value.(*atomic.Int64).Load()
	}
	return 0
}

func (m *Manager) clientFor(id uint64, scope domain.Scope, proxyURL, userAgent, cookies string, sticky bool, accountIdentity string) (cachedClient, error) {
	return m.clientForWithOptions(id, scope, proxyURL, userAgent, cookies, sticky, accountIdentity, clientOptions{})
}

func (m *Manager) clientForWithOptions(id uint64, scope domain.Scope, proxyURL, userAgent, cookies string, sticky bool, accountIdentity string, options clientOptions) (cachedClient, error) {
	clientKind := "browser"
	buildHeaderTimeout := time.Duration(0)
	if scope == domain.ScopeBuild {
		clientKind = "build"
		buildHeaderTimeout = time.Duration(m.buildHeaderTimeout.Load())
		if buildHeaderTimeout <= 0 {
			buildHeaderTimeout = settingsdomain.DefaultBuildResponseHeaderTimeout
		}
		clientKind += "\x00" + strconv.FormatInt(int64(buildHeaderTimeout), 10)
		if options.buildEnvironmentProxy {
			clientKind += "\x00environment-proxy"
		}
	}
	fingerprint := fmt.Sprintf("%x", sha256.Sum256([]byte(clientKind+"\x00"+proxyURL+"\x00"+userAgent+"\x00"+cookies)))
	cacheScope := scope
	if cacheScope == domain.ScopeWebAsset {
		cacheScope = domain.ScopeWeb
	}
	for attempt := 0; attempt < clientCreationRetryLimit; attempt++ {
		isolated := m.accountIsolated.Load()
		if options.requireAccountIsolation && !isolated {
			return cachedClient{}, errAccountConnectionIsolationDisabled
		}
		keyAccountIdentity := ""
		if isolated {
			keyAccountIdentity = strings.TrimSpace(accountIdentity)
			if keyAccountIdentity == "" {
				keyAccountIdentity = "shared"
			}
		}
		key := clientCacheKey{nodeID: id, scope: cacheScope, fingerprint: fingerprint, accountIdentity: keyAccountIdentity}
		loadKey := strconv.FormatUint(key.nodeID, 10) + "\x00" + string(key.scope) + "\x00" + key.fingerprint + "\x00" + key.accountIdentity
		now := time.Now().UTC()
		m.clientMu.RLock()
		cached, cachedOK := m.clients[key]
		cleanupDue := m.lastClientCleanup.IsZero() || now.Sub(m.lastClientCleanup) >= clientCacheCleanupInterval
		touchDue := cachedOK && (cached.lastUsed.IsZero() || now.Sub(cached.lastUsed) >= clientCacheTouchInterval)
		m.clientMu.RUnlock()
		if cachedOK && !cleanupDue && !touchDue {
			return cached, nil
		}

		m.clientMu.Lock()
		stale := m.cleanupClientCacheLocked(now)
		if cached, ok := m.clients[key]; ok {
			cached.lastUsed = now
			m.clients[key] = cached
			m.clientMu.Unlock()
			closeRequestClients(stale)
			return cached, nil
		}
		m.clientMu.Unlock()
		closeRequestClients(stale)

		loaded, err, _ := m.clientLoads.Do(loadKey, func() (any, error) {
			return m.createAndCacheClient(key, id, scope, proxyURL, userAgent, sticky, buildHeaderTimeout, options)
		})
		if errors.Is(err, errClientCacheInvalidated) {
			continue
		}
		if err != nil {
			return cachedClient{}, err
		}
		return loaded.(cachedClient), nil
	}
	return cachedClient{}, errClientCacheInvalidated
}

func (m *Manager) createAndCacheClient(key clientCacheKey, id uint64, scope domain.Scope, proxyURL, userAgent string, sticky bool, buildHeaderTimeout time.Duration, options clientOptions) (cachedClient, error) {
	now := time.Now().UTC()
	m.clientMu.Lock()
	stale := m.cleanupClientCacheLocked(now)
	if (key.accountIdentity != "") != m.accountIsolated.Load() {
		m.clientMu.Unlock()
		closeRequestClients(stale)
		return cachedClient{}, errClientCacheInvalidated
	}
	if cached, ok := m.clients[key]; ok {
		cached.lastUsed = now
		m.clients[key] = cached
		m.clientMu.Unlock()
		closeRequestClients(stale)
		return cached, nil
	}
	version := m.clientVersionLocked(id)
	m.clientMu.Unlock()
	closeRequestClients(stale)

	value, err := m.buildCachedClient(scope, proxyURL, userAgent, buildHeaderTimeout, options)
	if err != nil {
		return cachedClient{}, err
	}
	value.lastUsed = time.Now().UTC()

	m.clientMu.Lock()
	stale = m.cleanupClientCacheLocked(value.lastUsed)
	if (key.accountIdentity != "") != m.accountIsolated.Load() {
		m.clientMu.Unlock()
		closeRequestClients(append(stale, value.client))
		return cachedClient{}, errClientCacheInvalidated
	}
	if cached, ok := m.clients[key]; ok {
		cached.lastUsed = value.lastUsed
		m.clients[key] = cached
		m.clientMu.Unlock()
		closeRequestClients(append(stale, value.client))
		return cached, nil
	}
	if m.clientVersionLocked(id) != version {
		m.clientMu.Unlock()
		closeRequestClients(append(stale, value.client))
		return cachedClient{}, errClientCacheInvalidated
	}
	if id != 0 && !sticky {
		for previousKey, previous := range m.clients {
			if previousKey.nodeID != id || previousKey.scope != key.scope {
				continue
			}
			// Keep other accounts' pools when isolation is on.
			if key.accountIdentity != "" && previousKey.accountIdentity != key.accountIdentity {
				continue
			}
			stale = append(stale, m.evictClientLocked(previousKey, previous))
		}
	}
	stale = append(stale, m.ensureClientCacheCapacityLocked()...)
	m.clients[key] = value
	m.clientMu.Unlock()
	closeRequestClients(stale)
	return value, nil
}

func (m *Manager) buildCachedClient(scope domain.Scope, proxyURL, userAgent string, buildHeaderTimeout time.Duration, options clientOptions) (cachedClient, error) {
	if scope == domain.ScopeBuild {
		if options.buildEnvironmentProxy {
			factory := m.newBuildEnvClient
			if factory == nil {
				factory = newBuildEnvironmentRequestClient
			}
			client, err := factory(buildHeaderTimeout)
			if err != nil {
				return cachedClient{}, err
			}
			return cachedClient{client: client}, nil
		}
		factory := m.newBuildClient
		if factory == nil {
			factory = newBuildRequestClient
		}
		client, err := factory(proxyURL, buildHeaderTimeout)
		if err != nil {
			return cachedClient{}, err
		}
		return cachedClient{client: client}, nil
	}
	factory := m.newBrowserClient
	if factory == nil {
		factory = newBrowserClient
	}
	client, err := factory(proxyURL, userAgent)
	if err != nil {
		return cachedClient{}, err
	}
	return cachedClient{client: client, browser: client}, nil
}

func newBuildRequestClient(proxyURL string, responseHeaderTimeout time.Duration) (requestClient, error) {
	return newBuildClient(proxyURL, responseHeaderTimeout)
}

func newBuildEnvironmentRequestClient(responseHeaderTimeout time.Duration) (requestClient, error) {
	return newBuildEnvironmentClient(responseHeaderTimeout)
}

func (m *Manager) cleanupClientCacheLocked(now time.Time) []requestClient {
	if m.clients == nil {
		m.clients = make(map[clientCacheKey]cachedClient)
	}
	if !m.lastClientCleanup.IsZero() && now.Sub(m.lastClientCleanup) < clientCacheCleanupInterval {
		return nil
	}
	m.lastClientCleanup = now
	var stale []requestClient
	for key, value := range m.clients {
		if !value.lastUsed.IsZero() && now.Sub(value.lastUsed) >= clientCacheIdleTTL {
			stale = append(stale, m.evictClientLocked(key, value))
		}
	}
	return stale
}

func (m *Manager) ensureClientCacheCapacityLocked() []requestClient {
	var stale []requestClient
	for len(m.clients) >= maxCachedClients {
		var oldestKey clientCacheKey
		var oldest cachedClient
		found := false
		for key, value := range m.clients {
			if !found || value.lastUsed.Before(oldest.lastUsed) {
				oldestKey, oldest, found = key, value, true
			}
		}
		if !found {
			break
		}
		stale = append(stale, m.evictClientLocked(oldestKey, oldest))
	}
	return stale
}

func (m *Manager) evictClientLocked(key clientCacheKey, value cachedClient) requestClient {
	delete(m.clients, key)
	return value.client
}

func closeRequestClients(values []requestClient) {
	for _, value := range values {
		if value != nil {
			value.CloseIdleConnections()
		}
	}
}

func (m *Manager) clientVersionLocked(nodeID uint64) uint64 {
	return m.clientGeneration + m.clientVersions[nodeID]
}

func (m *Manager) invalidateClientVersionLocked(nodeID uint64) {
	if m.clientVersions == nil {
		m.clientVersions = make(map[uint64]uint64)
	}
	if _, exists := m.clientVersions[nodeID]; !exists && len(m.clientVersions) >= maxClientVersionEntries {
		// A generation bump invalidates in-flight creations before the tombstone map is reset.
		m.clientGeneration++
		clear(m.clientVersions)
	}
	m.clientVersions[nodeID]++
}

func (m *Manager) invalidateAllClientVersionsLocked() {
	m.clientGeneration++
	clear(m.clientVersions)
}

func (m *Manager) Feedback(ctx context.Context, nodeID uint64, status int, transportErr error) {
	m.FeedbackForScope(ctx, domain.ScopeWeb, nodeID, status, transportErr)
}

func (m *Manager) FeedbackForScope(ctx context.Context, scope domain.Scope, nodeID uint64, status int, transportErr error) {
	if status == clientClosedRequestStatus || errors.Is(transportErr, context.Canceled) {
		return
	}
	// Console media hosts are public and do not use clearance credentials. A
	// 403 there commonly describes the object URL (expired, rejected, or
	// missing), not the proxy's ability to reach the origin, so it must not cool
	// or rotate an otherwise healthy primary Console node.
	if scope == domain.ScopeConsoleAsset && transportErr == nil && status == http.StatusForbidden {
		return
	}
	if neterrorpkg.IsUpstreamStreamIdleTimeout(transportErr) {
		return
	}
	if scope == domain.ScopeBuild && neterrorpkg.IsResponseHeaderTimeout(transportErr) {
		return
	}
	if nodeID == 0 {
		if transportErr != nil || (scope != domain.ScopeBuild && status == http.StatusForbidden) {
			m.clearanceMu.Lock()
			if isGrokWebScope(scope) && status == http.StatusForbidden && m.clearanceConfig.Mode == "flaresolverr" {
				state := m.clearances["direct"]
				state.invalid = true
				state.used = true
				m.clearances["direct"] = state
			}
			m.clearanceMu.Unlock()
			m.clientMu.Lock()
			stale := m.invalidateClientForScopeLocked(0, scope)
			m.clientMu.Unlock()
			closeRequestClients(stale)
		}
		return
	}
	succeeded := transportErr == nil && status >= 200 && status < 400
	if succeeded && m.cachedNodeIsHealthy(nodeID) {
		return
	}
	value, err := m.repository.GetEgressNode(ctx, nodeID)
	if err != nil {
		return
	}
	if succeeded && nodeIsHealthy(value) {
		m.nodeMu.Lock()
		m.healthyNodes[nodeID] = time.Now().UTC().Add(nodeSnapshotTTL)
		m.nodeMu.Unlock()
		return
	}
	now := time.Now().UTC()
	var stale []requestClient
	switch {
	case succeeded:
		value.Health = min(1, value.Health+0.1)
		value.FailureCount = 0
		value.CooldownUntil = nil
		value.LastError = ""
	case status == http.StatusUnauthorized || status == http.StatusTooManyRequests:
		return
	case scope == domain.ScopeBuild && status == http.StatusForbidden:
		// Build 403 may indicate account permissions, quota, token, or egress policy. The gateway classifies the body;
		// status alone must not misclassify standard CLI egress as Web anti-bot behavior.
		return
	case scope == domain.ScopeBuild && status == http.StatusBadRequest:
		// Device OAuth polls with 400 + authorization_pending before user confirmation.
		// This is a normal protocol state and must not cool the egress node.
		return
	case status == http.StatusForbidden:
		if m.isProxyPoolNode(value) {
			// A request-level 403 does not prove that a shared proxy pool is unhealthy.
			return
		}
		value.FailureCount++
		value.Health = max(0.05, value.Health*0.7)
		value.CooldownUntil = nil
		value.LastError = "anti-bot rejection"
		m.clearanceMu.Lock()
		if isGrokWebScope(scope) && m.clearanceConfig.Mode == "flaresolverr" {
			key := clearanceCacheKey(nodeID, "", false)
			state := m.clearances[key]
			state.invalid = true
			state.used = true
			m.clearances[key] = state
		}
		m.clearanceMu.Unlock()
		m.clientMu.Lock()
		stale = m.invalidateClientLocked(nodeID)
		m.clientMu.Unlock()
	case transportErr != nil:
		if m.isProxyPoolNode(value) {
			return
		}
		value.FailureCount++
		value.Health = max(0.05, value.Health*0.7)
		cooldown := min(10*time.Minute, 30*time.Second*time.Duration(1<<min(value.FailureCount-1, 4)))
		until := now.Add(cooldown)
		value.CooldownUntil = &until
		value.LastError = domain.LastErrorTransport
		m.clientMu.Lock()
		stale = m.invalidateClientLocked(nodeID)
		m.clientMu.Unlock()
	default:
		// An HTTP status describes the upstream response, not the health of the
		// configured proxy endpoint. Account routing handles upstream failures.
		return
	}
	closeRequestClients(stale)
	if stateRepository, ok := m.repository.(egressStateRepository); ok {
		if err := stateRepository.UpdateEgressNodeHealth(ctx, value.ID, value.Health, value.FailureCount, value.CooldownUntil, value.LastError); err == nil {
			m.invalidateNodes(value.Scope)
			if transportErr != nil {
				m.scheduleFailureProbe(value)
			}
		}
		return
	}
	if _, err := m.repository.UpdateEgressNode(ctx, value); err == nil {
		m.invalidateNodes(value.Scope)
		if transportErr != nil {
			m.scheduleFailureProbe(value)
		}
	}
}

func (m *Manager) cachedNodeIsHealthy(nodeID uint64) bool {
	m.nodeMu.Lock()
	validUntil, ok := m.healthyNodes[nodeID]
	healthy := ok && time.Now().UTC().Before(validUntil)
	if ok && !healthy {
		delete(m.healthyNodes, nodeID)
	}
	m.nodeMu.Unlock()
	return healthy
}

func nodeIsHealthy(value domain.Node) bool {
	return value.Health >= 1 && value.FailureCount == 0 && value.CooldownUntil == nil && value.LastError == ""
}

func (m *Manager) clearanceMode() string {
	m.clearanceMu.Lock()
	defer m.clearanceMu.Unlock()
	return m.clearanceConfig.Mode
}

func (m *Manager) ensureClearance(ctx context.Context, node domain.Node, proxyURL, existingCookies, existingUserAgent, key string, persist bool) (string, string, error) {
	m.clearanceMu.Lock()
	cfg := m.clearanceConfig
	version := m.clearanceVersion
	interval := clearanceRefreshInterval(cfg)
	now := time.Now().UTC()
	fingerprint := clearanceFingerprint(cfg, proxyURL)
	bindingFingerprint := clearanceBindingFingerprint(cfg, proxyURL)
	m.cleanupClearanceCacheLocked(now, interval)
	state, known := m.clearances[key]
	if key == "direct" {
		if !known {
			m.ensureClearanceCacheCapacityLocked()
		}
		state.used = true
		m.clearances[key] = state
	}
	if (!known || state.userAgent == "") && persist && (existingCookies != "" || node.ClearanceRefreshedAt != nil) {
		if !known {
			m.ensureClearanceCacheCapacityLocked()
		}
		state = clearanceState{
			cookies: existingCookies, userAgent: existingUserAgent, used: true, version: version,
			fingerprint: node.ClearanceFingerprint, bindingFingerprint: node.ClearanceBindingFingerprint,
			lastUsedAt: now,
		}
		if node.ClearanceRefreshedAt != nil {
			state.refreshedAt = *node.ClearanceRefreshedAt
		}
		known = true
		m.clearances[key] = state
	}
	// A successful solve may legitimately return no Cloudflare cookies when the
	// selected egress does not trigger a challenge. The solver User-Agent marks
	// that cookie-less result as complete so requests do not block on re-solving.
	fresh := known && !state.invalid && state.userAgent != "" && state.version == version &&
		state.fingerprint == fingerprint && (state.bindingFingerprint == "" || state.bindingFingerprint == bindingFingerprint) &&
		!state.refreshedAt.IsZero() && now.Sub(state.refreshedAt) < interval
	if fresh {
		state.lastUsedAt = now
		m.clearances[key] = state
		cookies, userAgent := state.cookies, state.userAgent
		m.clearanceMu.Unlock()
		return cookies, userAgent, nil
	}
	fallbackAllowed := known && !state.invalid && state.userAgent != "" &&
		(state.bindingFingerprint == "" || state.bindingFingerprint == bindingFingerprint)
	fallback := clearanceSolution{Cookies: state.cookies, UserAgent: state.userAgent}
	forceRefresh := known && state.invalid
	refreshAfter := time.Time{}
	if forceRefresh {
		refreshAfter = state.refreshedAt
	}
	if fallbackAllowed {
		state.lastUsedAt = now
		m.clearances[key] = state
	}
	if cfg.Mode == "on_demand" && !forceRefresh {
		m.clearanceMu.Unlock()
		if fallbackAllowed {
			return fallback.Cookies, fallback.UserAgent, nil
		}
		return existingCookies, existingUserAgent, nil
	}
	if cfg.Mode != "flaresolverr" && cfg.Mode != "on_demand" {
		m.clearanceMu.Unlock()
		return existingCookies, existingUserAgent, nil
	}
	m.clearanceMu.Unlock()

	result, err, _ := m.clearanceLoads.Do(key, func() (any, error) {
		return m.refreshNode(ctx, node, proxyURL, key, persist, forceRefresh, !fallbackAllowed, refreshAfter)
	})
	if err != nil {
		if fallbackAllowed {
			return fallback.Cookies, fallback.UserAgent, nil
		}
		return "", "", err
	}
	solution := result.(clearanceSolution)
	return solution.Cookies, solution.UserAgent, nil
}

func (m *Manager) refreshNode(ctx context.Context, node domain.Node, proxyURL, key string, persist, force, waitForPeer bool, refreshAfter time.Time) (clearanceSolution, error) {
	m.clearanceMu.Lock()
	cfg := m.clearanceConfig
	solveVersion := m.clearanceVersion
	solver := m.solver
	lock := m.clearanceLock
	m.clearanceMu.Unlock()
	if cfg.Mode != "flaresolverr" && cfg.Mode != "on_demand" {
		return clearanceSolution{}, errors.New("FlareSolverr Clearance 未启用")
	}
	timeout := cfg.Timeout
	if timeout <= 0 {
		timeout = time.Minute
	}
	fingerprint := clearanceFingerprint(cfg, proxyURL)
	bindingFingerprint := clearanceBindingFingerprint(cfg, proxyURL)
	interval := clearanceRefreshInterval(cfg)
	if persist && node.ID != 0 && lock != nil {
		release, acquired, err := lock.Acquire(ctx, "egress-clearance:"+strconv.FormatUint(node.ID, 10), timeout+clearanceLockGrace)
		if err != nil {
			return clearanceSolution{}, fmt.Errorf("协调 Clearance 刷新: %w", err)
		}
		if !acquired {
			if !force {
				if solution, refreshedAt, ok := m.loadPersistedClearance(ctx, node.ID, fingerprint, bindingFingerprint, interval); ok {
					m.cacheClearance(key, solution, refreshedAt, solveVersion, fingerprint, bindingFingerprint, interval)
					return solution, nil
				}
			}
			if waitForPeer {
				if solution, refreshedAt, ok := m.waitPersistedClearance(ctx, node.ID, fingerprint, bindingFingerprint, interval, timeout, refreshAfter); ok {
					m.cacheClearance(key, solution, refreshedAt, solveVersion, fingerprint, bindingFingerprint, interval)
					return solution, nil
				}
			}
			return clearanceSolution{}, errors.New("另一个实例正在刷新 Cloudflare Clearance")
		}
		defer release()
		if solution, refreshedAt, ok := m.loadPersistedClearance(ctx, node.ID, fingerprint, bindingFingerprint, interval); ok {
			// A peer may have refreshed the rejected Clearance immediately before
			// this instance acquired the distributed lock. Reuse that newer result
			// instead of performing a duplicate browser solve. A force refresh with
			// no newer persisted generation must still reach the solver.
			if !force || (!refreshAfter.IsZero() && refreshedAt.After(refreshAfter)) {
				m.cacheClearance(key, solution, refreshedAt, solveVersion, fingerprint, bindingFingerprint, interval)
				return solution, nil
			}
		}
	}
	solveCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	solution, err := solver.Solve(solveCtx, cfg, proxyURL)
	if err != nil {
		m.recordClearanceError(ctx, node, persist)
		return clearanceSolution{}, fmt.Errorf("刷新出口 %q 的 Cloudflare Clearance: %w", node.Name, err)
	}
	now := time.Now().UTC()
	if persist && node.ID != 0 {
		encryptedCookies, encryptErr := m.cipher.Encrypt(solution.Cookies)
		if encryptErr != nil {
			return clearanceSolution{}, encryptErr
		}
		if stateRepository, ok := m.repository.(egressStateRepository); ok {
			if updateErr := stateRepository.UpdateEgressNodeClearance(ctx, node.ID, encryptedCookies, solution.UserAgent, fingerprint, bindingFingerprint, now); updateErr != nil {
				return clearanceSolution{}, updateErr
			}
		} else {
			latest, loadErr := m.repository.GetEgressNode(ctx, node.ID)
			if loadErr != nil {
				return clearanceSolution{}, loadErr
			}
			latest.EncryptedCloudflareCookie = encryptedCookies
			latest.UserAgent = solution.UserAgent
			latest.ClearanceFingerprint = fingerprint
			latest.ClearanceBindingFingerprint = bindingFingerprint
			latest.ClearanceRefreshedAt = &now
			latest.LastError = ""
			if _, updateErr := m.repository.UpdateEgressNode(ctx, latest); updateErr != nil {
				return clearanceSolution{}, updateErr
			}
		}
		m.invalidateNodes(node.Scope)
	}
	m.cacheClearance(key, solution, now, solveVersion, fingerprint, bindingFingerprint, interval)
	return solution, nil
}

func (m *Manager) waitPersistedClearance(ctx context.Context, nodeID uint64, fingerprint, bindingFingerprint string, interval, timeout time.Duration, refreshAfter time.Time) (clearanceSolution, time.Time, bool) {
	waitCtx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	ticker := time.NewTicker(200 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-waitCtx.Done():
			return clearanceSolution{}, time.Time{}, false
		case <-ticker.C:
			if solution, refreshedAt, ok := m.loadPersistedClearance(waitCtx, nodeID, fingerprint, bindingFingerprint, interval); ok &&
				(refreshAfter.IsZero() || refreshedAt.After(refreshAfter)) {
				return solution, refreshedAt, true
			}
		}
	}
}

func (m *Manager) loadPersistedClearance(ctx context.Context, nodeID uint64, fingerprint, bindingFingerprint string, interval time.Duration) (clearanceSolution, time.Time, bool) {
	latest, err := m.repository.GetEgressNode(ctx, nodeID)
	if err != nil || latest.ClearanceRefreshedAt == nil || latest.ClearanceFingerprint != fingerprint ||
		(latest.ClearanceBindingFingerprint != "" && latest.ClearanceBindingFingerprint != bindingFingerprint) ||
		time.Since(*latest.ClearanceRefreshedAt) >= interval {
		return clearanceSolution{}, time.Time{}, false
	}
	cookies, err := m.cipher.Decrypt(latest.EncryptedCloudflareCookie)
	if err != nil {
		return clearanceSolution{}, time.Time{}, false
	}
	cookies = application.SanitizeCloudflareCookies(cookies)
	userAgent := strings.TrimSpace(latest.UserAgent)
	if userAgent == "" {
		return clearanceSolution{}, time.Time{}, false
	}
	return clearanceSolution{Cookies: cookies, UserAgent: userAgent}, *latest.ClearanceRefreshedAt, true
}

func (m *Manager) cacheClearance(key string, solution clearanceSolution, refreshedAt time.Time, version uint64, fingerprint, bindingFingerprint string, interval time.Duration) {
	m.clearanceMu.Lock()
	now := time.Now().UTC()
	m.cleanupClearanceCacheLocked(now, interval)
	if _, exists := m.clearances[key]; !exists {
		m.ensureClearanceCacheCapacityLocked()
	}
	m.clearances[key] = clearanceState{
		cookies: solution.Cookies, userAgent: solution.UserAgent, refreshedAt: refreshedAt,
		used: true, version: version, fingerprint: fingerprint, bindingFingerprint: bindingFingerprint, lastUsedAt: now,
	}
	m.clearanceMu.Unlock()
}

func (m *Manager) cleanupClearanceCacheLocked(now time.Time, interval time.Duration) {
	if m.clearances == nil {
		m.clearances = make(map[string]clearanceState)
	}
	if !m.lastClearanceCleanup.IsZero() && now.Sub(m.lastClearanceCleanup) < clearanceCacheCleanupInterval {
		return
	}
	m.lastClearanceCleanup = now
	idleTTL := interval * 2
	if idleTTL < clearanceCacheMinIdleTTL {
		idleTTL = clearanceCacheMinIdleTTL
	}
	for key, state := range m.clearances {
		lastUsedAt := state.lastUsedAt
		if lastUsedAt.IsZero() {
			lastUsedAt = state.refreshedAt
		}
		if !lastUsedAt.IsZero() && now.Sub(lastUsedAt) >= idleTTL {
			delete(m.clearances, key)
		}
	}
}

func (m *Manager) ensureClearanceCacheCapacityLocked() {
	if len(m.clearances) < maxCachedClearances {
		return
	}
	type candidate struct {
		key      string
		lastUsed time.Time
	}
	candidates := make([]candidate, 0, len(m.clearances))
	for key, state := range m.clearances {
		lastUsedAt := state.lastUsedAt
		if lastUsedAt.IsZero() {
			lastUsedAt = state.refreshedAt
		}
		candidates = append(candidates, candidate{key: key, lastUsed: lastUsedAt})
	}
	sort.Slice(candidates, func(i, j int) bool {
		return candidates[i].lastUsed.Before(candidates[j].lastUsed)
	})
	removeCount := min(clearanceCacheEvictionBatch, len(candidates))
	for _, entry := range candidates[:removeCount] {
		delete(m.clearances, entry.key)
	}
}

func clearanceRefreshInterval(cfg ClearanceConfig) time.Duration {
	if cfg.RefreshInterval > 0 {
		return cfg.RefreshInterval
	}
	return 10 * time.Minute
}

func clearanceFingerprint(cfg ClearanceConfig, proxyURL string) string {
	value := strings.TrimSpace(cfg.FlareSolverrURL) + "\x00" + clearanceBindingFingerprint(cfg, proxyURL)
	return fmt.Sprintf("%x", sha256.Sum256([]byte(value)))
}

func clearanceBindingFingerprint(cfg ClearanceConfig, proxyURL string) string {
	value := strings.TrimRight(strings.TrimSpace(cfg.TargetURL), "/") + "\x00" + strings.TrimSpace(proxyURL)
	return fmt.Sprintf("%x", sha256.Sum256([]byte(value)))
}

func (m *Manager) recordClearanceError(ctx context.Context, node domain.Node, persist bool) {
	if node.ID == 0 || !persist {
		return
	}
	if stateRepository, ok := m.repository.(egressStateRepository); ok {
		if err := stateRepository.UpdateEgressNodeLastError(ctx, node.ID, "clearance refresh failed"); err == nil {
			m.invalidateNodes(node.Scope)
			return
		}
	}
	latest, err := m.repository.GetEgressNode(ctx, node.ID)
	if err != nil {
		return
	}
	latest.LastError = "clearance refresh failed"
	if _, err := m.repository.UpdateEgressNode(ctx, latest); err == nil {
		m.invalidateNodes(latest.Scope)
	}
}

func (m *Manager) RefreshClearance(ctx context.Context, nodeID uint64) error {
	if nodeID == 0 {
		_, err, _ := m.clearanceLoads.Do("direct", func() (any, error) {
			return m.refreshNode(ctx, domain.Node{Name: "direct", Scope: domain.ScopeWeb, Enabled: true}, "", "direct", false, true, true, time.Time{})
		})
		return err
	}
	node, err := m.repository.GetEgressNode(ctx, nodeID)
	if err != nil {
		return err
	}
	if !isGrokWebScope(node.Scope) {
		return fmt.Errorf("出口节点 %q 不支持 Clearance 刷新", node.Name)
	}
	proxyURL, err := m.cipher.Decrypt(node.EncryptedProxyURL)
	if err != nil {
		return err
	}
	if strings.Contains(proxyURL, application.ProxyAccountPlaceholder) {
		return fmt.Errorf("出口节点 %q 使用账号粘性代理，将在账号请求时按租约自动刷新 Clearance", node.Name)
	}
	proxyURL, err = application.NormalizeProxyURL(proxyURL)
	if err != nil {
		return err
	}
	key := clearanceCacheKey(node.ID, proxyURL, false)
	_, err, _ = m.clearanceLoads.Do(key, func() (any, error) {
		return m.refreshNode(ctx, node, proxyURL, key, true, true, true, time.Time{})
	})
	return err
}

func (m *Manager) InvalidateClearance(nodeID uint64) {
	m.clearanceMu.Lock()
	prefix := "node:" + strconv.FormatUint(nodeID, 10)
	if nodeID == 0 {
		prefix = "direct"
	}
	for key, state := range m.clearances {
		if key == prefix || strings.HasPrefix(key, prefix+":") {
			state.invalid = true
			state.used = true
			m.clearances[key] = state
		}
	}
	m.clearanceMu.Unlock()
	m.clientMu.Lock()
	stale := m.invalidateClientLocked(nodeID)
	m.clientMu.Unlock()
	closeRequestClients(stale)
}

// ForgetClearance evicts runtime state after an administrator changes or
// removes a node. Unlike a 403 rejection, it does not mark the persisted
// last-known-good cookie as invalid; ensureClearance will still verify its
// binding before using it as a solver-failure fallback.
func (m *Manager) ForgetClearance(nodeID uint64) {
	m.ForgetClearances([]uint64{nodeID})
}

// ForgetClearances evicts a batch of node-scoped runtime state with one cache
// scan and one lock acquisition. Administrative bulk updates can contain
// thousands of nodes, so repeating the global snapshot invalidation per ID
// would add avoidable lock contention and CPU work.
func (m *Manager) ForgetClearances(nodeIDs []uint64) {
	ids := make(map[uint64]struct{}, len(nodeIDs))
	prefixes := make(map[string]struct{}, len(nodeIDs))
	for _, nodeID := range nodeIDs {
		if _, exists := ids[nodeID]; exists {
			continue
		}
		ids[nodeID] = struct{}{}
		prefix := "node:" + strconv.FormatUint(nodeID, 10)
		if nodeID == 0 {
			prefix = "direct"
		}
		prefixes[prefix] = struct{}{}
	}
	if len(ids) == 0 {
		return
	}
	m.clearanceMu.Lock()
	m.nodeMu.Lock()
	m.clientMu.Lock()
	for key := range m.clearances {
		prefix := key
		if strings.HasPrefix(key, "node:") {
			if separator := strings.IndexByte(key[len("node:"):], ':'); separator >= 0 {
				prefix = key[:len("node:")+separator]
			}
		} else if strings.HasPrefix(key, "direct:") {
			prefix = "direct"
		}
		if _, selected := prefixes[prefix]; selected {
			delete(m.clearances, key)
		}
	}
	// Node mutations are rare administration operations. Clearing the small
	// one-second snapshots prevents a just-edited proxy from being used once
	// more before its scope cache expires.
	if m.nodeVersions == nil {
		m.nodeVersions = make(map[domain.Scope]uint64)
	}
	for _, scope := range allEgressScopes() {
		m.nodeVersions[scope]++
	}
	clear(m.nodes)
	clear(m.healthyNodes)
	var stale []requestClient
	for nodeID := range ids {
		m.invalidateClientVersionLocked(nodeID)
	}
	for key, cached := range m.clients {
		if _, selected := ids[key.nodeID]; !selected {
			continue
		}
		delete(m.clients, key)
		stale = append(stale, cached.client)
	}
	m.clientMu.Unlock()
	m.nodeMu.Unlock()
	m.clearanceMu.Unlock()
	closeRequestClients(stale)
}

func (m *Manager) invalidateClearanceKey(key string, client requestClient) {
	m.clearanceMu.Lock()
	state := m.clearances[key]
	state.invalid = true
	state.used = true
	state.lastUsedAt = time.Now().UTC()
	m.clearances[key] = state
	m.clearanceMu.Unlock()
	if client != nil {
		client.CloseIdleConnections()
	}
}

func (m *Manager) RefreshDueClearances(ctx context.Context, force bool) error {
	m.clearanceMu.Lock()
	cfg := m.clearanceConfig
	direct := m.clearances["direct"]
	version := m.clearanceVersion
	m.clearanceMu.Unlock()
	if cfg.Mode != "flaresolverr" {
		return nil
	}
	interval := clearanceRefreshInterval(cfg)
	now := time.Now().UTC()
	nodes, err := m.repository.ListEgressNodes(ctx, "", repository.SortQuery{})
	if err != nil {
		return err
	}
	var refreshErrors []error
	webNodeCount := 0
	for _, node := range nodes {
		if !node.Enabled || !isGrokWebScope(node.Scope) {
			continue
		}
		webNodeCount++
		proxyURL, decryptErr := m.cipher.Decrypt(node.EncryptedProxyURL)
		if decryptErr != nil {
			refreshErrors = append(refreshErrors, decryptErr)
			continue
		}
		if strings.Contains(proxyURL, application.ProxyAccountPlaceholder) {
			// Resin clearance is account/IP bound and has no safe node-wide value
			// for a background task to solve or persist.
			continue
		}
		proxyURL, normalizeErr := application.NormalizeProxyURL(proxyURL)
		if normalizeErr != nil {
			refreshErrors = append(refreshErrors, normalizeErr)
			continue
		}
		m.clearanceMu.Lock()
		key := clearanceCacheKey(node.ID, proxyURL, false)
		state, known := m.clearances[key]
		m.clearanceMu.Unlock()
		fingerprint := clearanceFingerprint(cfg, proxyURL)
		memoryFresh := known && !state.invalid && state.version == version && state.fingerprint == fingerprint && now.Sub(state.refreshedAt) < interval
		persistedFresh := (!known || !state.invalid) && node.ClearanceRefreshedAt != nil && node.ClearanceFingerprint == fingerprint && now.Sub(*node.ClearanceRefreshedAt) < interval
		if !force && (memoryFresh || persistedFresh) {
			continue
		}
		refreshForce := force || (known && state.invalid)
		refreshAfter := time.Time{}
		if refreshForce && known && state.invalid {
			refreshAfter = state.refreshedAt
		}
		_, refreshErr, _ := m.clearanceLoads.Do(key, func() (any, error) {
			return m.refreshNode(ctx, node, proxyURL, key, true, refreshForce, false, refreshAfter)
		})
		if refreshErr != nil {
			refreshErrors = append(refreshErrors, refreshErr)
		}
	}
	shouldUseDirect := direct.used || force && webNodeCount == 0
	if shouldUseDirect && (force || direct.invalid || direct.userAgent == "" || direct.version != version || now.Sub(direct.refreshedAt) >= interval) {
		_, err, _ := m.clearanceLoads.Do("direct", func() (any, error) {
			return m.refreshNode(ctx, domain.Node{Name: "direct", Scope: domain.ScopeWeb, Enabled: true}, "", "direct", false, force, false, time.Time{})
		})
		if err != nil {
			refreshErrors = append(refreshErrors, err)
		}
	}
	return errors.Join(refreshErrors...)
}

func isGrokWebScope(scope domain.Scope) bool {
	return scope == domain.ScopeWeb || scope == domain.ScopeWebAsset || scope == domain.ScopeConsole
}

func allEgressScopes() []domain.Scope {
	return []domain.Scope{domain.ScopeBuild, domain.ScopeWeb, domain.ScopeConsole, domain.ScopeWebAsset, domain.ScopeConsoleAsset}
}

func (m *Manager) isStickyProxyNode(value domain.Node) bool {
	if m == nil || m.cipher == nil || strings.TrimSpace(value.EncryptedProxyURL) == "" {
		return false
	}
	proxyURL, err := m.cipher.Decrypt(value.EncryptedProxyURL)
	return err == nil && strings.Contains(proxyURL, application.ProxyAccountPlaceholder)
}

func (m *Manager) isProxyPoolNode(value domain.Node) bool {
	return value.ProxyPool || m.isStickyProxyNode(value)
}

func (m *Manager) invalidateClientLocked(nodeID uint64) []requestClient {
	m.invalidateClientVersionLocked(nodeID)
	var stale []requestClient
	for key, cached := range m.clients {
		if key.nodeID != nodeID {
			continue
		}
		delete(m.clients, key)
		stale = append(stale, cached.client)
	}
	return stale
}

func (m *Manager) invalidateClientForScopeLocked(nodeID uint64, scope domain.Scope) []requestClient {
	m.invalidateClientVersionLocked(nodeID)
	if scope == domain.ScopeWebAsset {
		scope = domain.ScopeWeb
	}
	var stale []requestClient
	for key, cached := range m.clients {
		if key.nodeID != nodeID || key.scope != scope {
			continue
		}
		delete(m.clients, key)
		stale = append(stale, cached.client)
	}
	return stale
}

func BuildSSOCookie(token, cloudflareCookies string) string {
	token = strings.TrimSpace(token)
	if strings.HasPrefix(strings.ToLower(token), "sso=") {
		token = strings.TrimSpace(token[len("sso="):])
	}
	if value, _, found := strings.Cut(token, ";"); found {
		token = strings.TrimSpace(value)
	}
	token = strings.NewReplacer("\r", "", "\n", "", "\x00", "").Replace(token)
	cookies := "sso=" + token + "; sso-rw=" + token
	if sanitized := application.SanitizeCloudflareCookies(cloudflareCookies); sanitized != "" {
		cookies += "; " + sanitized
	}
	return cookies
}
