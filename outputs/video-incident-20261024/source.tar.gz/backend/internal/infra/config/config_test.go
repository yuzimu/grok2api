package config

import (
	"encoding/base64"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	clientkeydomain "github.com/chenyme/grok2api/backend/internal/domain/clientkey"
)

func TestLoadDatabaseURLOverridesYAMLAndSelectsPostgres(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  password: "password123"
database:
  driver: sqlite
  sqlite:
    path: "./yaml.db"
  postgres:
    dsn: "postgres://yaml:yaml@yaml.invalid/yaml"
`), 0o600); err != nil {
		t.Fatal(err)
	}
	const environmentDSN = "postgresql://env:secret@postgres.internal:5432/grok2api?sslmode=require"
	t.Setenv(DatabaseURLEnv, environmentDSN)

	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Database.Driver != "postgres" || cfg.Database.Postgres.DSN != environmentDSN {
		t.Fatalf("database config = %#v", cfg.Database)
	}
}

func TestLoadEmptyDatabaseURLKeepsYAML(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	const yamlDSN = "postgres://yaml:secret@postgres.internal:5432/grok2api"
	if err := os.WriteFile(path, []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  password: "password123"
database:
  driver: postgres
  postgres:
    dsn: "`+yamlDSN+`"
`), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv(DatabaseURLEnv, "   ")

	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Database.Driver != "postgres" || cfg.Database.Postgres.DSN != yamlDSN {
		t.Fatalf("database config = %#v", cfg.Database)
	}
}

func TestLoadStatsigSignerURLFromYAML(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  password: "password123"
provider:
  web:
    statsigMode: url
    statsigSignerURL: "https://signer.example.com/sign"
`), 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Provider.Web.StatsigMode != StatsigModeURL {
		t.Fatalf("statsigMode = %q", cfg.Provider.Web.StatsigMode)
	}
	if cfg.Provider.Web.StatsigSignerURL != "https://signer.example.com/sign" {
		t.Fatalf("statsigSignerURL = %q", cfg.Provider.Web.StatsigSignerURL)
	}
}

func TestLoadEmptyStatsigSignerURLKeepsDefault(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  password: "password123"
`), 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Provider.Web.StatsigSignerURL != DefaultStatsigSignerURL {
		t.Fatalf("statsigSignerURL = %q", cfg.Provider.Web.StatsigSignerURL)
	}
}

func TestLoadDoesNotImplicitlyReadGenericDatabaseURL(t *testing.T) {
	t.Setenv(DatabaseURLEnv, "")
	t.Setenv("DATABASE_URL", "postgres://generic:secret@postgres.internal/grok2api")
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  password: "password123"
`), 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Database.Driver != "sqlite" {
		t.Fatalf("generic DATABASE_URL unexpectedly selected %q", cfg.Database.Driver)
	}
}

func TestLoadRejectsInvalidDatabaseEnvironmentURLWithoutLeakingCredentials(t *testing.T) {
	tests := []struct {
		name    string
		value   string
		message string
	}{
		{name: "asyncpg", value: "postgresql+asyncpg://user:highly-secret@postgres.internal/grok2api", message: "改为 postgresql://"},
		{name: "unsupported scheme", value: "mysql://user:highly-secret@mysql.internal/grok2api", message: "postgres:// 或 postgresql://"},
		{name: "malformed URL", value: "postgres://user:highly-secret%zz@postgres.internal/grok2api", message: "不是有效的 PostgreSQL URL"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			t.Setenv(DatabaseURLEnv, test.value)
			_, err := Load("")
			if err == nil || !strings.Contains(err.Error(), test.message) {
				t.Fatalf("Load error = %v, want message containing %q", err, test.message)
			}
			if strings.Contains(err.Error(), "highly-secret") || strings.Contains(err.Error(), test.value) {
				t.Fatalf("Load error leaked database credentials: %v", err)
			}
		})
	}
}

func TestLoadDurationAndSecretsFromYAML(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.yaml")
	data := []byte(`server:
  requestTimeout: 2m
secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  username: "admin"
  password: "password123"
`)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}

	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Server.RequestTimeout.Value() != 2*time.Minute {
		t.Fatalf("requestTimeout = %s", cfg.Server.RequestTimeout.Value())
	}
	if cfg.Server.ReadTimeout.Value() != 15*time.Minute {
		t.Fatalf("readTimeout = %s", cfg.Server.ReadTimeout.Value())
	}
	if cfg.Secrets.JWTSecret != "12345678901234567890123456789012" {
		t.Fatalf("jwtSecret = %q", cfg.Secrets.JWTSecret)
	}
	if cfg.Secrets.CredentialEncryptionKey != "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" {
		t.Fatalf("credentialEncryptionKey = %q", cfg.Secrets.CredentialEncryptionKey)
	}
	if cfg.BootstrapAdmin.Username != "admin" || cfg.BootstrapAdmin.Password != "password123" {
		t.Fatalf("bootstrapAdmin = %#v", cfg.BootstrapAdmin)
	}
	if cfg.Batch.ImportConcurrency != 25 || cfg.Batch.ConversionConcurrency != 25 || cfg.Batch.SyncConcurrency != 25 || cfg.Batch.RefreshConcurrency != 25 || cfg.Batch.DetectConcurrency != 32 || cfg.Batch.RandomDelay.Value() != 500*time.Millisecond {
		t.Fatalf("batch defaults = %#v", cfg.Batch)
	}
	if cfg.Routing.PreferFreeBuild {
		t.Fatal("preferFreeBuild should retain its false default when omitted from YAML")
	}
	if !cfg.Routing.SegmentedSelectorEnabled || cfg.Routing.SegmentedMinCandidates != 3000 || cfg.Routing.SegmentedWindowSize != 64 {
		t.Fatalf("segmented selector defaults = %#v", cfg.Routing)
	}
	if cfg.Accounts.AutoCleanReauthEnabled || cfg.Accounts.AutoCleanIncludeDisabled {
		t.Fatal("accounts auto-clean flags should default to false")
	}
	if cfg.Accounts.MarkBuildForbiddenReauth || len(cfg.Accounts.BuildForbiddenReauthCodes) != 1 || cfg.Accounts.BuildForbiddenReauthCodes[0] != "permission-denied" {
		t.Fatalf("Build forbidden-account defaults = %#v", cfg.Accounts)
	}
	if cfg.Accounts.AutoCleanReauthInterval.Value() != 10*time.Minute || cfg.Accounts.AutoCleanReauthMinAge.Value() != time.Hour {
		t.Fatalf("accounts auto-clean defaults = %#v", cfg.Accounts)
	}
	if !cfg.Routing.ReasoningReplayEnabled || cfg.Routing.ReasoningReplayTTL.Value() != time.Hour || cfg.Routing.ReasoningReplayMaxEntries != 10240 {
		t.Fatalf("reasoning replay defaults = %#v", cfg.Routing)
	}
	if cfg.Audit.CommitDelay.Value() != 5*time.Millisecond {
		t.Fatalf("audit commit delay = %s", cfg.Audit.CommitDelay.Value())
	}
	if cfg.Audit.LedgerMode != "enforce" || cfg.Audit.LedgerFailureThreshold != 1 {
		t.Fatalf("audit ledger defaults = %#v", cfg.Audit)
	}
	if cfg.Provider.Build.ResponseHeaderTimeout.Value() != 5*time.Minute {
		t.Fatalf("Build response header timeout = %s", cfg.Provider.Build.ResponseHeaderTimeout.Value())
	}
	expectedDatabasePath := filepath.Join(dir, "data", "backend.db")
	if cfg.Database.SQLite.Path != expectedDatabasePath {
		t.Fatalf("database path = %q, want %q", cfg.Database.SQLite.Path, expectedDatabasePath)
	}
	expectedMediaPath := filepath.Join(dir, "data", "media")
	if cfg.Media.Local.Path != expectedMediaPath {
		t.Fatalf("media path = %q, want %q", cfg.Media.Local.Path, expectedMediaPath)
	}
	expectedFrontendPath := filepath.Join(dir, "frontend", "dist")
	if cfg.Frontend.StaticPath != expectedFrontendPath {
		t.Fatalf("frontend static path = %q, want %q", cfg.Frontend.StaticPath, expectedFrontendPath)
	}
}

func TestLoadQualityGuardFromYAML(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	data := []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
bootstrapAdmin:
  password: "password123"
qualityGuard:
  enabled: true
  clientKeyID: 999
  model: "grok-4.7"
  nodeIDs: [2, 9]
  minimumHealthyNodes: 1
  activeInterval: 45m
  requestRetry:
    enabled: true
    autoDisable: true
`)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
	value, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if !value.QualityGuard.Enabled || value.QualityGuard.DeprecatedClientKeyID != 999 || value.QualityGuard.ActiveInterval.Value() != 45*time.Minute {
		t.Fatalf("qualityGuard = %#v", value.QualityGuard)
	}
	retry := value.QualityGuard.RequestRetry
	if !retry.Enabled || !retry.AutoDisable || retry.MaxAttempts != 6 || retry.HoldTimeout.Value() != 30*time.Second || retry.MinOutputTokens != 5 || retry.OnExhausted != "fail_closed" || retry.AccountCooldown.Value() != 12*time.Hour || retry.IdleAccountCooldown.Value() != 15*time.Minute {
		t.Fatalf("loaded requestRetry defaults = %#v", retry)
	}
}

func TestDefaultQualityGuardRequestRetryContract(t *testing.T) {
	t.Parallel()
	got := defaultConfig().QualityGuard.RequestRetry
	if got.Enabled || got.AutoDisable || got.MaxAttempts != 6 || got.HoldTimeout.Value() != 30*time.Second || got.MinOutputTokens != 5 || got.OnExhausted != "fail_closed" || got.AccountCooldown.Value() != 12*time.Hour || got.IdleAccountCooldown.Value() != 15*time.Minute || got.MinEncryptedBytes != 256 || got.EncryptedBytesPerReasoningToken != 4 {
		t.Fatalf("requestRetry defaults = %#v", got)
	}
}

func TestAutoDisableValidatesRequestPolicyWithoutSidecar(t *testing.T) {
	t.Parallel()
	base := defaultConfig().QualityGuard
	base.RequestRetry.AutoDisable = true
	if err := validateQualityGuardConfig(base); err != nil {
		t.Fatalf("auto-disable with default policy: %v", err)
	}
	for _, test := range []struct {
		name   string
		change func(*QualityGuardConfig)
	}{
		{"retry limit", func(c *QualityGuardConfig) { c.RequestRetry.MaxAttempts = 7 }},
		{"hold timeout", func(c *QualityGuardConfig) { c.RequestRetry.HoldTimeout = Duration(time.Minute) }},
		{"output floor", func(c *QualityGuardConfig) { c.RequestRetry.MinOutputTokens = 1 }},
		{"soft TPS", func(c *QualityGuardConfig) { c.SoftTPS = 0 }},
		{"hard TPS", func(c *QualityGuardConfig) { c.HardTPS = c.SoftTPS }},
		{"generation window", func(c *QualityGuardConfig) { c.MinimumGenerationWindow = 0 }},
	} {
		t.Run(test.name, func(t *testing.T) {
			cfg := base
			test.change(&cfg)
			if err := validateQualityGuardConfig(cfg); err == nil {
				t.Fatal("invalid active request-path policy must be rejected even when the sidecar is disabled")
			}
		})
	}
}

func TestQualityGuardRequestRetryAccountCooldownBounds(t *testing.T) {
	t.Parallel()
	for _, test := range []struct {
		name    string
		value   time.Duration
		wantErr bool
	}{
		{name: "default", value: 0},
		{name: "minimum", value: time.Minute},
		{name: "maximum", value: 168 * time.Hour},
		{name: "below minimum", value: time.Minute - time.Millisecond, wantErr: true},
		{name: "above maximum", value: 168*time.Hour + time.Millisecond, wantErr: true},
	} {
		t.Run(test.name, func(t *testing.T) {
			err := validateQualityGuardRequestRetry(QualityGuardRequestRetryConfig{
				Enabled: true, AccountCooldown: Duration(test.value),
			})
			if (err != nil) != test.wantErr {
				t.Fatalf("validate cooldown %s: err=%v, wantErr=%t", test.value, err, test.wantErr)
			}
			err = validateQualityGuardRequestRetry(QualityGuardRequestRetryConfig{
				Enabled: true, IdleAccountCooldown: Duration(test.value),
			})
			if (err != nil) != test.wantErr {
				t.Fatalf("validate idle cooldown %s: err=%v, wantErr=%t", test.value, err, test.wantErr)
			}
		})
	}
}

// TestEnabledQualityGuardUsesManagedIdentity 验证内置身份和仅限 Grok 4.7 的探针配置。
func TestEnabledQualityGuardUsesManagedIdentity(t *testing.T) {
	value := defaultConfig()
	value.Secrets.JWTSecret = "12345678901234567890123456789012"
	value.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
	value.BootstrapAdmin.Password = "password123"
	value.QualityGuard.Enabled = true
	if err := value.Validate(); err != nil {
		t.Fatalf("enabled quality guard should not require a client key ID: %v", err)
	}
	for _, oldModel := range []string{"grok-4.5", "grok-4.6"} {
		value.QualityGuard.Model = oldModel
		if err := value.Validate(); err == nil {
			t.Fatalf("quality guard accepted old model %s", oldModel)
		}
	}
}

func TestBuildResponseHeaderTimeoutIsRuntimeOnly(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(path, []byte("provider:\n  build:\n    responseHeaderTimeout: 10m\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(path); err == nil {
		t.Fatal("runtime-only Build response header timeout was accepted from YAML")
	}
}

func TestDefaultGrokBuildClientVersionMatchesLocalBaseline(t *testing.T) {
	build := defaultConfig().Provider.Build
	if RecommendedBuildClientVersion != "1.0.60" {
		t.Fatalf("recommended clientVersion = %q", RecommendedBuildClientVersion)
	}
	if build.ClientVersion != RecommendedBuildClientVersion {
		t.Fatalf("clientVersion = %q", build.ClientVersion)
	}
	if RecommendedBuildUserAgent != "grok-shell/1.0.60 (linux; x86_64)" {
		t.Fatalf("recommended userAgent = %q", RecommendedBuildUserAgent)
	}
	if build.UserAgent != RecommendedBuildUserAgent {
		t.Fatalf("userAgent = %q", build.UserAgent)
	}
}

func TestLoadKeepsExplicitGrokBuildClientFingerprint(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	data := []byte(`provider:
  build:
    clientVersion: "0.2.111"
    userAgent: "grok-shell/0.2.111 (linux; x86_64)"
secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
`)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Provider.Build.ClientVersion != "0.2.111" || cfg.Provider.Build.UserAgent != "grok-shell/0.2.111 (linux; x86_64)" {
		t.Fatalf("explicit Build fingerprint was overwritten: %#v", cfg.Provider.Build)
	}
}

func TestDefaultConsoleProviderConfig(t *testing.T) {
	console := defaultConfig().Provider.Console
	if console.BaseURL != "https://console.x.ai" || console.LegacyUserAgent != "" || console.ChatTimeout.Value() != 5*time.Minute {
		t.Fatalf("console defaults = %#v", console)
	}
}

func TestLoadAcceptsLegacyConsoleUserAgent(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	data := []byte(`provider:
  console:
    userAgent: "legacy-console-agent"
secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
`)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Provider.Console.LegacyUserAgent != "legacy-console-agent" {
		t.Fatalf("legacy userAgent = %q", cfg.Provider.Console.LegacyUserAgent)
	}
}

func TestLoadAcceptsRuntimeDefaultsAndRejectsUnknownFields(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	data := []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
routing:
  maxAttempts: 9
  preferFreeBuild: true
`)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil || cfg.Routing.MaxAttempts != 9 || !cfg.Routing.PreferFreeBuild {
		t.Fatalf("runtime defaults = %#v, err = %v", cfg.Routing, err)
	}
	data = append(data, []byte("unknownField: true\n")...)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(path); err == nil {
		t.Fatal("unknown field was accepted")
	}
}

func TestRoutingMaxAttemptsSupportsLargeCredentialPools(t *testing.T) {
	cfg := defaultConfig()
	cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
	cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
	if cfg.Routing.MaxAttempts != 999 {
		t.Fatalf("default max attempts = %d, want 999", cfg.Routing.MaxAttempts)
	}
	if cfg.Routing.CapacityWait.Value() != 500*time.Millisecond {
		t.Fatalf("default capacity wait = %s, want 500ms", cfg.Routing.CapacityWait.Value())
	}
	if cfg.Provider.Web.ChatTimeout.Value() != 2*time.Minute {
		t.Fatalf("default web chat timeout = %s, want 2m", cfg.Provider.Web.ChatTimeout.Value())
	}
	cfg.Routing.MaxAttempts = 65535
	if err := cfg.Validate(); err != nil {
		t.Fatalf("65535 attempts should be valid: %v", err)
	}
	cfg.Routing.MaxAttempts = 65536
	if err := cfg.Validate(); err == nil {
		t.Fatal("65536 attempts should be rejected")
	}
	cfg.Routing.MaxAttempts = 999
	cfg.Routing.CapacityWait = Duration(30 * time.Second)
	if err := cfg.Validate(); err != nil {
		t.Fatalf("30s capacity wait should be valid: %v", err)
	}
	cfg.Routing.CapacityWait = Duration(31 * time.Second)
	if err := cfg.Validate(); err == nil {
		t.Fatal("31s capacity wait should be rejected")
	}
	cfg.Routing.CapacityWait = Duration(500 * time.Millisecond)
	cfg.Routing.MaxAttempts = -1
	if err := cfg.Validate(); err != nil {
		t.Fatalf("unlimited attempts should be valid: %v", err)
	}
	cfg.Routing.MaxAttempts = 0
	if err := cfg.Validate(); err == nil {
		t.Fatal("zero attempts should be rejected")
	}
	cfg.Routing.MaxAttempts = -2
	if err := cfg.Validate(); err == nil {
		t.Fatal("values below unlimited sentinel should be rejected")
	}
}

func TestValidateAuditRetentionDaysRange(t *testing.T) {
	for _, days := range []int{-1, 366} {
		cfg := defaultConfig()
		cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
		cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
		cfg.Audit.RetentionDays = days
		if err := cfg.Validate(); err == nil {
			t.Fatalf("audit retentionDays %d should be rejected", days)
		}
	}
	for _, days := range []int{0, 7, 365} {
		cfg := defaultConfig()
		cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
		cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
		cfg.Audit.RetentionDays = days
		if err := cfg.Validate(); err != nil {
			t.Fatalf("audit retentionDays %d should be valid: %v", days, err)
		}
	}
}

func TestValidateRejectsInvalidAutoAssignShareConfig(t *testing.T) {
	cfg := defaultConfig()
	cfg.Routing.AutoAssignMaxNodeShare = 0.03
	if err := cfg.Validate(); err == nil {
		t.Fatal("autoAssignMaxNodeShare 0.03 should be rejected")
	}
	cfg = defaultConfig()
	cfg.Routing.AutoAssignMaxMigrationShare = 1.5
	if err := cfg.Validate(); err == nil {
		t.Fatal("autoAssignMaxMigrationShare 1.5 should be rejected")
	}
	if !validAutoAssignShare(0) || !validAutoAssignShare(0.3) || !validAutoAssignShare(1) {
		t.Fatal("0, 0.3, and 1 must remain valid shares")
	}
}

func TestValidateTrustedProxies(t *testing.T) {
	for _, values := range [][]string{nil, {"127.0.0.1", "10.0.0.0/8", "2001:db8::/32"}} {
		cfg := defaultConfig()
		cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
		cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
		cfg.BootstrapAdmin.Password = "password123"
		cfg.Server.TrustedProxies = values
		if err := cfg.Validate(); err != nil {
			t.Fatalf("trusted proxies %v: %v", values, err)
		}
	}
	for _, value := range []string{"", " proxy.internal", "proxy.internal", "10.0.0.0/99", "0.0.0.0/0", "::/0"} {
		cfg := defaultConfig()
		cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
		cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
		cfg.BootstrapAdmin.Password = "password123"
		cfg.Server.TrustedProxies = []string{value}
		if err := cfg.Validate(); err == nil {
			t.Fatalf("trusted proxy %q should be rejected", value)
		}
	}
}

func TestValidateRejectsInvalidSegmentedSelectorConfig(t *testing.T) {
	tests := []func(*RoutingConfig){
		func(value *RoutingConfig) { value.SegmentedMinCandidates = 99 },
		func(value *RoutingConfig) { value.SegmentedWindowSize = 257 },
		func(value *RoutingConfig) { value.SegmentedWindowSize = value.SegmentedMinCandidates + 1 },
	}
	for index, mutate := range tests {
		cfg := defaultConfig()
		mutate(&cfg.Routing)
		if err := cfg.Validate(); err == nil {
			t.Fatalf("case %d accepted invalid segmented selector config", index)
		}
	}
}

func TestLoadRejectsMediaRuntimeSettingsInYAML(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.yaml")
	data := []byte(`secrets:
  jwtSecret: "12345678901234567890123456789012"
  credentialEncryptionKey: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
media:
  driver: local
  maxTotalBytes: 1073741824
  local:
    path: "./data/media"
`)
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(path); err == nil {
		t.Fatal("hot-reloadable media setting was accepted from YAML")
	}
}

func TestDurationStringUsesCompactYAMLForm(t *testing.T) {
	tests := map[time.Duration]string{
		250 * time.Millisecond: "250ms",
		30 * time.Second:       "30s",
		30 * time.Minute:       "30m",
		time.Hour:              "1h",
		90 * time.Minute:       "1h30m",
	}
	for value, expected := range tests {
		if actual := (Duration(value)).String(); actual != expected {
			t.Fatalf("Duration(%s).String() = %q, want %q", value, actual, expected)
		}
	}
}

func TestValidateRejectsUnsafeRuntimeLimits(t *testing.T) {
	tests := map[string]func(*Config){
		"request body": func(cfg *Config) { cfg.Server.MaxBodyBytes = maxServerBodyBytes + 1 },
		"audit buffer": func(cfg *Config) { cfg.Audit.BufferSize = maxAuditBufferSize + 1 },
		"audit commit delay": func(cfg *Config) {
			cfg.Audit.CommitDelay = Duration(maxAuditCommitDelay + time.Millisecond)
		},
		"client rpm":   func(cfg *Config) { cfg.ClientKeyDefaults.RPMLimit = clientkeydomain.MaxRPMLimit + 1 },
		"image size":   func(cfg *Config) { cfg.Media.MaxImageBytes = 33 << 20 },
		"media total":  func(cfg *Config) { cfg.Media.MaxTotalBytes = 1 },
		"batch limit":  func(cfg *Config) { cfg.Batch.SyncConcurrency = 51 },
		"batch jitter": func(cfg *Config) { cfg.Batch.RandomDelay = Duration(6 * time.Second) },
		"console url":  func(cfg *Config) { cfg.Provider.Console.BaseURL = "http://console.x.ai" },
		"console timeout": func(cfg *Config) {
			cfg.Provider.Console.ChatTimeout = Duration(time.Second)
		},
	}
	for name, mutate := range tests {
		t.Run(name, func(t *testing.T) {
			cfg := defaultConfig()
			cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
			cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
			mutate(&cfg)
			if err := cfg.Validate(); err == nil {
				t.Fatal("unsafe configuration was accepted")
			}
		})
	}
}

func TestValidateRejectsExampleSecrets(t *testing.T) {
	base := defaultConfig()
	base.Secrets.JWTSecret = "12345678901234567890123456789012"
	base.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="

	tests := map[string]func(*Config){
		"example jwt":            func(cfg *Config) { cfg.Secrets.JWTSecret = "replace-with-at-least-32-characters" },
		"invalid encryption key": func(cfg *Config) { cfg.Secrets.CredentialEncryptionKey = "not-a-32-byte-base64-key" },
		"example admin password": func(cfg *Config) { cfg.BootstrapAdmin.Password = "replace-with-a-strong-password" },
	}
	for name, mutate := range tests {
		t.Run(name, func(t *testing.T) {
			cfg := base
			mutate(&cfg)
			if err := cfg.Validate(); err == nil {
				t.Fatal("unsafe configuration was accepted")
			}
		})
	}
}

func TestValidateStatsigModes(t *testing.T) {
	base := defaultConfig()
	base.Secrets.JWTSecret = "12345678901234567890123456789012"
	base.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="

	manual := base
	manual.Provider.Web.StatsigMode = StatsigModeManual
	manual.Provider.Web.StatsigManualValue = base64.RawStdEncoding.EncodeToString(make([]byte, 70))
	if err := manual.Validate(); err != nil {
		t.Fatalf("valid manual Statsig rejected: %v", err)
	}
	manual.Provider.Web.StatsigManualValue = "invalid"
	if err := manual.Validate(); err == nil {
		t.Fatal("invalid manual Statsig was accepted")
	}

	remote := base
	remote.Provider.Web.StatsigMode = StatsigModeURL
	remote.Provider.Web.StatsigSignerURL = "http://grok-signer-go:8788/sign"
	if err := remote.Validate(); err != nil {
		t.Fatalf("Docker internal Statsig signer rejected: %v", err)
	}
	remote.Provider.Web.StatsigSignerURL = "http://signer.example.com:8788/sign"
	if err := remote.Validate(); err == nil {
		t.Fatal("public plaintext Statsig signer URL was accepted")
	}
}

func TestValidateOnDemandClearance(t *testing.T) {
	base := defaultConfig()
	base.Secrets.JWTSecret = "12345678901234567890123456789012"
	base.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
	base.Provider.Web.ClearanceMode = ClearanceModeOnDemand
	base.Provider.Web.FlareSolverrURL = "http://flaresolverr:8191"
	if err := base.Validate(); err != nil {
		t.Fatalf("valid on-demand Clearance rejected: %v", err)
	}
}

func TestValidateFlareSolverrClearance(t *testing.T) {
	base := defaultConfig()
	base.Secrets.JWTSecret = "12345678901234567890123456789012"
	base.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
	base.Provider.Web.ClearanceMode = ClearanceModeFlareSolverr
	base.Provider.Web.FlareSolverrURL = "http://flaresolverr:8191"
	if err := base.Validate(); err != nil {
		t.Fatalf("valid FlareSolverr config rejected: %v", err)
	}
	base.Provider.Web.FlareSolverrURL = "ftp://solver.example"
	if err := base.Validate(); err == nil {
		t.Fatal("invalid FlareSolverr scheme was accepted")
	}
	base.Provider.Web.FlareSolverrURL = "http://solver.example:8191"
	if err := base.Validate(); err == nil {
		t.Fatal("public plaintext FlareSolverr URL was accepted")
	}
	base.Provider.Web.FlareSolverrURL = "https://solver.example/v1"
	if err := base.Validate(); err != nil {
		t.Fatalf("public HTTPS FlareSolverr URL rejected: %v", err)
	}
}

func TestValidateInfrastructureDrivers(t *testing.T) {
	base := defaultConfig()
	base.Secrets.JWTSecret = "12345678901234567890123456789012"
	base.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="

	postgresRedis := base
	postgresRedis.Database.Driver = "postgres"
	postgresRedis.Database.Postgres.DSN = "postgres://user:password@127.0.0.1:5432/grok2api"
	postgresRedis.RuntimeStore.Driver = "redis"
	if err := postgresRedis.Validate(); err != nil {
		t.Fatalf("valid postgres + redis configuration rejected: %v", err)
	}
	postgresRedis.Deployment = DeploymentConfig{Replicas: 2, InstanceID: "replica-a", ClusterID: "cluster-a", SharedMedia: true}
	if err := postgresRedis.Validate(); err != nil {
		t.Fatalf("valid multi-replica configuration rejected: %v", err)
	}

	invalidMultiReplica := base
	invalidMultiReplica.Deployment.Replicas = 2
	if err := invalidMultiReplica.Validate(); err == nil {
		t.Fatal("multi-replica SQLite and memory configuration was accepted")
	}

	invalidDatabase := base
	invalidDatabase.Database.Driver = "mysql"
	if err := invalidDatabase.Validate(); err == nil {
		t.Fatal("unsupported database driver was accepted")
	}

	invalidRuntime := base
	invalidRuntime.RuntimeStore.Driver = "fallback"
	if err := invalidRuntime.Validate(); err == nil {
		t.Fatal("unsupported runtime store driver was accepted")
	}
}

func TestValidateFrontendPublicAPIBaseURL(t *testing.T) {
	cfg := defaultConfig()
	cfg.Secrets.JWTSecret = "12345678901234567890123456789012"
	cfg.Secrets.CredentialEncryptionKey = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
	for _, value := range []string{"127.0.0.1:8000", "ftp://example.com", "https://user@example.com", "https://example.com?token=value"} {
		cfg.Frontend.PublicAPIBaseURL = value
		if err := cfg.Validate(); err == nil {
			t.Fatalf("frontend.publicApiBaseURL %q was accepted", value)
		}
	}
	cfg.Frontend.PublicAPIBaseURL = "https://api.example.com/grok2api"
	cfg.Auth.SecureCookies = false
	if err := cfg.Validate(); err != nil {
		t.Fatalf("valid frontend.publicApiBaseURL rejected: %v", err)
	}
}

func TestEffectivePublicAPIBaseURLPriority(t *testing.T) {
	cases := []struct {
		name     string
		frontend FrontendConfig
		want     string
	}{
		{name: "runtime override", frontend: FrontendConfig{PublicAPIBaseURL: "https://yaml.example/base", PublicAPIBaseURLOverride: "https://runtime.example/api/"}, want: "https://runtime.example/api"},
		{name: "yaml fallback", frontend: FrontendConfig{PublicAPIBaseURL: "https://yaml.example/base/"}, want: "https://yaml.example/base"},
		{name: "local fallback", frontend: FrontendConfig{}, want: DefaultPublicAPIBaseURL},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := tc.frontend.EffectivePublicAPIBaseURL(); got != tc.want {
				t.Fatalf("EffectivePublicAPIBaseURL() = %q, want %q", got, tc.want)
			}
		})
	}
}
